# Compilation de Feuillet sur GitHub (lance par .github/workflows/feuillet.yml).
# Ce script voyage dans le zip des sources : on le modifie sans toucher au
# script de GitHub.

$ErrorActionPreference = 'Stop'
$version = '6.7.3'
$arch = 'win64_msvc2019_64'
$qtBase = Join-Path $env:RUNNER_TEMP 'Qt'
$qt = Join-Path $qtBase "$version\msvc2019_64"

Write-Host '=== Qt 6'
python -m pip install --quiet aqtinstall
if ($LASTEXITCODE -ne 0) { exit 1 }
python -m aqt install-qt windows desktop $version $arch -m qtpdf qtimageformats -O $qtBase
if ($LASTEXITCODE -ne 0) { exit 1 }

Write-Host '=== LibRaw (photos RAW)'
& "$env:VCPKG_INSTALLATION_ROOT\vcpkg.exe" install libraw:x64-windows-static-md
$avecLibRaw = ($LASTEXITCODE -eq 0)

Write-Host '=== Compilation'
$ok = $false
if ($avecLibRaw) {
    $tc = "$env:VCPKG_INSTALLATION_ROOT\scripts\buildsystems\vcpkg.cmake"
    cmake -S . -B build -A x64 "-DCMAKE_PREFIX_PATH=$qt" "-DCMAKE_TOOLCHAIN_FILE=$tc" -DVCPKG_TARGET_TRIPLET=x64-windows-static-md -DVCPKG_MANIFEST_MODE=OFF
    if ($LASTEXITCODE -eq 0) { cmake --build build --config Release --parallel }
    $ok = ($LASTEXITCODE -eq 0)
}
if (-not $ok) {
    Write-Host '::warning::Compilation sans LibRaw (les RAW passeront par Windows)'
    Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue
    cmake -S . -B build -A x64 "-DCMAKE_PREFIX_PATH=$qt" -DFEUILLET_AVEC_LIBRAW=OFF
    if ($LASTEXITCODE -ne 0) { exit 1 }
    cmake --build build --config Release --parallel
    if ($LASTEXITCODE -ne 0) { exit 1 }
}

Write-Host '=== Rassemblement'
New-Item -ItemType Directory -Force Feuillet | Out-Null
Copy-Item build\Release\Feuillet.exe Feuillet\
& "$qt\bin\windeployqt.exe" --release --no-translations --no-system-d3d-compiler --no-opengl-sw --no-compiler-runtime Feuillet\Feuillet.exe
if ($LASTEXITCODE -ne 0) { exit 1 }
# Les bibliotheques d'execution de Visual C++ voyagent avec le programme.
$vs = & "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe" -latest -property installationPath
$crt = Get-ChildItem "$vs\VC\Redist\MSVC\*\x64\Microsoft.VC*.CRT" -Directory | Sort-Object FullName | Select-Object -Last 1
if ($crt) { Copy-Item "$($crt.FullName)\*.dll" Feuillet\ }
Compress-Archive -Path Feuillet -DestinationPath Feuillet.zip -Force

Write-Host '=== Publication'
gh release delete derniere --yes --cleanup-tag 2>$null
$global:LASTEXITCODE = 0
gh release create derniere Feuillet.zip --target $env:GITHUB_SHA --title 'Feuillet - derniere compilation' --notes 'Dezipper puis lancer Feuillet\Feuillet.exe' --latest
if ($LASTEXITCODE -ne 0) { exit 1 }
Write-Host 'Feuillet.zip publie.'
