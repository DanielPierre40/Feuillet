// lecteurs_images — ce que faisaient Pillow et rawpy dans la version Python :
//
//   · PSD   — lecture de l'image composite (« aplatie ») rangée dans le fichier ;
//   · RAW   — développement par LibRaw (la bibliothèque qu'utilisait rawpy) ;
//   · WIC   — le décodeur d'images de Windows, qui lit en plus tout ce pour quoi
//             un codec est installé (HEIC, AVIF, RAW d'appareils, JPEG XR, DDS…).
//
// Chaque lecteur rend une QImage nulle s'il ne sait pas lire le fichier.
#pragma once

#include <QImage>
#include <QString>

namespace lecteurs {

QImage lirePsd(const QString &chemin);
QImage lireRaw(const QString &chemin);   // nulle si LibRaw est absent
QImage lireWic(const QString &chemin);   // nulle hors Windows
bool rawDisponible();
bool estExtensionRaw(const QString &ext);

} // namespace lecteurs
