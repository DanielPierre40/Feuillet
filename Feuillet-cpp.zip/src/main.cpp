// Feuillet — gestionnaire d'impression de la suite Le Barrail (version C++).
//
// Le même exécutable sert aussi l'imprimante virtuelle « Feuillet » :
//     Feuillet.exe --guetteur              surveillance du spool (sans fenêtre)
//     Feuillet.exe --admin-installer S     partie élevée de l'installation
//     Feuillet.exe --admin-desinstaller S  partie élevée de la désinstallation
// et ouvre directement les fichiers qu'on lui passe en argument.

#include "apparence.h"
#include "driver_feuillet.h"
#include "main_window.h"
#include "theme.h"
#include "ui_helpers.h"

#include <QApplication>
#include <QCoreApplication>
#include <QFileInfo>
#include <QIcon>
#include <QImageReader>
#include <QPalette>
#include <QStyleFactory>
#include <QTimer>

#include <cstring>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <shobjidl.h>
#endif

static int modeDriver(int argc, char **argv)
{
    for (int i = 1; i < argc; ++i) {
        const char *a = argv[i];
        if (std::strcmp(a, "--guetteur") == 0)
            return 1;
        if (std::strcmp(a, "--admin-installer") == 0)
            return 2;
        if (std::strcmp(a, "--admin-desinstaller") == 0)
            return 3;
    }
    return 0;
}

int main(int argc, char **argv)
{
    const int mode = modeDriver(argc, argv);
    if (mode) {
        // Pas de fenêtre du tout : une application console invisible suffit.
        QCoreApplication app(argc, argv);
        const QStringList args = QCoreApplication::arguments();
        auto suivant = [&args](const QString &option) {
            const int i = int(args.indexOf(option));
            return (i >= 0 && i + 1 < args.size()) ? args.at(i + 1) : driver::fichierSpool();
        };
        if (mode == 1)
            return driver::guetteur();
        if (mode == 2)
            return driver::adminInstaller(suivant(QStringLiteral("--admin-installer")));
        return driver::adminDesinstaller(suivant(QStringLiteral("--admin-desinstaller")));
    }

#ifdef Q_OS_WIN
    // La barre des tâches doit montrer l'icône de Feuillet : le processus se
    // déclare application à part entière AVANT toute fenêtre.
    SetCurrentProcessExplicitAppUserModelID(L"LeBarrail.Feuillet");
#endif

    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("Feuillet"));
    QApplication::setOrganizationName(QStringLiteral("Le Barrail"));
    app.setStyle(QStyleFactory::create(QStringLiteral("Fusion")));
    app.setWindowIcon(QIcon(QStringLiteral(":/feuillet.ico")));
    // Les photos de plusieurs centaines de mégapixels doivent passer : la
    // limite de Qt (256 Mo) est levée.
    QImageReader::setAllocationLimit(0);

    QPalette pal;
    pal.setColor(QPalette::Window, QColor(theme::BG_WIN));
    pal.setColor(QPalette::WindowText, QColor(theme::FG));
    pal.setColor(QPalette::Base, QColor(theme::BG_EDITOR));
    pal.setColor(QPalette::Text, QColor(theme::FG));
    pal.setColor(QPalette::Button, QColor(theme::TOOLBAR_BG));
    pal.setColor(QPalette::ButtonText, QColor(theme::FG));
    pal.setColor(QPalette::Highlight, QColor(theme::ACCENT));
    pal.setColor(QPalette::HighlightedText, QColor(QStringLiteral("#ffffff")));
    pal.setColor(QPalette::ToolTipBase, QColor(QStringLiteral("#1c1c2c")));
    pal.setColor(QPalette::ToolTipText, QColor(theme::FG));
    app.setPalette(pal);

    apparence::appliquerStyle(&app);
    apparence::installer(&app);
    ui::poserCurseurs(&app);

    MainWindow w;
    w.show();

    // Ouverture directe des fichiers passés en argument (imprimante, glisser
    // sur l'icône, « Ouvrir avec »).
    QStringList chemins;
    const QStringList args = QCoreApplication::arguments();
    for (int i = 1; i < args.size(); ++i)
        if (QFileInfo(args.at(i)).isFile())
            chemins << args.at(i);
    if (!chemins.isEmpty())
        QTimer::singleShot(0, &w, [&w, chemins]() { w.runWithPaths(chemins); });

    return app.exec();
}
