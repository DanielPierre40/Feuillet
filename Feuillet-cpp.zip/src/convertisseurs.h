// convertisseurs — les logiciels que Feuillet sait faire travailler pour lui :
// Microsoft Office (COM), LibreOffice (--headless), ImageMagick, GIMP
// (Script-Fu). Feuillet les cherche seul ; il ne pose une question que le jour
// où il en a besoin, une seule fois.
#pragma once

#include <QMap>
#include <QPair>
#include <QSet>
#include <QString>
#include <QStringList>
#include <QVariant>
#include <functional>

class QWidget;

namespace cv {

struct Fiche {
    QString nom;        // tel qu'il est présenté à l'utilisateur
    QString quoi;       // ce qu'il permet d'ouvrir, en une ligne
    QSet<QString> formats;
    QStringList exes;   // cherchés dans le PATH
    QStringList dossiers; // emplacements habituels, motifs acceptés (*)
    QString filtre;     // filtre de la boîte « Parcourir »
};

const QMap<QString, Fiche> &table();

// Exécute `fonction` sur le fil de l'interface et rend son résultat.
QVariant auPremierPlan(const std::function<QVariant()> &fonction);

QString cheminRetenu(const QString &cle);
void retenir(const QString &cle, const QString &chemin);
bool refuse(const QString &cle);
void noterRefus(const QString &cle);
QString chercher(const QString &cle);
QString trouver(const QString &cle);
QStringList convertisseursPour(const QString &ext);
QString demander(const QString &cle, const QString &ext, QWidget *parent);
QString identifier(const QString &chemin, const QString &ext = QString());
QPair<QString, QString> designerALaMain(const QString &ext, QWidget *parent);

// Les recettes — lèvent ErreurChargement en cas d'échec.
QString convertirEnPdf(const QString &soffice, const QString &fichier, const QString &dossierSortie);
QString xcfViaImagemagick(const QString &magick, const QString &fichier);
QString xcfViaGimp(const QString &gimp, const QString &fichier);

} // namespace cv
