// format_inconnu — fenêtre affichée quand Feuillet ne reconnaît pas le format
// d'un fichier. Elle vérifie si l'imprimante « Feuillet » est installée, et
// propose de l'installer sur place si besoin.
#pragma once

#include <QDialog>

class QLabel;
class QPushButton;

class FormatInconnuDialog : public QDialog {
    Q_OBJECT
public:
    static constexpr int LARGEUR = 560;
    static constexpr int MARGES = 56;

    explicit FormatInconnuDialog(QWidget *parent = nullptr);

private:
    QPushButton *bouton(const QString &texte, const QString &fond, const QString &survol,
                        const QString &appui);
    void rafraichir();
    void installerImprimante();

    QString m_famille;
    int m_taille;
    int m_largeur;
    QLabel *m_mot;
    QPushButton *m_btnInstaller;
    QPushButton *m_btnAnnuler;
};
