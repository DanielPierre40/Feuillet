// workers — chargement des fichiers dans un fil séparé, et écran d'attente.
#pragma once

#include <QElapsedTimer>
#include <QImage>
#include <QList>
#include <QObject>
#include <QPixmap>
#include <QStringList>
#include <QWidget>
#include <functional>

class QLabel;
class QTimer;

// Échec d'un chargeur : le message est montré tel quel à l'utilisateur.
struct ErreurChargement {
    QString message;
};

// Une page produite par le chargeur, avec sa provenance.
struct ImageChargee {
    QImage image;
    QString chemin;     // chemin RÉEL demandé (jamais la copie temporaire)
    int page = 1;
    int pages = 1;
};

using Chargeur = std::function<QList<QImage>(const QString &)>;

class LoadWorker : public QObject {
    Q_OBJECT
public:
    LoadWorker(Chargeur chargeur, const QStringList &chemins);

public slots:
    void run();

signals:
    void termine(const QList<ImageChargee> &images, const QStringList &erreurs);

private:
    static QString copieTemporaire(const QString &source);
    void collecter(const QList<QImage> &resultat, const QString &nom, const QString &source,
                   QList<ImageChargee> &images, QStringList &erreurs);

    Chargeur m_chargeur;
    QStringList m_chemins;
};

Q_DECLARE_METATYPE(ImageChargee)

class FonduAttente : public QWidget {
    Q_OBJECT
public:
    static constexpr int PAUSE = 2000;
    static constexpr int FONDU = 900;
    static constexpr int INTERVALLE = 33;

    explicit FonduAttente(QWidget *parent = nullptr);
    void demarrer();
    void arreter();

protected:
    void resizeEvent(QResizeEvent *e) override;
    void paintEvent(QPaintEvent *e) override;

private:
    void remettreALEchelle();

    QList<QPixmap> m_images;
    QList<QPixmap> m_echelle;
    QElapsedTimer m_horloge;
    QTimer *m_timer;
};

class LoadingOverlay : public QWidget {
    Q_OBJECT
public:
    static constexpr int DELAI_GRACE = 350;

    explicit LoadingOverlay(QWidget *parent);
    void start();
    void stop();

protected:
    void resizeEvent(QResizeEvent *e) override;
    void paintEvent(QPaintEvent *e) override;

private:
    void animer();
    void montrer();

    QWidget *m_carte;
    FonduAttente *m_fondu;
    QLabel *m_lblMsg;
    QLabel *m_lblHint;
    int m_tick = 0;
    QTimer *m_timer;
    QTimer *m_attente;
};

// Convertit le résultat du fil de chargement en pixmaps (fil de l'interface)
// et note la provenance de chacune.
QList<QPixmap> pixmapsDepuis(const QList<ImageChargee> &images);
