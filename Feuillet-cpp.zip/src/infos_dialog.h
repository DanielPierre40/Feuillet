// infos_dialog — la fenêtre « Infos » du menu contextuel d'un élément.
#pragma once

#include <QDialog>

class QGridLayout;
class QPushButton;
class ResizablePixmapItem;

QString formatPapier(int largeurPx, int hauteurPx, int ppp);
QString poidsLisible(qint64 octets);
bool montrerDansExplorateur(const QString &chemin);

class InfosDialog : public QDialog {
    Q_OBJECT
public:
    InfosDialog(ResizablePixmapItem *item, int ppp, QWidget *parent = nullptr);

private:
    void ligne(QGridLayout *grille, int rang, const QString &libelle, const QString &valeur,
               bool grise = false, const QString &texteGrise = QString(), bool selectionnable = false);
    void allerAuDossier();

    QString m_chemin;
    QPushButton *m_btnDossier;
};
