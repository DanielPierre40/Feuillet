// aide_dialog — la fenêtre « Aide » : elle dit où trouver le PDF d'aide.
// Largeur libre ; la hauteur suit le texte replié tant qu'on ne l'a pas
// réglée soi-même ; poignée de taille en bas à droite.
#pragma once

#include <QDialog>

class QLabel;
class QLayoutItem;
class QVBoxLayout;

class AideDialog : public QDialog {
    Q_OBJECT
public:
    static constexpr int LARGEUR = 520;
    static constexpr int LARGEUR_MINI = 340;

    explicit AideDialog(QWidget *parent = nullptr);

protected:
    void resizeEvent(QResizeEvent *e) override;
    void showEvent(QShowEvent *e) override;

private:
    void ajusterHauteur();

    QLabel *m_mot;
    QLayoutItem *m_ressort = nullptr;
    bool m_enAjustement = false;
    int m_habillage = -1;
    bool m_hauteurLibre = false;
    int m_hauteurPosee = -1;
};
