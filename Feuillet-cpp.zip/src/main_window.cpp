#include "main_window.h"

#include "aide_dialog.h"
#include "apres_impression.h"
#include "barre_titre.h"
#include "chargeur.h"
#include "config.h"
#include "format_inconnu.h"
#include "graphics_items.h"
#include "memoire_fenetres.h"
#include "options_dialog.h"
#include "origines.h"
#include "print_editor_dialog.h"
#include "theme.h"
#include "ui_helpers.h"

#include <QApplication>
#include <QDateTime>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QGraphicsScene>
#include <QHBoxLayout>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLinearGradient>
#include <QMessageBox>
#include <QPageLayout>
#include <QPageSize>
#include <QPainter>
#include <QPrintDialog>
#include <QPrinter>
#include <QProcess>
#include <QPushButton>
#include <QThread>
#include <QUrl>
#include <QVBoxLayout>

#include <algorithm>

namespace {

// Un seul filtre, et il n'exclut rien : c'est à l'ouverture que se décide ce
// qui est faisable.
const QString OPEN_FILTER = QStringLiteral("Tous les fichiers (*)");

// Le titre « FEUILLET » en dégradé orange qui s'efface vers le bas.
class TitreDegrade : public QWidget {
public:
    explicit TitreDegrade(const QString &texte, QWidget *parent = nullptr) : QWidget(parent), m_texte(texte)
    {
        setAttribute(Qt::WA_TranslucentBackground);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        setFixedHeight(80);
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing);
        p.setRenderHint(QPainter::TextAntialiasing);
        QFont f(theme::FONT_UI, 42, 900);
        f.setLetterSpacing(QFont::AbsoluteSpacing, 8);
        p.setFont(f);
        QLinearGradient g(0, 0, 0, height());
        g.setColorAt(0.0, QColor(QStringLiteral("#e8770a")));
        g.setColorAt(0.55, QColor(QStringLiteral("#e8770a")));
        g.setColorAt(1.0, QColor(232, 119, 10, 0));
        p.setPen(QPen(QBrush(g), 0));
        p.drawText(rect(), Qt::AlignHCenter | Qt::AlignVCenter, m_texte);
    }

private:
    QString m_texte;
};

} // namespace

MainWindow::MainWindow()
{
    setWindowTitle(QStringLiteral("Feuillet — Gestionnaire d'impression"));
    resize(520, 420);

    auto *central = new QWidget();
    central->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BG_WIN));
    auto *root = new QVBoxLayout(central);
    root->setSpacing(0);
    root->setContentsMargins(0, 0, 0, 0);

    // ── Barre supérieure ──────────────────────────────────────────────
    auto *topbar = new QWidget();
    topbar->setFixedHeight(36);
    topbar->setStyleSheet(QStringLiteral("background: %1;").arg(theme::TOOLBAR_BG));
    auto *topL = new QHBoxLayout(topbar);
    topL->setContentsMargins(8, 0, 8, 0);
    topL->setSpacing(0);
    topL->addStretch();
    const QString styleHaut = QStringLiteral("QPushButton { background: transparent; color: #8a92aa; border: none;"
                                             "  font-size: 9pt; font-family: '%1'; padding: 0 8px; }"
                                             "QPushButton:hover { color: %2; }"
                                             "QPushButton:pressed { color: %3; }")
                                  .arg(theme::FONT_UI, theme::ACCENT, theme::FG);
    auto boutonHaut = [&](const QString &texte, const QString &bulle) {
        auto *b = new QPushButton(texte);
        b->setToolTip(bulle);
        b->setFixedHeight(26);
        b->setStyleSheet(styleHaut);
        topL->addWidget(b);
        return b;
    };
    connect(boutonHaut(QStringLiteral("Options"), QStringLiteral("Réglages de Feuillet")), &QPushButton::clicked, this,
            [this]() {
                OptionsDialog d(this);
                d.exec();
            });
    connect(boutonHaut(QStringLiteral("Aide"), QStringLiteral("Aide sur l'utilisation de Feuillet")),
            &QPushButton::clicked, this, [this]() {
                AideDialog d(this);
                d.exec();
            });
    connect(boutonHaut(QStringLiteral("Quitter"), QStringLiteral("Fermer Feuillet")), &QPushButton::clicked, this,
            &QWidget::close);
    root->addWidget(topbar);

    // ── Corps ─────────────────────────────────────────────────────────
    auto *body = new QWidget();
    auto *bl = new QVBoxLayout(body);
    bl->setSpacing(0);
    bl->setContentsMargins(36, 22, 36, 36);
    bl->addWidget(new TitreDegrade(QStringLiteral("FEUILLET")));

    auto *sous = new QLabel(QStringLiteral("Gestionnaire d'impression"));
    sous->setAlignment(Qt::AlignCenter);
    sous->setStyleSheet(QStringLiteral("color: #8a92aa; font-size: 11pt; font-family: '%1';"
                                       "background: transparent; margin-bottom: 2px;")
                            .arg(theme::FONT_UI));
    bl->addWidget(sous);
    auto *ver = new QLabel(QStringLiteral("Le Barrail  /  Feuillet"));
    ver->setAlignment(Qt::AlignCenter);
    ver->setStyleSheet(QStringLiteral("color: %1; font-size: 8pt; font-family: '%2';"
                                      "background: transparent; margin-bottom: 24px;")
                           .arg(theme::FG2, theme::FONT_UI));
    bl->addWidget(ver);
    auto *sep = new QWidget();
    sep->setFixedHeight(1);
    sep->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BORDER_COL));
    bl->addWidget(sep);
    auto *sp = new QWidget();
    sp->setFixedHeight(20);
    sp->setStyleSheet(QStringLiteral("background: transparent;"));
    bl->addWidget(sp);

    const QString styleBtn = QStringLiteral("QPushButton { background: %1; color: %2;"
                                            "  border: 1px solid %3; border-radius: 4px;"
                                            "  padding: 10px 20px; font-family: '%4'; font-size: 14pt; }"
                                            "QPushButton:hover { background: %5; color: %6;"
                                            "  border-color: %6; }"
                                            "QPushButton:pressed { background: %7; }")
                                 .arg(theme::BG_BTN, theme::FG, theme::BD_BTN, theme::FONT_UI, theme::BG_BTN_HOV,
                                      theme::ACCENT, theme::BG_BTN_PRS);
    auto *btnOpen = new QPushButton(QStringLiteral("📂   Ouvrir une image ou un document (ou plusieurs)"));
    btnOpen->setMinimumHeight(72);
    btnOpen->setStyleSheet(styleBtn);
    connect(btnOpen, &QPushButton::clicked, this, &MainWindow::ouvrir);
    ui::addShadow(btnOpen);
    auto *btnImport = new QPushButton(QStringLiteral("📥   Importer un feuillet"));
    btnImport->setMinimumHeight(72);
    btnImport->setStyleSheet(styleBtn);
    connect(btnImport, &QPushButton::clicked, this, &MainWindow::importerFeuillet);
    ui::addShadow(btnImport);
    bl->addWidget(btnOpen);
    bl->addSpacing(12);
    bl->addWidget(btnImport);

    // ── Avatar ────────────────────────────────────────────────────────
    bl->addSpacing(30);
    auto *avatar = new QLabel();
    avatar->setFixedSize(64, 64);
    avatar->setAlignment(Qt::AlignCenter);
    avatar->setPixmap(QPixmap(QStringLiteral(":/avatar.jpg")));
    avatar->setStyleSheet(QStringLiteral("background: transparent;"));
    ui::addShadow(avatar, 14, 0, 5, 110);
    auto *rangAvatar = new QHBoxLayout();
    rangAvatar->addStretch();
    rangAvatar->addWidget(avatar);
    rangAvatar->addStretch();
    bl->addLayout(rangAvatar);
    bl->addSpacing(30);

    root->addWidget(body);
    setCentralWidget(central);
    cadre::poserCadre(this);
    memoire::retenir(this, QStringLiteral("accueil"));
    // Le voile se pose DANS le cadre arrondi.
    QWidget *porteur = cadre::contenuDe(this);
    m_overlay = new LoadingOverlay(porteur ? porteur : centralWidget());
}

Chargeur MainWindow::chargeur()
{
    return [this](const QString &chemin) { return chargeur::charger(chemin, this, &m_formatInconnu); };
}

void MainWindow::ouvrir()
{
    const QStringList chemins =
        QFileDialog::getOpenFileNames(this, QStringLiteral("Ouvrir"), config::departFichier(), OPEN_FILTER);
    if (!chemins.isEmpty())
        runWithPaths(chemins);
}

void MainWindow::runWithPaths(const QStringList &chemins)
{
    m_formatInconnu = false;
    m_overlay->start();
    auto *fil = new QThread();
    auto *ouvrier = new LoadWorker(chargeur(), chemins);
    ouvrier->moveToThread(fil);
    connect(fil, &QThread::started, ouvrier, &LoadWorker::run);
    connect(ouvrier, &LoadWorker::termine, this, &MainWindow::chargementTermine);
    connect(ouvrier, &LoadWorker::termine, fil, &QThread::quit);
    connect(fil, &QThread::finished, ouvrier, &QObject::deleteLater);
    connect(fil, &QThread::finished, fil, &QObject::deleteLater);
    fil->start();
}

void MainWindow::chargementTermine(const QList<ImageChargee> &images, const QStringList &erreursBrutes)
{
    m_overlay->stop();
    direFormatInconnu();
    // Certains échecs ont leur propre fenêtre : pas de doublon dans la liste.
    QStringList erreurs;
    for (const QString &e : erreursBrutes)
        if (!e.endsWith(chargeur::DEJA_DIT))
            erreurs << e;
    if (!erreurs.isEmpty())
        QMessageBox::warning(this, QStringLiteral("Fichiers non chargés"),
                             QStringLiteral("Certains fichiers n'ont pas pu être ouverts :\n\n") + erreurs.join(QLatin1Char('\n')));
    const QList<QPixmap> pixmaps = pixmapsDepuis(images);
    if (pixmaps.isEmpty())
        return;
    auto *dlg = new PrintEditorDialog(pixmaps, this);
    boucleMiseEnPage(dlg);
}

void MainWindow::direFormatInconnu(QWidget *parent)
{
    // Dit une seule fois par ouverture, une fois le chargement TERMINÉ.
    if (!m_formatInconnu.exchange(false))
        return;
    FormatInconnuDialog d(parent ? parent : this);
    d.exec();
}

// ---------------------------------------------------------------------------
// Cycle de vie d'une mise en page
// ---------------------------------------------------------------------------
void MainWindow::boucleMiseEnPage(PrintEditorDialog *dlg)
{
    // La fermeture de Feuillet se décide ICI et nulle part ailleurs.
    for (;;) {
        if (dlg->exec() != QDialog::Accepted)
            break; // « Retour », ou sortie demandée
        if (!printFinal(dlg))
            continue; // impression annulée : on repose la mise en page
        if (apresImpression(dlg))
            break; // nouveau travail : retour à l'accueil
    }
    const bool sortir = dlg->sortieDemandee();
    dlg->deleteLater();
    if (sortir) {
        close();
        QApplication::quit();
        return;
    }
    raise();
    activateWindow();
}

bool MainWindow::apresImpression(PrintEditorDialog *dlg)
{
    for (;;) {
        ApresImpressionDialog d(this, QStringLiteral("Impression lancée"), QStringLiteral("🖨️   Impression lancée"),
                                QStringLiteral("Que faire maintenant ?"), ApresImpressionDialog::portesImpression(),
                                ApresImpressionDialog::REVENIR);
        const int choix = d.demander();
        if (choix == ApresImpressionDialog::REVENIR)
            return false; // l'Atelier se repose, intact
        if (choix == ApresImpressionDialog::SAUVER) {
            if (dlg->saveFeuillet()) {
                dlg->demanderLaSortie();
                return true;
            }
            continue; // sauvegarde annulée : on repropose
        }
        if (choix == ApresImpressionDialog::QUITTER) {
            dlg->demanderLaSortie();
            return true;
        }
        return true; // nouveau travail
    }
}

void MainWindow::importerFeuillet()
{
    const QString chemin = QFileDialog::getOpenFileName(this, QStringLiteral("Importer un feuillet"),
                                                        config::departFichier(), QStringLiteral("Feuillet (*.feuillet)"));
    if (chemin.isEmpty())
        return;
    QFile f(chemin);
    if (!f.open(QIODevice::ReadOnly)) {
        QMessageBox::warning(this, QStringLiteral("Importer un feuillet"), QStringLiteral("Fichier illisible."));
        return;
    }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const QJsonObject data = QJsonDocument::fromJson(f.readAll()).object();
    const QJsonArray items = data.value(QStringLiteral("items")).toArray();
    if (items.isEmpty()) {
        QApplication::restoreOverrideCursor();
        return;
    }
    auto *dlg = new PrintEditorDialog({}, this);
    dlg->restoreSheets(data.value(QStringLiteral("sheets")).toArray());
    for (const QJsonValue &v : items) {
        const QJsonObject o = v.toObject();
        // Seule la version pleine résolution est relue.
        QPixmap orig;
        orig.loadFromData(QByteArray::fromBase64(o.value(QStringLiteral("original")).toString().toLatin1()), "PNG");
        if (orig.isNull())
            continue;
        // La provenance est réinscrite au registre AVANT de créer l'élément.
        const QJsonValue org = o.value(QStringLiteral("origine"));
        if (org.isObject()) {
            const Origine origine = Origine::depuisJson(org.toObject());
            if (origine.valide())
                origines::noter(orig, origine.chemin, origine.page, origine.pages);
        }
        auto *it = new ResizablePixmapItem(orig);
        it->poserTaille(o.value(QStringLiteral("w")).toInt(), o.value(QStringLiteral("h")).toInt());
        dlg->scene()->addItem(it);
        it->setPos(o.value(QStringLiteral("x")).toDouble(), o.value(QStringLiteral("y")).toDouble());
    }
    QApplication::restoreOverrideCursor();
    // Le feuillet chargé EST le point de départ, et il sort tout droit du disque.
    dlg->repartirDeZero();
    dlg->marquerEnregistre();
    boucleMiseEnPage(dlg);
}

// ---------------------------------------------------------------------------
// Impression
// ---------------------------------------------------------------------------
QString MainWindow::fichierPdf()
{
    // Le nom porte la date et l'heure : deux impressions ne s'écrasent pas.
    const QString nom = QDateTime::currentDateTime().toString(QStringLiteral("'Feuillet 'yyyy-MM-dd HH'h'mm'.pdf'"));
    const QString depart = config::departFichier();
    const QString propose = depart.isEmpty() ? nom : QDir(depart).filePath(nom);
    QString chemin = QFileDialog::getSaveFileName(this, QStringLiteral("Imprimer en PDF"), propose,
                                                  QStringLiteral("PDF (*.pdf)"));
    if (chemin.isEmpty())
        return QString();
    if (!chemin.toLower().endsWith(QLatin1String(".pdf")))
        chemin += QStringLiteral(".pdf");
    return chemin;
}

void MainWindow::montrerLePdf(const QString &chemin)
{
    if (!config::ouvrirPdfApres() || !QFileInfo(chemin).isFile())
        return;
    const QString lecteur = config::lecteurPdf();
    QString message;
    if (!lecteur.isEmpty() && QFileInfo(lecteur).isFile()) {
        if (QProcess::startDetached(lecteur, {QDir::toNativeSeparators(chemin)}))
            return;
        message = QStringLiteral("Le lecteur désigné n'a pas pu démarrer.");
    } else {
        if (QDesktopServices::openUrl(QUrl::fromLocalFile(chemin)))
            return;
        message = QStringLiteral("Windows n'a pas trouvé de programme pour ouvrir les fichiers PDF.");
    }
    QMessageBox::information(this, QStringLiteral("Ouverture du PDF"),
                             QStringLiteral("Le PDF a bien été écrit :\n%1\n\nMais il n'a pas pu être ouvert.\n%2")
                                 .arg(QDir::toNativeSeparators(chemin), message));
}

bool MainWindow::printFinal(PrintEditorDialog *dlg)
{
    const int destination = demanderDestination(this);
    if (destination == ApresImpressionDialog::ANNULER)
        return false;
    const bool versPdf = destination == ApresImpressionDialog::PDF;

    QList<PaperItem *> papers = dlg->papers();
    std::sort(papers.begin(), papers.end(), [](PaperItem *a, PaperItem *b) {
        return std::make_pair(a->pos().y(), a->pos().x()) < std::make_pair(b->pos().y(), b->pos().x());
    });

    QPrinter printer(QPrinter::HighResolution);
    // Le format de sortie se règle AVANT la mise en page : en changer ensuite
    // remettrait l'imprimante à ses valeurs d'usine.
    QString chemin;
    if (versPdf) {
        chemin = fichierPdf();
        if (chemin.isEmpty())
            return false;
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setOutputFileName(chemin);
    }
    printer.setFullPage(true);

    QPageLayout layout = printer.pageLayout();
    const bool premierPortrait = papers.isEmpty() || papers.first()->isPortrait();
    layout.setOrientation(premierPortrait ? QPageLayout::Portrait : QPageLayout::Landscape);
    if (!papers.isEmpty()) {
        // La feuille de travail donne le format du papier, ramené DEBOUT.
        const QRectF r = papers.first()->rect();
        const double petit = qMin(r.width(), r.height()), grand = qMax(r.width(), r.height());
        layout.setPageSize(QPageSize(QSizeF(petit, grand), QPageSize::Point, QString(), QPageSize::FuzzyMatch));
    }
    printer.setPageLayout(layout);
    if (!papers.isEmpty())
        printer.setFromTo(1, int(papers.size()));

    // Vers un PDF, rien à demander de plus.
    if (!versPdf) {
        QPrintDialog boite(&printer, this);
        if (boite.exec() != QDialog::Accepted)
            return false;
    }

    QGraphicsScene *scene = dlg->scene();
    const int premiere = printer.fromPage() > 0 ? printer.fromPage() : 1;
    const int derniere = printer.toPage() > 0 ? printer.toPage() : int(papers.size());
    const QList<PaperItem *> selection = papers.mid(premiere - 1, derniere - premiere + 1);
    if (selection.isEmpty())
        return false;

    // Les bordures d'écran des feuilles ne s'impriment pas.
    QList<QPair<PaperItem *, QPen>> stylos;
    for (PaperItem *p : std::as_const(papers)) {
        stylos.append({p, p->pen()});
        p->setPen(Qt::NoPen);
    }
    {
        QPainter painter(&printer);
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setRenderHint(QPainter::SmoothPixmapTransform, true);
        painter.setRenderHint(QPainter::TextAntialiasing, true);
        for (int i = 0; i < selection.size(); ++i) {
            if (i)
                printer.newPage();
            const QRectF page = printer.pageRect(QPrinter::DevicePixel);
            // La source est exactement la feuille : ce qui déborde n'est pas imprimé.
            scene->render(&painter, page, selection[i]->scenePageRect());
        }
    } // le fichier n'existe vraiment qu'une fois le peintre refermé
    for (const auto &[p, stylo] : stylos)
        p->setPen(stylo);
    if (versPdf)
        montrerLePdf(chemin);
    return true;
}
