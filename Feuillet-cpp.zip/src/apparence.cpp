#include "apparence.h"

#include "config.h"
#include "theme.h"

#include <QApplication>
#include <QColor>
#include <QEvent>
#include <QObject>
#include <QOperatingSystemVersion>
#include <QWidget>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <dwmapi.h>
#endif

namespace apparence {

namespace {
constexpr unsigned DWMWA_MODE_SOMBRE = 20;   // Windows 10 1903 et au-delà
constexpr unsigned DWMWA_COULEUR_FOND = 35;  // Windows 11 seulement
constexpr unsigned DWMWA_COULEUR_TEXTE = 36; // Windows 11 seulement

int g_couleurAcceptee = -1; // -1 inconnu, 0 non, 1 oui
QObject *g_poseur = nullptr;

#ifdef Q_OS_WIN
bool poserAttribut(HWND hwnd, unsigned attribut, int valeur)
{
    const HRESULT rc = DwmSetWindowAttribute(hwnd, attribut, &valeur, sizeof(valeur));
    return rc == S_OK;
}
#endif

class Poseur : public QObject {
public:
    using QObject::QObject;
    bool eventFilter(QObject *objet, QEvent *e) override
    {
        // Show et non Create : la poignée système n'existe pas avant.
        if (e->type() == QEvent::Show && objet->isWidgetType()) {
            auto *w = static_cast<QWidget *>(objet);
            if (w->isWindow())
                appliquerTitlebar(w);
        }
        return false;
    }
};
} // namespace

QString titlebarDefaut() { return theme::BG_WIN; }
QString msgPoliceDefaut() { return theme::FONT_UI; }
QString msgCouleurDefaut() { return theme::FG; }

QString couleurTitlebar()
{
    const QString c = config::lireTexte(QStringLiteral("titlebar_color"), titlebarDefaut());
    return c.isEmpty() ? titlebarDefaut() : c;
}

PoliceMessages policeMessages()
{
    PoliceMessages p;
    p.famille = config::lireTexte(QStringLiteral("msg_font"), msgPoliceDefaut());
    if (p.famille.isEmpty())
        p.famille = msgPoliceDefaut();
    const QJsonValue v = config::lire(QStringLiteral("msg_font_size"), MSG_TAILLE_DEFAUT);
    int taille = MSG_TAILLE_DEFAUT;
    if (v.isDouble())
        taille = int(v.toDouble());
    else if (v.isString())
        taille = v.toString().toInt();
    if (taille <= 0)
        taille = MSG_TAILLE_DEFAUT;
    p.taille = qBound(MSG_TAILLE_MIN, taille, MSG_TAILLE_MAX);
    p.couleur = config::lireTexte(QStringLiteral("msg_font_color"), msgCouleurDefaut());
    if (p.couleur.isEmpty())
        p.couleur = msgCouleurDefaut();
    return p;
}

bool clair(const QString &hexa)
{
    const QColor c(hexa);
    if (!c.isValid())
        return false;
    return (0.299 * c.red() + 0.587 * c.green() + 0.114 * c.blue()) > 140;
}

bool couleurAcceptee()
{
#ifdef Q_OS_WIN
    if (g_couleurAcceptee >= 0)
        return g_couleurAcceptee == 1;
    return QOperatingSystemVersion::current()
           >= QOperatingSystemVersion(QOperatingSystemVersion::Windows, 10, 0, 22000);
#else
    return false;
#endif
}

bool appliquerTitlebar(QWidget *fenetre)
{
#ifdef Q_OS_WIN
    if (!fenetre)
        return false;
    HWND hwnd = reinterpret_cast<HWND>(fenetre->winId());
    if (!hwnd)
        return false;
    const QString hexa = couleurTitlebar();
    const bool estClair = clair(hexa);
    // Windows 10 : la couleur est refusée, mais le clair/sombre est accepté.
    poserAttribut(hwnd, DWMWA_MODE_SOMBRE, estClair ? 0 : 1);
    const QColor c(hexa);
    if (!c.isValid())
        return false;
    // COLORREF s'écrit à l'envers : 0x00BBGGRR.
    const int colorref = (c.blue() << 16) | (c.green() << 8) | c.red();
    const bool ok = poserAttribut(hwnd, DWMWA_COULEUR_FOND, colorref);
    g_couleurAcceptee = ok ? 1 : 0;
    if (ok)
        poserAttribut(hwnd, DWMWA_COULEUR_TEXTE, estClair ? 0x00000000 : 0x00FFFFFF);
    return ok;
#else
    Q_UNUSED(fenetre);
    return false;
#endif
}

void installer(QApplication *app)
{
#ifdef Q_OS_WIN
    if (g_poseur || !app)
        return;
    g_poseur = new Poseur(app);
    app->installEventFilter(g_poseur);
#else
    Q_UNUSED(app);
#endif
}

void reappliquerTitlebar()
{
#ifdef Q_OS_WIN
    for (QWidget *w : QApplication::topLevelWidgets())
        if (w->isVisible())
            appliquerTitlebar(w);
#endif
}

QString qssMessages()
{
    const PoliceMessages p = policeMessages();
    return QStringLiteral(
               "\nQMessageBox { font-family: \"%1\"; font-size: %2pt; }"
               "\nQMessageBox QLabel { font-family: \"%1\"; font-size: %2pt;"
               "  color: %3; background: transparent; }"
               "\nQMessageBox QPushButton { font-family: \"%1\";"
               "  font-size: %4pt;"
               "  min-width: %5px; padding: %6px 14px; }")
        .arg(p.famille)
        .arg(p.taille)
        .arg(p.couleur)
        .arg(qMax(MSG_TAILLE_MIN, p.taille - 1))
        .arg(p.taille * 7)
        .arg(p.taille / 2);
}

void appliquerStyle(QApplication *app)
{
    if (!app)
        return;
    app->setStyleSheet(theme::style() + qssMessages());
}

} // namespace apparence
