#include "ui_helpers.h"

#include <QAbstractButton>
#include <QAbstractItemView>
#include <QApplication>
#include <QColor>
#include <QComboBox>
#include <QEnterEvent>
#include <QGraphicsDropShadowEffect>
#include <QHash>
#include <QMouseEvent>
#include <QSet>
#include <QSlider>
#include <QTabBar>
#include <QWidget>

namespace ui {

void addShadow(QWidget *widget, int blur, int dx, int dy, int opacity)
{
    auto *ombre = new QGraphicsDropShadowEffect(widget);
    ombre->setBlurRadius(blur);
    ombre->setOffset(dx, dy);
    ombre->setColor(QColor(0, 0, 0, opacity));
    widget->setGraphicsEffect(ombre);
}

namespace {

// Tout ce qui se clique et doit donc annoncer la main. Volontairement absents :
// barres de défilement, champs de saisie et compteurs, zone de travail.
bool estCliquable(const QObject *o)
{
    return qobject_cast<const QAbstractButton *>(o) || qobject_cast<const QTabBar *>(o)
           || qobject_cast<const QComboBox *>(o) || qobject_cast<const QSlider *>(o)
           || qobject_cast<const QAbstractItemView *>(o);
}

void poserMain(QWidget *commande)
{
    // La flèche explicite ne compte pas pour une consigne.
    if (commande->testAttribute(Qt::WA_SetCursor)
        && commande->cursor().shape() != Qt::ArrowCursor)
        return;
    commande->setCursor(Qt::PointingHandCursor);
}

class Curseurs : public QObject {
public:
    using QObject::QObject;

    bool eventFilter(QObject *objet, QEvent *e) override
    {
        const QEvent::Type t = e->type();
        if (t == QEvent::Polish) {
            if (estCliquable(objet))
                poserMain(static_cast<QWidget *>(objet));
        } else if (t == QEvent::Enter) {
            if (estCliquable(objet)) {
                auto *w = static_cast<QWidget *>(objet);
                if (!w->isEnabled())
                    preterPour(w);
            } else if (objet->isWidgetType()) {
                auto *w = static_cast<QWidget *>(objet);
                auto *ee = dynamic_cast<QEnterEvent *>(e);
                if (ee && w->isEnabled() && hebergeDuGrise(w)) {
                    pister(w);
                    if (griseeSous(w, ee->position().toPoint()))
                        preter(w);
                }
            }
        } else if (t == QEvent::MouseMove) {
            if (estCliquable(objet)) {
                auto *w = static_cast<QWidget *>(objet);
                if (!w->isEnabled())
                    preterPour(w);
            } else if (objet->isWidgetType()) {
                auto *w = static_cast<QWidget *>(objet);
                if (m_pistes.contains(w)) {
                    const QPoint pos = static_cast<QMouseEvent *>(e)->position().toPoint();
                    if (griseeSous(w, pos))
                        preter(w);
                    else
                        rendre(w);
                }
            }
        } else if (t == QEvent::Leave) {
            if (estCliquable(objet)) {
                rendrePour(static_cast<QWidget *>(objet));
            } else if (objet->isWidgetType()) {
                auto *w = static_cast<QWidget *>(objet);
                rendre(w);
                depister(w);
            }
        }
        return false;
    }

private:
    struct Etat {
        bool consigne;
        Qt::CursorShape forme;
    };
    QHash<QWidget *, Etat> m_prets;       // hôte -> état d'avant
    QHash<QWidget *, bool> m_pistes;      // hôte -> écoutait déjà les mouvements
    QHash<QWidget *, QWidget *> m_porteurs; // commande grisée -> hôte prêteur
    QSet<QObject *> m_branches;

    void suivre(QWidget *w)
    {
        if (m_branches.contains(w))
            return;
        m_branches.insert(w);
        connect(w, &QObject::destroyed, this, [this](QObject *o) { oublier(o); });
    }

    void oublier(QObject *o)
    {
        m_branches.remove(o);
        auto *w = static_cast<QWidget *>(o);
        m_prets.remove(w);
        m_pistes.remove(w);
        if (m_porteurs.contains(w)) {
            QWidget *hote = m_porteurs.take(w);
            rendre(hote);
        }
        // Un hôte détruit ne doit plus être référencé par une commande grisée.
        for (auto it = m_porteurs.begin(); it != m_porteurs.end();) {
            if (it.value() == w)
                it = m_porteurs.erase(it);
            else
                ++it;
        }
    }

    void preter(QWidget *hote)
    {
        if (m_prets.contains(hote))
            return;
        suivre(hote);
        m_prets.insert(hote, Etat{hote->testAttribute(Qt::WA_SetCursor), hote->cursor().shape()});
        hote->setCursor(Qt::PointingHandCursor);
    }

    void rendre(QWidget *hote)
    {
        if (!m_prets.contains(hote))
            return;
        const Etat etat = m_prets.take(hote);
        // L'état NOTÉ est remis, sans passer par unsetCursor (qui laisse
        // WA_SetCursor levé sur une fenêtre de premier niveau).
        hote->setCursor(etat.forme);
        if (!etat.consigne)
            hote->setAttribute(Qt::WA_SetCursor, false);
    }

    void preterPour(QWidget *grisee)
    {
        if (m_porteurs.contains(grisee))
            return;
        QWidget *hote = grisee->parentWidget();
        while (hote && !hote->isEnabled())
            hote = hote->parentWidget();
        if (!hote)
            return;
        suivre(grisee);
        m_porteurs.insert(grisee, hote);
        preter(hote);
    }

    void rendrePour(QWidget *grisee)
    {
        if (!m_porteurs.contains(grisee))
            return;
        QWidget *hote = m_porteurs.take(grisee);
        rendre(hote);
    }

    QWidget *griseeSous(QWidget *hote, const QPoint &pos) const
    {
        QWidget *enfant = hote->childAt(pos);
        while (enfant && enfant != hote) {
            if (estCliquable(enfant))
                return enfant->isEnabled() ? nullptr : enfant;
            enfant = enfant->parentWidget();
        }
        return nullptr;
    }

    bool hebergeDuGrise(QWidget *hote) const
    {
        const auto enfants = hote->findChildren<QWidget *>();
        for (QWidget *w : enfants)
            if (estCliquable(w) && !w->isEnabled() && w->isVisible())
                return true;
        return false;
    }

    void pister(QWidget *hote)
    {
        if (m_pistes.contains(hote))
            return;
        suivre(hote);
        m_pistes.insert(hote, hote->hasMouseTracking());
        hote->setMouseTracking(true);
    }

    void depister(QWidget *hote)
    {
        if (!m_pistes.contains(hote))
            return;
        const bool avant = m_pistes.take(hote);
        if (!avant)
            hote->setMouseTracking(false);
    }
};

Curseurs *g_curseurs = nullptr;

} // namespace

void poserCurseurs(QApplication *app)
{
    if (g_curseurs || !app)
        return;
    g_curseurs = new Curseurs(app);
    app->installEventFilter(g_curseurs);
    const auto existants = QApplication::allWidgets();
    for (QWidget *w : existants)
        if (estCliquable(w))
            poserMain(w);
}

} // namespace ui
