#include "barre_titre.h"

#include "apparence.h"
#include "theme.h"

#include <QApplication>
#include <QEvent>
#include <QHBoxLayout>
#include <QLabel>
#include <QMainWindow>
#include <QMouseEvent>
#include <QPainter>
#include <QPen>
#include <QPushButton>
#include <QVBoxLayout>

namespace {

const char *P_BARRE = "feuillet_barre";
const char *P_CONTENU = "feuillet_contenu";
const char *P_CADRE = "feuillet_cadre";
const char *P_MARGE = "feuillet_marge";
const char *P_POIGNEE = "feuillet_poignee";

QObject *objetDe(QWidget *f, const char *nom)
{
    if (!f)
        return nullptr;
    return f->property(nom).value<QObject *>();
}

QString melange(const QString &hexa, const QString &vers, double part)
{
    const QColor a(hexa), b(vers);
    auto m = [part](int x, int y) { return int(x + (y - x) * part); };
    return QColor(m(a.red(), b.red()), m(a.green(), b.green()), m(a.blue(), b.blue())).name();
}

QLayout *gabaritDe(QWidget *fenetre)
{
    if (auto *mw = qobject_cast<QMainWindow *>(fenetre)) {
        QWidget *central = mw->centralWidget();
        return central ? central->layout() : nullptr;
    }
    return fenetre->layout();
}

// ---------------------------------------------------------------------------
// Redimensionnement par les bords
// ---------------------------------------------------------------------------
class Redimensionneur : public QObject {
public:
    explicit Redimensionneur(QWidget *fenetre) : QObject(fenetre), f(fenetre)
    {
        bande = cadre::margeCadre(fenetre);
        fenetre->setMouseTracking(true);
    }

    bool eventFilter(QObject *objet, QEvent *e) override
    {
        if (objet != f || f->isMaximized())
            return false;
        const QEvent::Type t = e->type();
        if (t == QEvent::MouseButtonPress) {
            auto *me = static_cast<QMouseEvent *>(e);
            if (me->button() == Qt::LeftButton) {
                const int s = sensEn(me->position().toPoint());
                if (s) {
                    sens = s;
                    origine = me->globalPosition().toPoint();
                    geo = f->geometry();
                    return true;
                }
            }
        } else if (t == QEvent::MouseMove) {
            auto *me = static_cast<QMouseEvent *>(e);
            if (sens && (me->buttons() & Qt::LeftButton)) {
                suivre(me->globalPosition().toPoint());
                return true;
            }
            if (!me->buttons())
                f->setCursor(curseur(sensEn(me->position().toPoint())));
        } else if (t == QEvent::MouseButtonRelease) {
            if (sens) {
                sens = 0;
                f->unsetCursor();
                return true;
            }
        } else if (t == QEvent::Leave) {
            f->unsetCursor();
        }
        return false;
    }

private:
    // Bits : 1 gauche, 2 droite, 4 haut, 8 bas. Les bords qui ne mèneraient à
    // rien (dimension figée) sont retirés.
    int sensEn(const QPoint &p) const
    {
        const int b = bande;
        int s = 0;
        if (p.x() <= b) s |= 1;
        if (p.x() >= f->width() - b) s |= 2;
        if (p.y() <= b) s |= 4;
        if (p.y() >= f->height() - b) s |= 8;
        if (f->minimumHeight() == f->maximumHeight()) s &= 3;
        if (f->minimumWidth() == f->maximumWidth()) s &= 12;
        return s;
    }

    static Qt::CursorShape curseur(int s)
    {
        if (s == 5 || s == 10) return Qt::SizeFDiagCursor;
        if (s == 6 || s == 9) return Qt::SizeBDiagCursor;
        if (s & 3) return Qt::SizeHorCursor;
        if (s & 12) return Qt::SizeVerCursor;
        return Qt::ArrowCursor;
    }

    void suivre(const QPoint &point)
    {
        const QPoint d = point - origine;
        const QRect g = f->geometry();
        int x = g.x(), y = g.y(), l = g.width(), h = g.height();
        const QSize mini = f->minimumSizeHint();
        const int lmin = qMax(qMax(f->minimumWidth(), mini.width()), 200);
        const int hmin = qMax(qMax(f->minimumHeight(), mini.height()), cadre::HAUTEUR + 40);
        if (sens & 1) {
            l = qMax(lmin, geo.width() - d.x());
            x = geo.x() + geo.width() - l;
        }
        if (sens & 2)
            l = qMax(lmin, geo.width() + d.x());
        if (sens & 4) {
            h = qMax(hmin, geo.height() - d.y());
            y = geo.y() + geo.height() - h;
        }
        if (sens & 8)
            h = qMax(hmin, geo.height() + d.y());
        f->setGeometry(x, y, l, h);
    }

    QWidget *f;
    int bande;
    int sens = 0;
    QPoint origine;
    QRect geo;
};

// ---------------------------------------------------------------------------
// Masque du CONTENU à la forme du cadre (jamais le cadre lui-même)
// ---------------------------------------------------------------------------
class MasqueArrondi : public QObject {
public:
    MasqueArrondi(QWidget *contenu, int rayon) : QObject(contenu), m_contenu(contenu), m_rayon(rayon)
    {
        contenu->installEventFilter(this);
    }

    void appliquer()
    {
        const QSize taille = m_contenu->size();
        if (taille == m_taille)
            return;
        m_taille = taille;
        m_contenu->setMask(cadre::regionArrondie(m_contenu->rect(), m_rayon));
    }

    bool eventFilter(QObject *objet, QEvent *e) override
    {
        if (objet == m_contenu && (e->type() == QEvent::Resize || e->type() == QEvent::Show))
            appliquer();
        return false;
    }

private:
    QWidget *m_contenu;
    int m_rayon;
    QSize m_taille;
};

// ---------------------------------------------------------------------------
// L'ombre douce portée sous la fenêtre, peinte dans la couronne transparente.
// ---------------------------------------------------------------------------
class Ombre : public QWidget {
public:
    Ombre(QWidget *hote, QWidget *cadreW, int rayon) : QWidget(hote), m_cadre(cadreW), m_rayon(rayon)
    {
        setAttribute(Qt::WA_TransparentForMouseEvents, true);
        setAttribute(Qt::WA_NoSystemBackground, true);
        setStyleSheet(QStringLiteral("background: transparent;"));
        hote->installEventFilter(this);
        suivre();
        lower();
    }

    void suivre()
    {
        setGeometry(parentWidget()->rect());
        lower();
    }

protected:
    bool eventFilter(QObject *objet, QEvent *e) override
    {
        if (objet == parentWidget() && (e->type() == QEvent::Resize || e->type() == QEvent::Show))
            suivre();
        return false;
    }

    void paintEvent(QPaintEvent *) override
    {
        const QRect geo = m_cadre->geometry();
        if (geo.isEmpty())
            return;
        const int marge = qMin(qMin(geo.x(), geo.y()),
                               qMin(width() - geo.right() - 1, height() - geo.bottom() - 1));
        if (marge <= 0)
            return;
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        p.setClipRegion(QRegion(rect()).subtracted(cadre::regionArrondie(geo, m_rayon)));
        p.setPen(Qt::NoPen);
        const int portee = qMin(cadre::OMBRE_PORTEE, marge);
        for (int i = portee; i > 0; --i) {
            const double part = 1.0 - i / (portee + 1.0);
            const int alpha = int(cadre::OMBRE_NOIR * part * part);
            if (alpha <= 0)
                continue;
            p.setBrush(QColor(0, 0, 0, alpha));
            const QRect r = geo.adjusted(-i, -i + cadre::OMBRE_CHUTE, i, i + cadre::OMBRE_CHUTE);
            p.drawRoundedRect(r, m_rayon + i, m_rayon + i);
        }
    }

private:
    QWidget *m_cadre;
    int m_rayon;
};

} // namespace

// ===========================================================================
// BarreTitre
// ===========================================================================
BarreTitre::BarreTitre(QWidget *fenetre, bool reduire, bool agrandir, int arrondi)
    : QWidget(fenetre), m_fenetre(fenetre), m_arrondi(arrondi)
{
    setFixedHeight(cadre::HAUTEUR);
    // Une sous-classe de QWidget ne peint pas le fond de sa feuille de style
    // sans cet attribut (sous Windows).
    setAttribute(Qt::WA_StyledBackground, true);

    const QString fond = apparence::couleurTitlebar();
    const QString encre = apparence::clair(fond) ? QStringLiteral("#101014") : QStringLiteral("#e8ecf6");
    peindreFond(fond);

    auto *rang = new QHBoxLayout(this);
    rang->setContentsMargins(10, 0, 0, 0);
    rang->setSpacing(8);

    m_icone = new QLabel(this);
    const QIcon icone = fenetre->windowIcon();
    if (!icone.isNull())
        m_icone->setPixmap(icone.pixmap(18, 18));
    m_icone->setStyleSheet(QStringLiteral("background: transparent;"));
    rang->addWidget(m_icone);

    m_titre = new QLabel(fenetre->windowTitle(), this);
    m_titre->setStyleSheet(
        QStringLiteral("color: %1; background: transparent; font-size: 10pt;").arg(encre));
    rang->addWidget(m_titre);
    rang->addStretch();
    connect(fenetre, &QWidget::windowTitleChanged, m_titre, &QLabel::setText);

    if (reduire) {
        QPushButton *b = bouton(QStringLiteral("─"), fond, encre);
        connect(b, &QPushButton::clicked, fenetre, [fenetre]() { fenetre->showMinimized(); });
        rang->addWidget(b);
    }
    if (agrandir) {
        m_btnAgrandir = bouton(QStringLiteral("□"), fond, encre);
        connect(m_btnAgrandir, &QPushButton::clicked, this, [this]() { basculer(); });
        rang->addWidget(m_btnAgrandir);
    }
    QPushButton *fermer = bouton(QStringLiteral("✕"), fond, encre, true);
    connect(fermer, &QPushButton::clicked, fenetre, [fenetre]() { fenetre->close(); });
    rang->addWidget(fermer);
    arrondirDernier(fond, encre);
}

void BarreTitre::habiller(QPushButton *btn, const QString &fond, const QString &encre, bool rouge,
                          int coin)
{
    const QString survol = rouge ? cadre::ROUGE_FERMER : melange(fond, encre, 0.18);
    const QString appui = melange(survol, QStringLiteral("#000000"), 0.25);
    const QString arrondi = coin ? QStringLiteral(" border-top-right-radius: %1px;").arg(coin) : QString();
    btn->setStyleSheet(QStringLiteral("QPushButton { background: %1; color: %2;"
                                      "  border: none; border-radius: 0;%3"
                                      "  font-size: 11pt; padding: 0; }"
                                      "QPushButton:hover { background: %4;"
                                      "  color: %5; }"
                                      "QPushButton:pressed { background: %6; }")
                           .arg(fond, encre, arrondi, survol,
                                rouge ? QStringLiteral("#ffffff") : encre, appui));
}

QPushButton *BarreTitre::bouton(const QString &glyphe, const QString &fond, const QString &encre,
                                bool rouge)
{
    auto *btn = new QPushButton(glyphe, this);
    btn->setFixedSize(46, cadre::HAUTEUR);
    btn->setFocusPolicy(Qt::NoFocus);
    habiller(btn, fond, encre, rouge);
    m_boutons.append({btn, rouge});
    return btn;
}

void BarreTitre::arrondirDernier(const QString &fond, const QString &encre)
{
    if (!m_arrondi || m_boutons.isEmpty())
        return;
    const Bouton &b = m_boutons.last();
    habiller(b.btn, fond, encre, b.rouge, m_arrondi);
}

void BarreTitre::peindreFond(const QString &fond)
{
    const int r = m_arrondi;
    const QString coins = r ? QStringLiteral(" border-top-left-radius: %1px;"
                                             " border-top-right-radius: %1px;")
                                  .arg(r)
                            : QString();
    setStyleSheet(QStringLiteral("BarreTitre { background: %1;%2 }").arg(fond, coins));
}

void BarreTitre::recolorer()
{
    const QString fond = apparence::couleurTitlebar();
    const QString encre = apparence::clair(fond) ? QStringLiteral("#101014") : QStringLiteral("#e8ecf6");
    peindreFond(fond);
    m_titre->setStyleSheet(
        QStringLiteral("color: %1; background: transparent; font-size: 10pt;").arg(encre));
    for (const Bouton &b : m_boutons)
        habiller(b.btn, fond, encre, b.rouge);
    arrondirDernier(fond, encre);
}

void BarreTitre::basculer()
{
    if (m_fenetre->isMaximized())
        m_fenetre->showNormal();
    else
        m_fenetre->showMaximized();
    marges();
}

void BarreTitre::marges()
{
    // Agrandie, la fenêtre perd sa couronne (et donc son ombre).
    QLayout *gabarit = gabaritDe(m_fenetre);
    if (!gabarit)
        return;
    const int marge = cadre::margeCadre(m_fenetre);
    const int b = m_fenetre->isMaximized() ? 0 : marge;
    gabarit->setContentsMargins(b, b, b, b);
    if (m_btnAgrandir)
        m_btnAgrandir->setText(m_fenetre->isMaximized() ? QStringLiteral("❐") : QStringLiteral("□"));
}

void BarreTitre::mousePressEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton) {
        m_presse = true;
        m_depart = e->globalPosition().toPoint();
    }
    QWidget::mousePressEvent(e);
}

void BarreTitre::mouseMoveEvent(QMouseEvent *e)
{
    if (!m_presse || !(e->buttons() & Qt::LeftButton))
        return;
    const QPoint point = e->globalPosition().toPoint();
    if (m_fenetre->isMaximized()) {
        // Rétablir puis reprendre la fenêtre sous le curseur, à la même
        // proportion horizontale — le geste de Windows.
        const double part = e->position().x() / qMax(1, width());
        m_fenetre->showNormal();
        marges();
        const int largeur = m_fenetre->width();
        m_fenetre->move(point.x() - int(largeur * part), point.y() - cadre::HAUTEUR / 2);
        m_depart = point;
        return;
    }
    const QPoint delta = point - m_depart;
    m_fenetre->move(m_fenetre->pos() + delta);
    m_depart = point;
}

void BarreTitre::mouseReleaseEvent(QMouseEvent *e)
{
    m_presse = false;
    QWidget::mouseReleaseEvent(e);
}

void BarreTitre::mouseDoubleClickEvent(QMouseEvent *e)
{
    if (m_btnAgrandir && e->button() == Qt::LeftButton)
        basculer();
}

// ===========================================================================
// PoigneeTaille
// ===========================================================================
PoigneeTaille::PoigneeTaille(QWidget *fenetre, QWidget *hote) : QWidget(hote), m_fenetre(fenetre)
{
    setFixedSize(COTE, COTE);
    setCursor(Qt::SizeFDiagCursor);
    setToolTip(QStringLiteral("Tirer pour redimensionner la fenêtre"));
    setAttribute(Qt::WA_TranslucentBackground);
    hote->installEventFilter(this);
    replacer();
    raise();
}

void PoigneeTaille::replacer()
{
    QWidget *hote = parentWidget();
    if (!hote)
        return;
    move(hote->width() - COTE - MARGE, hote->height() - COTE - MARGE);
    raise();
}

bool PoigneeTaille::eventFilter(QObject *objet, QEvent *e)
{
    if (objet == parentWidget() && e->type() == QEvent::Resize)
        replacer();
    return false;
}

void PoigneeTaille::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, false);
    p.setPen(QPen(QColor(cadre::LISERE), 1));
    const int c = COTE - 2;
    for (int retrait : {0, 4, 8})
        p.drawLine(c - retrait, c, c, c - retrait);
}

void PoigneeTaille::mousePressEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton && !m_fenetre->isMaximized()) {
        m_tire = true;
        m_origine = e->globalPosition().toPoint();
        m_geo = m_fenetre->geometry();
        e->accept();
    }
}

void PoigneeTaille::mouseMoveEvent(QMouseEvent *e)
{
    if (!m_tire)
        return;
    const QPoint d = e->globalPosition().toPoint() - m_origine;
    const QSize mini = m_fenetre->minimumSizeHint();
    const int lmin = qMax(qMax(m_fenetre->minimumWidth(), mini.width()), 200);
    const int hmin = qMax(qMax(m_fenetre->minimumHeight(), mini.height()), cadre::HAUTEUR + 40);
    const int largeur = qMin(qMax(lmin, m_geo.width() + d.x()), m_fenetre->maximumWidth());
    const int hauteur = qMin(qMax(hmin, m_geo.height() + d.y()), m_fenetre->maximumHeight());
    m_fenetre->resize(largeur, hauteur);
    e->accept();
}

void PoigneeTaille::mouseReleaseEvent(QMouseEvent *e)
{
    m_tire = false;
    e->accept();
}

// ===========================================================================
// Fonctions du module
// ===========================================================================
namespace cadre {

QRegion regionArrondie(const QRect &rect, int rayon)
{
    const int x = rect.x(), y = rect.y(), w = rect.width(), h = rect.height();
    const int r = qMax(0, qMin(rayon, qMin(w / 2, h / 2)));
    if (r == 0)
        return QRegion(rect);
    QRegion region(x + r, y, w - 2 * r, h);
    region = region.united(QRegion(x, y + r, w, h - 2 * r));
    const int d = 2 * r;
    const QPoint coins[4] = {{x, y}, {x + w - d, y}, {x, y + h - d}, {x + w - d, y + h - d}};
    for (const QPoint &c : coins)
        region = region.united(QRegion(c.x(), c.y(), d, d, QRegion::Ellipse));
    return region;
}

BarreTitre *barreDe(QWidget *fenetre)
{
    return qobject_cast<BarreTitre *>(objetDe(fenetre, P_BARRE));
}

QWidget *contenuDe(QWidget *fenetre)
{
    return qobject_cast<QWidget *>(objetDe(fenetre, P_CONTENU));
}

QWidget *cadreDe(QWidget *fenetre)
{
    return qobject_cast<QWidget *>(objetDe(fenetre, P_CADRE));
}

int margeCadre(QWidget *fenetre)
{
    const QVariant v = fenetre ? fenetre->property(P_MARGE) : QVariant();
    return v.isValid() ? v.toInt() : BORD;
}

bool poser(QWidget *fenetre, bool reduire, bool agrandir, QVBoxLayout *gabarit, int arrondi)
{
    const bool impose = gabarit != nullptr;
    QVBoxLayout *colonne = impose ? gabarit : qobject_cast<QVBoxLayout *>(gabaritDe(fenetre));
    if (!colonne)
        return false;
    if (barreDe(fenetre))
        return true;

    fenetre->setWindowFlag(Qt::FramelessWindowHint, true);
    auto *barre = new BarreTitre(fenetre, reduire, agrandir, arrondi);
    colonne->insertWidget(0, barre);
    if (!impose)
        colonne->setContentsMargins(BORD, BORD, BORD, BORD);

    fenetre->setProperty(P_BARRE, QVariant::fromValue<QObject *>(barre));
    auto *redim = new Redimensionneur(fenetre);
    fenetre->installEventFilter(redim);
    return true;
}

void recolorerTout()
{
    for (QWidget *w : QApplication::topLevelWidgets())
        if (BarreTitre *b = barreDe(w))
            b->recolorer();
}

bool poserCadre(QWidget *fenetre, bool reduire, bool agrandir, const QString &fond, int rayon,
                int marge, bool ombre)
{
    auto *ancien = qobject_cast<QVBoxLayout *>(gabaritDe(fenetre));
    if (!ancien)
        return false;
    if (barreDe(fenetre))
        return true;

    QWidget *hote = fenetre;
    if (auto *mw = qobject_cast<QMainWindow *>(fenetre))
        hote = mw->centralWidget();

    // L'hôte ne peint plus rien : c'est le cadre qui a la couleur.
    hote->setObjectName(QStringLiteral("hoteCadre"));
    hote->setStyleSheet(QStringLiteral("#hoteCadre { background: transparent; }"));
    const QString classe = QString::fromLatin1(fenetre->metaObject()->className());
    if (hote != fenetre)
        fenetre->setStyleSheet(fenetre->styleSheet()
                               + QStringLiteral("\n%1 { background: transparent; }").arg(classe));
    else
        fenetre->setStyleSheet(QStringLiteral("%1 { background: transparent; }").arg(classe));
    fenetre->setAttribute(Qt::WA_TranslucentBackground, true);

    auto *cadreW = new QWidget(hote);
    cadreW->setObjectName(QStringLiteral("cadreFeuillet"));
    cadreW->setStyleSheet(QStringLiteral("#cadreFeuillet { background: %1;"
                                         " border: 1px solid %2; border-radius: %3px; }")
                              .arg(fond.isEmpty() ? theme::BG_WIN : fond, LISERE)
                              .arg(rayon));

    // Le contenu d'origine garde SON gabarit : il déménage dans un porteur.
    auto *contenu = new QWidget(cadreW);
    contenu->setObjectName(QStringLiteral("contenuCadre"));
    contenu->setStyleSheet(QStringLiteral("#contenuCadre { background: transparent; }"));
    contenu->setLayout(ancien);

    auto *colonne = new QVBoxLayout(cadreW);
    colonne->setContentsMargins(1, 1, 1, 1); // dedans le liseré, jamais dessus
    colonne->setSpacing(0);
    colonne->addWidget(contenu);

    auto *racine = new QVBoxLayout(hote);
    racine->setContentsMargins(marge, marge, marge, marge);
    racine->setSpacing(0);
    racine->addWidget(cadreW);

    fenetre->setProperty(P_CADRE, QVariant::fromValue<QObject *>(cadreW));
    fenetre->setProperty(P_CONTENU, QVariant::fromValue<QObject *>(contenu));
    fenetre->setProperty(P_MARGE, marge);
    new MasqueArrondi(contenu, rayon - 1);
    if (ombre)
        new Ombre(hote, cadreW, rayon);
    return poser(fenetre, reduire, agrandir, colonne, rayon - 1);
}

PoigneeTaille *poserPoignee(QWidget *fenetre)
{
    QWidget *hote = contenuDe(fenetre);
    if (!hote)
        return nullptr;
    auto *p = new PoigneeTaille(fenetre, hote);
    fenetre->setProperty(P_POIGNEE, QVariant::fromValue<QObject *>(p));
    return p;
}

} // namespace cadre
