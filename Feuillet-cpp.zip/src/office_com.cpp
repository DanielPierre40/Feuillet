#include "office_com.h"

#include "workers.h"

#include <QDir>
#include <QFileInfo>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <objbase.h>
#include <oleauto.h>

#include <string>
#include <utility>
#include <vector>

namespace office {

namespace {

// --- petites briques VARIANT ------------------------------------------------
VARIANT vBool(bool b)
{
    VARIANT v;
    VariantInit(&v);
    v.vt = VT_BOOL;
    v.boolVal = b ? VARIANT_TRUE : VARIANT_FALSE;
    return v;
}

VARIANT vInt(int n)
{
    VARIANT v;
    VariantInit(&v);
    v.vt = VT_I4;
    v.lVal = n;
    return v;
}

VARIANT vTexte(const QString &s)
{
    VARIANT v;
    VariantInit(&v);
    v.vt = VT_BSTR;
    v.bstrVal = SysAllocString(reinterpret_cast<const OLECHAR *>(s.utf16()));
    return v;
}

// Un objet COM tenu par Feuillet, relâché à la sortie de portée.
class Objet {
public:
    Objet() = default;
    explicit Objet(IDispatch *p) : m_p(p) {}
    Objet(const Objet &) = delete;
    Objet &operator=(const Objet &) = delete;
    Objet(Objet &&o) noexcept : m_p(std::exchange(o.m_p, nullptr)) {}
    Objet &operator=(Objet &&o) noexcept
    {
        if (this != &o) {
            relacher();
            m_p = std::exchange(o.m_p, nullptr);
        }
        return *this;
    }
    ~Objet() { relacher(); }
    IDispatch *get() const { return m_p; }
    explicit operator bool() const { return m_p != nullptr; }

    // Appel d'une méthode (ou lecture d'une propriété), arguments nommés et
    // positionnels. Rend false si l'appel échoue.
    bool appeler(const wchar_t *nom, WORD sorte, std::vector<std::pair<std::wstring, VARIANT>> nommes,
                 std::vector<VARIANT> positionnels, VARIANT *resultat = nullptr) const
    {
        if (!m_p)
            return false;
        std::vector<std::wstring> noms;
        noms.push_back(nom);
        for (auto &n : nommes)
            noms.push_back(n.first);
        std::vector<LPOLESTR> ptr;
        for (auto &n : noms)
            ptr.push_back(const_cast<LPOLESTR>(n.c_str()));
        std::vector<DISPID> ids(ptr.size());
        if (FAILED(m_p->GetIDsOfNames(IID_NULL, ptr.data(), UINT(ptr.size()), LOCALE_USER_DEFAULT, ids.data()))) {
            nettoyer(nommes, positionnels);
            return false;
        }
        // Les nommés d'abord (dans l'ordre de leurs identifiants), puis les
        // positionnels à l'envers : c'est la convention d'IDispatch::Invoke.
        std::vector<VARIANT> args;
        std::vector<DISPID> idsNommes;
        for (size_t i = 0; i < nommes.size(); ++i) {
            args.push_back(nommes[i].second);
            idsNommes.push_back(ids[i + 1]);
        }
        for (auto it = positionnels.rbegin(); it != positionnels.rend(); ++it)
            args.push_back(*it);
        DISPPARAMS dp{};
        dp.cArgs = UINT(args.size());
        dp.rgvarg = args.empty() ? nullptr : args.data();
        DISPID put = DISPID_PROPERTYPUT;
        if (sorte & DISPATCH_PROPERTYPUT) {
            dp.cNamedArgs = 1;
            dp.rgdispidNamedArgs = &put;
        } else {
            dp.cNamedArgs = UINT(idsNommes.size());
            dp.rgdispidNamedArgs = idsNommes.empty() ? nullptr : idsNommes.data();
        }
        VARIANT res;
        VariantInit(&res);
        EXCEPINFO exc{};
        const HRESULT hr = m_p->Invoke(ids[0], IID_NULL, LOCALE_USER_DEFAULT, sorte, &dp, &res, &exc, nullptr);
        for (auto &a : args)
            VariantClear(&a);
        if (exc.bstrSource)
            SysFreeString(exc.bstrSource);
        if (exc.bstrDescription)
            SysFreeString(exc.bstrDescription);
        if (exc.bstrHelpFile)
            SysFreeString(exc.bstrHelpFile);
        if (resultat)
            *resultat = res;
        else
            VariantClear(&res);
        return SUCCEEDED(hr);
    }

    bool poser(const wchar_t *propriete, VARIANT valeur) const
    {
        return appeler(propriete, DISPATCH_PROPERTYPUT, {}, {valeur});
    }

    Objet objet(const wchar_t *nom, WORD sorte = DISPATCH_PROPERTYGET | DISPATCH_METHOD,
                std::vector<std::pair<std::wstring, VARIANT>> nommes = {}, std::vector<VARIANT> positionnels = {}) const
    {
        VARIANT res;
        VariantInit(&res);
        if (!appeler(nom, sorte, std::move(nommes), std::move(positionnels), &res))
            return Objet();
        if (res.vt != VT_DISPATCH || !res.pdispVal) {
            VariantClear(&res);
            return Objet();
        }
        return Objet(res.pdispVal); // la référence du VARIANT nous revient
    }

private:
    static void nettoyer(std::vector<std::pair<std::wstring, VARIANT>> &nommes, std::vector<VARIANT> &pos)
    {
        for (auto &n : nommes)
            VariantClear(&n.second);
        for (auto &v : pos)
            VariantClear(&v);
    }
    void relacher()
    {
        if (m_p)
            m_p->Release();
        m_p = nullptr;
    }
    IDispatch *m_p = nullptr;
};

Objet lancer(const wchar_t *progId)
{
    CLSID clsid;
    if (FAILED(CLSIDFromProgID(progId, &clsid)))
        return Objet();
    IDispatch *p = nullptr;
    if (FAILED(CoCreateInstance(clsid, nullptr, CLSCTX_LOCAL_SERVER, IID_IDispatch, reinterpret_cast<void **>(&p))))
        return Objet();
    return Objet(p);
}

QString absolu(const QString &chemin)
{
    return QDir::toNativeSeparators(QFileInfo(chemin).absoluteFilePath());
}

} // namespace

void wordVersPdf(const QString &document, const QString &pdf)
{
    Objet word = lancer(L"Word.Application");
    if (!word)
        throw ErreurChargement{QStringLiteral("Microsoft Word n'a pas pu être lancé.")};
    word.poser(L"Visible", vBool(false));
    word.poser(L"DisplayAlerts", vInt(0));
    bool ok = false;
    {
        Objet docs = word.objet(L"Documents", DISPATCH_PROPERTYGET);
        Objet doc = docs.objet(L"Open", DISPATCH_METHOD,
                               {{L"FileName", vTexte(absolu(document))},
                                {L"ConfirmConversions", vBool(false)},
                                {L"ReadOnly", vBool(true)},
                                {L"AddToRecentFiles", vBool(false)},
                                {L"Revert", vBool(true)}});
        if (doc) {
            ok = doc.appeler(L"ExportAsFixedFormat", DISPATCH_METHOD, {}, {vTexte(absolu(pdf)), vInt(17)});
            doc.appeler(L"Close", DISPATCH_METHOD, {}, {vBool(false)});
        }
    }
    word.appeler(L"Quit", DISPATCH_METHOD, {}, {});
    if (!ok)
        throw ErreurChargement{QStringLiteral("Word n'a pas pu exporter ce document en PDF.")};
}

void excelVersPdf(const QString &classeur, const QString &pdf)
{
    Objet excel = lancer(L"Excel.Application");
    if (!excel)
        throw ErreurChargement{QStringLiteral("Microsoft Excel n'a pas pu être lancé.")};
    excel.poser(L"Visible", vBool(false));
    excel.poser(L"DisplayAlerts", vBool(false));
    excel.poser(L"AskToUpdateLinks", vBool(false));
    bool ok = false;
    {
        Objet livres = excel.objet(L"Workbooks", DISPATCH_PROPERTYGET);
        Objet wb = livres.objet(L"Open", DISPATCH_METHOD,
                                {{L"Filename", vTexte(absolu(classeur))},
                                 {L"UpdateLinks", vBool(false)},
                                 {L"ReadOnly", vBool(true)},
                                 {L"CorruptLoad", vInt(2)}});
        if (wb) {
            ok = wb.appeler(L"ExportAsFixedFormat", DISPATCH_METHOD, {}, {vInt(0), vTexte(absolu(pdf))});
            wb.appeler(L"Close", DISPATCH_METHOD, {}, {vBool(false)});
        }
    }
    excel.appeler(L"Quit", DISPATCH_METHOD, {}, {});
    if (!ok)
        throw ErreurChargement{QStringLiteral("Excel n'a pas pu exporter ce classeur en PDF.")};
}

void powerpointVersPdf(const QString &presentation, const QString &pdf)
{
    Objet ppt = lancer(L"PowerPoint.Application");
    if (!ppt)
        throw ErreurChargement{QStringLiteral("Microsoft PowerPoint n'a pas pu être lancé.")};
    // PowerPoint refuse d'être invisible : on ouvre la présentation sans fenêtre.
    ppt.poser(L"DisplayAlerts", vInt(1)); // ppAlertsNone
    bool ok = false;
    {
        Objet pres = ppt.objet(L"Presentations", DISPATCH_PROPERTYGET);
        Objet prs = pres.objet(L"Open", DISPATCH_METHOD,
                               {{L"FileName", vTexte(absolu(presentation))},
                                {L"ReadOnly", vInt(-1)},
                                {L"Untitled", vInt(-1)},
                                {L"WithWindow", vInt(0)}});
        if (prs) {
            ok = prs.appeler(L"ExportAsFixedFormat", DISPATCH_METHOD, {}, {vTexte(absolu(pdf)), vInt(2)});
            prs.appeler(L"Close", DISPATCH_METHOD, {}, {});
        }
    }
    ppt.appeler(L"Quit", DISPATCH_METHOD, {}, {});
    if (!ok)
        throw ErreurChargement{QStringLiteral("PowerPoint n'a pas pu exporter cette présentation en PDF.")};
}

} // namespace office

#else // hors Windows : pas d'Office

namespace office {
void wordVersPdf(const QString &, const QString &)
{
    throw ErreurChargement{QStringLiteral("Microsoft Office n'est disponible que sous Windows.")};
}
void excelVersPdf(const QString &, const QString &)
{
    throw ErreurChargement{QStringLiteral("Microsoft Office n'est disponible que sous Windows.")};
}
void powerpointVersPdf(const QString &, const QString &)
{
    throw ErreurChargement{QStringLiteral("Microsoft Office n'est disponible que sous Windows.")};
}
} // namespace office

#endif
