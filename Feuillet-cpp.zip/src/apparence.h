// apparence — deux réglages qui débordent du cadre de Qt : la couleur de la
// barre de titre de Windows (DwmSetWindowAttribute) et la police des boîtes
// de message (feuille de style de l'application).
#pragma once

#include <QString>

class QApplication;
class QWidget;

namespace apparence {

QString titlebarDefaut();
inline const int MSG_TAILLE_DEFAUT = 10;
inline const int MSG_TAILLE_MIN = 8;
inline const int MSG_TAILLE_MAX = 24;
QString msgPoliceDefaut();
QString msgCouleurDefaut();

QString couleurTitlebar();

struct PoliceMessages {
    QString famille;
    int taille;
    QString couleur;
};
PoliceMessages policeMessages();

bool clair(const QString &hexa);
bool couleurAcceptee();
bool appliquerTitlebar(QWidget *fenetre);
void installer(QApplication *app);
void reappliquerTitlebar();

QString qssMessages();
void appliquerStyle(QApplication *app);

} // namespace apparence
