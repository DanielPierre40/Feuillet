// version — le numéro de version de Feuillet.
//
// Une seule ligne utile, et c'est voulu : le numéro se change ICI, à la main.
// Il s'affiche dans la fenêtre d'aide (« Version du programme : n° X »).
#pragma once

#define FEUILLET_VERSION "2.0"
