#include "memoire_fenetres.h"

#include "barre_titre.h"
#include "config.h"

#include <QEvent>
#include <QGuiApplication>
#include <QJsonObject>
#include <QPointer>
#include <QRect>
#include <QScreen>
#include <QTimer>
#include <QWidget>

namespace memoire {

namespace {

const QString CLE = QStringLiteral("fenetres");
constexpr int LARGEUR_SAISIE = 120;
constexpr int HAUTEUR_SAISIE = 40;
constexpr int BANDE_TITRE = 160;

bool fiche(const QString &nom, QRect &rect, bool &agrandie)
{
    const QJsonObject toutes = config::lire(CLE).toObject();
    const QJsonValue v = toutes.value(nom);
    if (!v.isObject())
        return false;
    const QJsonObject f = v.toObject();
    for (const char *k : {"x", "y", "l", "h"})
        if (!f.value(QLatin1String(k)).isDouble())
            return false;
    rect = QRect(f.value(QStringLiteral("x")).toInt(), f.value(QStringLiteral("y")).toInt(),
                 f.value(QStringLiteral("l")).toInt(), f.value(QStringLiteral("h")).toInt());
    if (rect.width() < 50 || rect.height() < 50)
        return false; // fiche abîmée
    agrandie = f.value(QStringLiteral("max")).toBool();
    return true;
}

QScreen *ecranDAccueil(const QRect &rect)
{
    const QRect bande(rect.x(), rect.y(), rect.width(), BANDE_TITRE);
    for (QScreen *ecran : QGuiApplication::screens()) {
        const QRect visible = ecran->availableGeometry().intersected(bande);
        if (visible.width() >= LARGEUR_SAISIE && visible.height() >= HAUTEUR_SAISIE)
            return ecran;
    }
    return nullptr;
}

bool appliquer(QWidget *fenetre, const QString &nom)
{
    QRect rect;
    bool agrandie = false;
    if (!fiche(nom, rect, agrandie))
        return false;
    QScreen *ecran = ecranDAccueil(rect);
    if (!ecran) {
        // Position perdue avec l'écran qui la portait : la taille seule.
        const QRect zone = QGuiApplication::primaryScreen()->availableGeometry();
        fenetre->resize(qMin(rect.width(), zone.width()), qMin(rect.height(), zone.height()));
    } else {
        const QRect zone = ecran->availableGeometry();
        rect.setWidth(qMin(rect.width(), zone.width()));
        rect.setHeight(qMin(rect.height(), zone.height()));
        fenetre->setGeometry(rect);
    }
    if (agrandie) {
        // Par la bascule de la barre, une fois la fenêtre montrée : elle seule
        // retire couronne et ombre.
        QPointer<QWidget> f(fenetre);
        QTimer::singleShot(0, fenetre, [f]() {
            if (!f)
                return;
            BarreTitre *barre = cadre::barreDe(f);
            if (barre && !f->isMaximized() && f->isVisible())
                barre->basculer();
        });
    }
    return true;
}

class Memoire : public QObject {
public:
    Memoire(QWidget *fenetre, const QString &nom)
        : QObject(fenetre), m_fenetre(fenetre), m_nom(nom), m_normale(fenetre->geometry())
    {
        fenetre->installEventFilter(this);
    }

    bool eventFilter(QObject *, QEvent *e) override
    {
        const QEvent::Type t = e->type();
        if (t == QEvent::Move || t == QEvent::Resize) {
            if (!m_fenetre->isMaximized() && m_fenetre->isVisible())
                m_normale = m_fenetre->geometry();
        } else if (t == QEvent::Hide) {
            ecrire();
        }
        return false;
    }

private:
    void ecrire()
    {
        QJsonObject f;
        f.insert(QStringLiteral("x"), m_normale.x());
        f.insert(QStringLiteral("y"), m_normale.y());
        f.insert(QStringLiteral("l"), m_normale.width());
        f.insert(QStringLiteral("h"), m_normale.height());
        f.insert(QStringLiteral("max"), m_fenetre->isMaximized());
        QJsonObject toutes = config::lire(CLE).toObject();
        if (toutes.value(m_nom).toObject() == f)
            return; // rien n'a bougé : pas d'écriture
        toutes.insert(m_nom, f);
        config::poser(CLE, toutes);
        config::enregistrer();
    }

    QWidget *m_fenetre;
    QString m_nom;
    QRect m_normale;
};

} // namespace

bool retenir(QWidget *fenetre, const QString &nom)
{
    const bool applique = appliquer(fenetre, nom);
    new Memoire(fenetre, nom); // même durée de vie que la fenêtre
    return applique;
}

} // namespace memoire
