// main_window — l'ACCUEIL de Feuillet : ouvrir, importer un feuillet, et le
// cycle mise en page → impression → fenêtre de fin.
#pragma once

#include "workers.h"

#include <QMainWindow>
#include <atomic>

class LoadingOverlay;
class PrintEditorDialog;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow();

    // Le chargeur universel, utilisable depuis le fil de chargement.
    Chargeur chargeur();
    void direFormatInconnu(QWidget *parent = nullptr);
    void runWithPaths(const QStringList &chemins);

private:
    void ouvrir();
    void importerFeuillet();
    void chargementTermine(const QList<ImageChargee> &images, const QStringList &erreurs);
    void boucleMiseEnPage(PrintEditorDialog *dlg);
    bool apresImpression(PrintEditorDialog *dlg);
    bool printFinal(PrintEditorDialog *dlg);
    QString fichierPdf();
    void montrerLePdf(const QString &chemin);

    LoadingOverlay *m_overlay = nullptr;
    std::atomic<bool> m_formatInconnu{false};
};
