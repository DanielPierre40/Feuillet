// theme — la palette « Encre » de Feuillet et la feuille de style commune.
#pragma once

#include <QString>

namespace theme {

inline const QString TOOLBAR_BG = QStringLiteral("#080808");
inline const QString BG_WIN     = QStringLiteral("#1C2026");
inline const QString BG_MENU    = QStringLiteral("#0c0e12");
inline const QString BG_EDITOR  = QStringLiteral("#14171d");
inline const QString BORDER_COL = QStringLiteral("#404050");
inline const QString SCROLL_BG  = QStringLiteral("#090b0e");
inline const QString SCROLL_FG  = QStringLiteral("#555563");
inline const QString FG         = QStringLiteral("#c6cee6");
inline const QString FG2        = QStringLiteral("#3a3e52");
inline const QString SEL_BG     = QStringLiteral("#1c2855");
inline const QString ACCENT     = QStringLiteral("#5070c8");
inline const QString BG_BTN     = QStringLiteral("#1c1e28");
inline const QString BG_BTN_HOV = QStringLiteral("#252837");
inline const QString BG_BTN_PRS = QStringLiteral("#14161f");
inline const QString BD_BTN     = QStringLiteral("#6a6a80");
inline const QString SCENE_BG   = QStringLiteral("#1a1c24");
inline const QString FONT_UI    = QStringLiteral("Segoe UI");

// La feuille de style de l'application entière.
QString style();

} // namespace theme
