#include "editor_view.h"

#include "config.h"
#include "graphics_items.h"
#include "infos_dialog.h"
#include "print_editor_dialog.h"
#include "theme.h"

#include <QContextMenuEvent>
#include <QFileInfo>
#include <QGraphicsSimpleTextItem>
#include <QKeyEvent>
#include <QLinearGradient>
#include <QMenu>
#include <QPainter>
#include <QRubberBand>
#include <QScrollBar>
#include <QTimer>
#include <QWheelEvent>

#include <cmath>

namespace {
// Pseudo-chemin de l'arrière-plan livré avec le programme.
const QString FOND_INTEGRE_CHEMIN = QStringLiteral("<cuir intégré>");

QPixmap &cuirIntegre()
{
    static QPixmap p;
    return p;
}

QString libelle(const QString &verbe, int n)
{
    return n <= 1 ? QStringLiteral("%1 cet élément").arg(verbe)
                  : QStringLiteral("%1 ces %2 éléments").arg(verbe).arg(n);
}
} // namespace

EditorView::EditorView(QGraphicsScene *scene, QWidget *parent) : QGraphicsView(scene, parent)
{
    m_rb = new QRubberBand(QRubberBand::Rectangle, this);
    setDragMode(QGraphicsView::NoDrag);
    scene->setBackgroundBrush(Qt::NoBrush);

    m_minuteurFin = new QTimer(this);
    m_minuteurFin->setSingleShot(true);
    connect(m_minuteurFin, &QTimer::timeout, this, &EditorView::renduFin);

    // Un fond accroché à la zone d'affichage ne doit pas suivre le défilement.
    setViewportUpdateMode(fondColleALaZone() ? QGraphicsView::FullViewportUpdate
                                             : QGraphicsView::SmartViewportUpdate);
    setOptimizationFlag(QGraphicsView::DontSavePainterState, true);
    setOptimizationFlag(QGraphicsView::DontAdjustForAntialiasing, true);
}

// ---------------------------------------------------------------------------
// Rendu rapide / rendu fin
// ---------------------------------------------------------------------------
void EditorView::debutRenduRapide()
{
    RenduRapide::actif = true;
    m_minuteurFin->stop();
}

void EditorView::programmerRenduFin()
{
    m_minuteurFin->start(DELAI_RENDU_FIN);
}

void EditorView::renduFin()
{
    RenduRapide::actif = false;
    viewport()->update();
}

// ---------------------------------------------------------------------------
// Zoom à la molette, centré sur le pointeur
// ---------------------------------------------------------------------------
void EditorView::wheelEvent(QWheelEvent *event)
{
    const int delta = event->angleDelta().y();
    if (!delta) {
        QGraphicsView::wheelEvent(event);
        return;
    }
    const double courant = transform().m11();
    double vise = courant * (delta > 0 ? ZOOM_STEP : 1.0 / ZOOM_STEP);
    vise = qBound(ZOOM_MIN, vise, ZOOM_MAX);
    if (qAbs(vise - courant) > 1e-9) {
        debutRenduRapide();
        const ViewportAnchor ancre = transformationAnchor();
        setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
        scale(vise / courant, vise / courant);
        setTransformationAnchor(ancre);
        emit zoomChanged(int(std::round(vise * 100)));
        programmerRenduFin();
    }
    event->accept();
}

// ---------------------------------------------------------------------------
// Déplacement du plan de travail
// ---------------------------------------------------------------------------
void EditorView::assurerPlace()
{
    QGraphicsScene *s = scene();
    if (!s)
        return;
    const QRectF visible = mapToScene(viewport()->rect()).boundingRect();
    if (visible.isEmpty())
        return;
    const double marge = qMax(visible.width(), visible.height());
    const QRectF voulu = visible.adjusted(-marge, -marge, marge, marge);
    const QRectF actuel = s->sceneRect();
    if (!actuel.contains(voulu))
        s->setSceneRect(actuel.united(voulu));
}

void EditorView::debutPan(QMouseEvent *event)
{
    m_panOrigine = event->position().toPoint();
    m_panDepart = m_panOrigine;
    assurerPlace();
    setCursor(Qt::ClosedHandCursor);
    debutRenduRapide();
    event->accept();
}

bool EditorView::finPan()
{
    const auto depart = m_panDepart;
    const auto arrivee = m_panOrigine;
    m_panOrigine.reset();
    m_panDepart.reset();
    unsetCursor();
    programmerRenduFin();
    if (!depart || !arrivee)
        return false;
    const QPoint ecart = *depart - *arrivee;
    return (qAbs(ecart.x()) + qAbs(ecart.y())) < SEUIL_CLIC;
}

bool EditorView::zoneDeplacement(const QPoint &point) const
{
    // Partout sauf sur un élément ou une de ses poignées.
    QGraphicsItem *item = itemAt(point);
    if (!item)
        return true;
    return item->type() == QGraphicsSimpleTextItem::Type || item->type() == PaperItem::Type;
}

// ---------------------------------------------------------------------------
// Fond du bureau
// ---------------------------------------------------------------------------
QString EditorView::cheminFond() const
{
    const QString source = config::sourceFond();
    if (source == config::FOND_COULEUR || source == config::FOND_DEGRADE)
        return QString();
    if (source == config::FOND_FICHIER) {
        const QString chemin = config::lireTexte(QStringLiteral("scene_bg_image")).trimmed();
        if (!chemin.isEmpty() && QFileInfo(chemin).isFile())
            return chemin;
    }
    // Une image choisie qui a disparu se rabat sur l'image intégrée.
    return FOND_INTEGRE_CHEMIN;
}

bool EditorView::fondColleALaZone() const
{
    return !cheminFond().isEmpty() || config::sourceFond() == config::FOND_DEGRADE;
}

QPixmap EditorView::chargerFond(const QString &chemin)
{
    if (!m_fondCharge || chemin != m_fondChemin) {
        m_fondChemin = chemin;
        m_fondCharge = true;
        if (chemin == FOND_INTEGRE_CHEMIN) {
            if (cuirIntegre().isNull())
                cuirIntegre().load(QStringLiteral(":/cuir.jpg"));
            m_fondSource = cuirIntegre();
        } else {
            m_fondSource = QFileInfo(chemin).isFile() ? QPixmap(chemin) : QPixmap();
        }
    }
    return m_fondSource;
}

QPixmap EditorView::preparerFond(const QPixmap &source, const QString &mode, const QSize &taille) const
{
    QPixmap pret(taille);
    pret.fill(QColor(config::lireTexte(QStringLiteral("scene_bg"), theme::SCENE_BG)));
    QPainter p(&pret);
    const QRect zone(0, 0, taille.width(), taille.height());
    if (mode == QStringLiteral("Étirer")) {
        p.setRenderHint(QPainter::SmoothPixmapTransform, true);
        p.drawPixmap(zone, source);
    } else if (mode == QStringLiteral("Mosaïque")) {
        p.fillRect(zone, QBrush(source));
    } else { // Remplir
        const QPixmap scaled = source.scaled(taille, Qt::KeepAspectRatioByExpanding,
                                             Qt::SmoothTransformation);
        p.drawPixmap((taille.width() - scaled.width()) / 2, (taille.height() - scaled.height()) / 2,
                     scaled);
    }
    p.end();
    return pret;
}

void EditorView::rafraichirFond()
{
    m_fondChemin.clear();
    m_fondCharge = false;
    m_fondSource = QPixmap();
    m_fondCle.clear();
    m_fondPret = QPixmap();
    setViewportUpdateMode(fondColleALaZone() ? QGraphicsView::FullViewportUpdate
                                             : QGraphicsView::SmartViewportUpdate);
    viewport()->update();
}

void EditorView::drawBackground(QPainter *painter, const QRectF &)
{
    const QRect vr = viewport()->rect();
    const QString chemin = cheminFond();
    if (!chemin.isEmpty()) {
        const QPixmap source = chargerFond(chemin);
        if (!source.isNull()) {
            const QString mode = config::lireTexte(QStringLiteral("scene_bg_mode"), QStringLiteral("Remplir"));
            const QString cle = QStringLiteral("%1|%2|%3|%4").arg(chemin, mode).arg(vr.width()).arg(vr.height());
            if (cle != m_fondCle || m_fondPret.isNull()) {
                m_fondCle = cle;
                m_fondPret = preparerFond(source, mode, vr.size());
            }
            painter->save();
            painter->resetTransform();
            painter->drawPixmap(0, 0, m_fondPret);
            painter->restore();
            return;
        }
    }
    painter->save();
    painter->resetTransform();
    if (config::sourceFond() == config::FOND_DEGRADE) {
        const QColor c1(config::lireTexte(QStringLiteral("scene_bg_deg1"),
                                          config::lireTexte(QStringLiteral("scene_bg"), theme::SCENE_BG)));
        const QColor c2(config::lireTexte(QStringLiteral("scene_bg_deg2"),
                                          config::lireTexte(QStringLiteral("scene_bg2"), config::SCENE_BG2)));
        const bool horizontal = config::lireTexte(QStringLiteral("scene_bg_sens"), QStringLiteral("Vertical"))
                                    .toLower()
                                    .startsWith(QLatin1Char('h'));
        QLinearGradient deg = horizontal ? QLinearGradient(vr.left(), 0, vr.right(), 0)
                                         : QLinearGradient(0, vr.top(), 0, vr.bottom());
        deg.setColorAt(0.0, c1);
        deg.setColorAt(1.0, c2);
        painter->fillRect(vr, QBrush(deg));
    } else {
        painter->fillRect(vr, QColor(config::lireTexte(QStringLiteral("scene_bg"), theme::SCENE_BG)));
    }
    painter->restore();
}

void EditorView::drawForeground(QPainter *painter, const QRectF &rect)
{
    QGraphicsView::drawForeground(painter, rect);
    if (!m_trait)
        return;
    painter->save();
    QPen stylo(QColor(COULEUR_INSERTION), 4);
    stylo.setCosmetic(true);
    stylo.setCapStyle(Qt::RoundCap);
    painter->setPen(stylo);
    painter->drawLine(*m_trait);
    painter->restore();
}

// ---------------------------------------------------------------------------
// Clavier et souris
// ---------------------------------------------------------------------------
QList<ResizablePixmapItem *> EditorView::selection() const
{
    QList<ResizablePixmapItem *> sel;
    const auto items = scene()->selectedItems();
    for (QGraphicsItem *it : items)
        if (auto *r = qgraphicsitem_cast<ResizablePixmapItem *>(it))
            sel.append(r);
    return sel;
}

void EditorView::keyPressEvent(QKeyEvent *event)
{
    const bool ctrl = event->modifiers() & Qt::ControlModifier;
    const int key = event->key();
    if (ctrl && key == Qt::Key_A) {
        scene()->clearSelection();
        const auto items = scene()->items();
        for (QGraphicsItem *it : items)
            if (qgraphicsitem_cast<ResizablePixmapItem *>(it))
                it->setSelected(true);
    } else if (ctrl && key == Qt::Key_C) {
        const auto sel = selection();
        if (!sel.isEmpty())
            doCopy(sel);
    } else if (ctrl && key == Qt::Key_V) {
        doPaste();
    } else {
        QGraphicsView::keyPressEvent(event);
    }
}

void EditorView::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::MiddleButton) {
        debutPan(event);
        return;
    }
    if (event->button() == Qt::LeftButton) {
        const QPoint point = event->position().toPoint();
        const bool ctrl = event->modifiers() & Qt::ControlModifier;
        if (zoneDeplacement(point)) {
            // Ctrl : rectangle de sélection.
            if (ctrl) {
                m_rbOrigine = point;
                m_rb->setGeometry(point.x(), point.y(), 0, 0);
                m_rb->show();
                return;
            }
            // Plusieurs feuilles : on réordonne ; sinon on fait glisser la vue.
            PaperItem *feuille = feuilleSousPoint(point);
            if (feuille && reordonnable()) {
                m_fgOrigine = point;
                m_fgFeuille = feuille;
                m_fgGlisse = false;
                m_indexCible.reset();
                event->accept();
                return;
            }
            debutPan(event);
            return;
        }
        debutRenduRapide();
    }
    QGraphicsView::mousePressEvent(event);
}

void EditorView::mouseMoveEvent(QMouseEvent *event)
{
    if (m_fgOrigine) {
        suivreGlisseFeuille(event);
        return;
    }
    if (m_panOrigine) {
        const QPoint point = event->position().toPoint();
        const QPoint delta = point - *m_panOrigine;
        m_panOrigine = point;
        horizontalScrollBar()->setValue(horizontalScrollBar()->value() - delta.x());
        verticalScrollBar()->setValue(verticalScrollBar()->value() - delta.y());
        event->accept();
        return;
    }
    if (m_rbOrigine) {
        m_rb->setGeometry(QRect(*m_rbOrigine, event->position().toPoint()).normalized());
        return;
    }
    QGraphicsView::mouseMoveEvent(event);
}

void EditorView::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && m_fgOrigine) {
        finGlisseFeuille(event);
        return;
    }
    if (m_panOrigine && (event->button() == Qt::LeftButton || event->button() == Qt::MiddleButton)) {
        // Un geste trop court était un clic : il désélectionne.
        if (finPan() && event->button() == Qt::LeftButton)
            scene()->clearSelection();
        event->accept();
        return;
    }
    if (event->button() == Qt::LeftButton && m_rbOrigine) {
        m_rb->hide();
        const QRectF zone =
            mapToScene(QRect(*m_rbOrigine, event->position().toPoint()).normalized()).boundingRect();
        const auto items = scene()->items(zone);
        for (QGraphicsItem *it : items)
            if (qgraphicsitem_cast<ResizablePixmapItem *>(it))
                it->setSelected(true);
        m_rbOrigine.reset();
        return;
    }
    QGraphicsView::mouseReleaseEvent(event);
    if (event->button() == Qt::LeftButton)
        programmerRenduFin();
}

// ---------------------------------------------------------------------------
// Glissé latéral d'une feuille
// ---------------------------------------------------------------------------
bool EditorView::reordonnable() const
{
    return hote && hote->papers().size() > 1;
}

PaperItem *EditorView::feuilleSousPoint(const QPoint &point) const
{
    return feuilleContenant(mapToScene(point));
}

PaperItem *EditorView::feuilleContenant(const QPointF &point) const
{
    const auto items = scene()->items(point);
    for (QGraphicsItem *it : items)
        if (auto *p = qgraphicsitem_cast<PaperItem *>(it))
            return p;
    return nullptr;
}

void EditorView::suivreGlisseFeuille(QMouseEvent *event)
{
    const QPoint point = event->position().toPoint();
    if (!m_fgGlisse) {
        const QPoint ecart = point - *m_fgOrigine;
        if (qAbs(ecart.x()) + qAbs(ecart.y()) >= SEUIL_CLIC) {
            m_fgGlisse = true;
            m_fgFeuille->marquerDeplacement(true);
            setCursor(Qt::SizeHorCursor);
            debutRenduRapide();
        }
    }
    if (m_fgGlisse && hote) {
        const int rang = hote->feuilleIndexInsertion(mapToScene(point).x());
        const std::optional<QLineF> trait = hote->traitInsertion(rang);
        if (!m_indexCible || rang != *m_indexCible || trait != m_trait) {
            m_indexCible = rang;
            m_trait = trait;
            viewport()->update();
        }
    }
    event->accept();
}

void EditorView::finGlisseFeuille(QMouseEvent *event)
{
    PaperItem *feuille = m_fgFeuille;
    const bool glisse = m_fgGlisse;
    const auto cible = m_indexCible;
    m_fgOrigine.reset();
    m_fgFeuille = nullptr;
    m_fgGlisse = false;
    m_indexCible.reset();
    m_trait.reset();
    if (feuille)
        feuille->marquerDeplacement(false);
    unsetCursor();
    viewport()->update();
    event->accept();
    if (glisse && feuille && cible && hote) {
        programmerRenduFin();
        hote->deplacerFeuille(feuille->index(), *cible);
        return;
    }
    scene()->clearSelection();
}

// ---------------------------------------------------------------------------
// Menus contextuels
// ---------------------------------------------------------------------------
void EditorView::contextMenuEvent(QContextMenuEvent *event)
{
    const QPointF scenePos = mapToScene(event->pos());
    ResizablePixmapItem *sous = nullptr;
    const auto items = scene()->items(scenePos);
    for (QGraphicsItem *it : items)
        if (auto *r = qgraphicsitem_cast<ResizablePixmapItem *>(it)) {
            sous = r;
            break;
        }
    if (sous)
        menuElement(sous, event->globalPos());
    else
        menuFeuille(scenePos, event->globalPos());
}

void EditorView::menuElement(ResizablePixmapItem *itemSous, const QPoint &global)
{
    QList<ResizablePixmapItem *> sel = selection();
    if (!sel.contains(itemSous)) {
        scene()->clearSelection();
        itemSous->setSelected(true);
        sel = {itemSous};
    }
    itemSous->marquerColle(false);

    const int nSel = int(sel.size());
    const int nPp = int(m_copies.size());
    QMenu menu(this);
    QAction *actCopier = menu.addAction(QStringLiteral("📋 ") + libelle(QStringLiteral("Copier"), nSel));
    QAction *actColler = menu.addAction(QStringLiteral("📌 ") + libelle(QStringLiteral("Coller"), nPp));
    actColler->setEnabled(!m_copies.isEmpty());
    menu.addSeparator();
    QAction *actSuppr = menu.addAction(QStringLiteral("🗑️ ") + libelle(QStringLiteral("Supprimer"), nSel));
    menu.addSeparator();
    QAction *actInfos = menu.addAction(QStringLiteral("ℹ️ Infos"));

    QAction *choix = menu.exec(global);
    if (choix == actCopier)
        doCopy(sel);
    else if (choix == actColler)
        doPaste();
    else if (choix == actSuppr)
        doDelete(sel);
    else if (choix == actInfos)
        afficherInfos(itemSous);
}

void EditorView::afficherInfos(ResizablePixmapItem *item)
{
    InfosDialog boite(item, config::renderDpi(), this);
    boite.exec();
}

void EditorView::menuFeuille(const QPointF &scenePos, const QPoint &global)
{
    if (!hote)
        return;
    PaperItem *feuille = feuilleContenant(scenePos);
    if (!feuille)
        return;
    const int numero = feuille->index() + 1;

    QMenu menu(this);
    QAction *actCollerElem = nullptr;
    if (!m_copies.isEmpty()) {
        actCollerElem = menu.addAction(QStringLiteral("📌 ")
                                       + libelle(QStringLiteral("Coller"), int(m_copies.size())));
        menu.addSeparator();
    }
    QAction *actCopier = menu.addAction(QStringLiteral("⧉ Copier la page %1").arg(numero));
    QAction *actColler = menu.addAction(QStringLiteral("📄 Coller la page…"));
    actColler->setEnabled(hote->feuilleDansPressePapiers());
    menu.addSeparator();
    QAction *actSuppr = menu.addAction(QStringLiteral("🗑️ Supprimer la page %1").arg(numero));
    actSuppr->setEnabled(hote->papers().size() > 1);

    QAction *choix = menu.exec(global);
    const int index = feuille->index();
    if (actCollerElem && choix == actCollerElem)
        doPaste();
    else if (choix == actCopier)
        hote->copierFeuille(index);
    else if (choix == actColler)
        hote->collerFeuille();
    else if (choix == actSuppr)
        hote->supprimerFeuille(index);
}

void EditorView::doCopy(const QList<ResizablePixmapItem *> &items)
{
    // Mémorise les éléments AVEC leur taille d'affichage et leur place.
    m_copies.clear();
    for (ResizablePixmapItem *it : items)
        m_copies.append(Copie{it->originalPixmap, it->pos(), it->pixmap().width(), it->pixmap().height()});
}

QPointF EditorView::placeACote(const Copie &copie) const
{
    const QPointF orig = copie.pos;
    const int w = copie.w, h = copie.h;
    const int e = ECART_COLLAGE;
    PaperItem *feuille = feuilleContenant(QPointF(orig.x() + w / 2.0, orig.y() + h / 2.0));
    if (!feuille)
        return QPointF(orig.x() + w + e, orig.y());
    const QRectF r = feuille->scenePageRect();
    if (orig.x() + w + e + w <= r.right())
        return QPointF(orig.x() + w + e, orig.y());
    if (orig.y() + h + e + h <= r.bottom())
        return QPointF(orig.x(), orig.y() + h + e);
    return QPointF(orig.x() + 20, orig.y() + 20);
}

void EditorView::doPaste()
{
    if (m_copies.isEmpty())
        return;
    scene()->clearSelection();
    for (const Copie &copie : std::as_const(m_copies)) {
        auto *item = new ResizablePixmapItem(copie.pixmap);
        item->poserTaille(copie.w, copie.h);
        scene()->addItem(item);
        item->setPos(placeACote(copie));
        item->setSelected(true);
        item->marquerColle(true);
    }
}

void EditorView::doDelete(const QList<ResizablePixmapItem *> &items)
{
    for (ResizablePixmapItem *it : items) {
        scene()->removeItem(it);
        delete it; // les poignées, enfants, partent avec
    }
}
