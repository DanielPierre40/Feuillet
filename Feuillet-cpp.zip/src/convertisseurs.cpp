#include "convertisseurs.h"

#include "config.h"
#include "workers.h"

#include <QAbstractButton>
#include <QCoreApplication>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonObject>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QStandardPaths>
#include <QThread>
#include <QUuid>

#include <algorithm>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace cv {

namespace {

const QString CLE_CHEMINS = QStringLiteral("convertisseurs");
const QString CLE_REFUS = QStringLiteral("convertisseurs_refuses");

QSet<QString> formatsOffice()
{
    return {QStringLiteral(".doc"), QStringLiteral(".docx"), QStringLiteral(".rtf"), QStringLiteral(".odt"),
            QStringLiteral(".epub"), QStringLiteral(".xls"), QStringLiteral(".xlsx"), QStringLiteral(".ods"),
            QStringLiteral(".csv"), QStringLiteral(".ppt"), QStringLiteral(".pptx"), QStringLiteral(".odp")};
}

QJsonObject chemins()
{
    const QJsonValue v = config::lire(CLE_CHEMINS);
    if (v.isObject())
        return v.toObject();
    // Anciennes clés, relues une fois.
    QJsonObject valeur;
    const QString word = config::lireTexte(QStringLiteral("msoffice_word")).trimmed();
    const QString lo = config::lireTexte(QStringLiteral("libreoffice_soffice")).trimmed();
    if (!word.isEmpty())
        valeur.insert(QStringLiteral("word"), word);
    if (!lo.isEmpty())
        valeur.insert(QStringLiteral("libreoffice"), lo);
    config::poser(CLE_CHEMINS, valeur);
    return valeur;
}

QStringList refus()
{
    QStringList r;
    for (const QJsonValue &v : config::lire(CLE_REFUS).toArray())
        r << v.toString();
    return r;
}

void poserRefus(const QStringList &r)
{
    config::poser(CLE_REFUS, QJsonArray::fromStringList(r));
}

// Développe un motif à jokers (* ?) dans un ou plusieurs composants du chemin.
QStringList globber(const QString &motif)
{
    const QString normal = QDir::fromNativeSeparators(motif);
    QStringList parties = normal.split(QLatin1Char('/'), Qt::KeepEmptyParts);
    if (parties.isEmpty())
        return {};
    QStringList courants;
    // Racine : « C: » ou « » (chemin absolu Unix).
    courants << (parties.first().isEmpty() ? QStringLiteral("/") : parties.first() + QLatin1Char('/'));
    parties.removeFirst();
    for (int i = 0; i < parties.size(); ++i) {
        const QString &p = parties[i];
        if (p.isEmpty())
            continue;
        const bool dernier = i == parties.size() - 1;
        QStringList suivants;
        for (const QString &base : std::as_const(courants)) {
            if (p.contains(QLatin1Char('*')) || p.contains(QLatin1Char('?'))) {
                QDir d(base);
                const QStringList noms = d.entryList({p}, (dernier ? QDir::Files : QDir::Dirs) | QDir::NoDotAndDotDot,
                                                     QDir::Name);
                for (const QString &n : noms)
                    suivants << QDir(base).filePath(n);
            } else {
                suivants << QDir(base).filePath(p);
            }
        }
        courants = suivants;
        if (courants.isEmpty())
            break;
    }
    return courants;
}

#ifdef Q_OS_WIN
void sansConsole(QProcess &p)
{
    p.setCreateProcessArgumentsModifier([](QProcess::CreateProcessArguments *a) {
        a->flags |= CREATE_NO_WINDOW;
        a->startupInfo->dwFlags |= STARTF_USESHOWWINDOW;
        a->startupInfo->wShowWindow = SW_HIDE;
    });
}
#else
void sansConsole(QProcess &) {}
#endif

QString fichierTemporairePng()
{
    return QDir::temp().filePath(QStringLiteral("feuillet_%1.png").arg(QUuid::createUuid().toString(QUuid::Id128)));
}

} // namespace

const QMap<QString, Fiche> &table()
{
    static const QMap<QString, Fiche> t = {
        {QStringLiteral("word"),
         {QStringLiteral("Microsoft Office"), QStringLiteral("les documents Word, Excel et PowerPoint"),
          formatsOffice(), {QStringLiteral("WINWORD.EXE")},
          {QStringLiteral("C:\\Program Files\\Microsoft Office\\root\\Office*\\WINWORD.EXE"),
           QStringLiteral("C:\\Program Files (x86)\\Microsoft Office\\root\\Office*\\WINWORD.EXE"),
           QStringLiteral("C:\\Program Files\\Microsoft Office\\Office*\\WINWORD.EXE"),
           QStringLiteral("C:\\Program Files (x86)\\Microsoft Office\\Office*\\WINWORD.EXE")},
          QStringLiteral("WINWORD.EXE (WINWORD.EXE);;Exécutables (*.exe)")}},
        {QStringLiteral("libreoffice"),
         {QStringLiteral("LibreOffice"), QStringLiteral("les documents Word, Excel, PowerPoint et OpenDocument"),
          formatsOffice(), {QStringLiteral("soffice"), QStringLiteral("libreoffice")},
          {QStringLiteral("C:\\Program Files\\LibreOffice\\program\\soffice.exe"),
           QStringLiteral("C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe"),
           QStringLiteral("/Applications/LibreOffice.app/Contents/MacOS/soffice"), QStringLiteral("/usr/bin/soffice")},
          QStringLiteral("soffice.exe (soffice.exe);;Exécutables (*.exe)")}},
        {QStringLiteral("imagemagick"),
         {QStringLiteral("ImageMagick"), QStringLiteral("les fichiers GIMP (.xcf)"), {QStringLiteral(".xcf")},
          {QStringLiteral("magick"), QStringLiteral("convert")},
          {QStringLiteral("C:\\Program Files\\ImageMagick*\\magick.exe"),
           QStringLiteral("C:\\Program Files (x86)\\ImageMagick*\\magick.exe"), QStringLiteral("/usr/bin/magick")},
          QStringLiteral("magick.exe (magick.exe);;Exécutables (*.exe)")}},
        {QStringLiteral("gimp"),
         {QStringLiteral("GIMP"), QStringLiteral("les fichiers GIMP (.xcf)"), {QStringLiteral(".xcf")},
          {QStringLiteral("gimp-console-2.10"), QStringLiteral("gimp-console-3.0"), QStringLiteral("gimp-console")},
          {QStringLiteral("C:\\Program Files\\GIMP *\\bin\\gimp-console-*.exe"),
           QStringLiteral("C:\\Program Files (x86)\\GIMP *\\bin\\gimp-console-*.exe"),
           QStringLiteral("/usr/bin/gimp-console")},
          QStringLiteral("gimp-console (gimp-console*.exe);;Exécutables (*.exe)")}},
    };
    return t;
}

QVariant auPremierPlan(const std::function<QVariant()> &fonction)
{
    QCoreApplication *app = QCoreApplication::instance();
    if (!app || QThread::currentThread() == app->thread())
        return fonction();
    QVariant resultat;
    QMetaObject::invokeMethod(
        app, [&]() { resultat = fonction(); }, Qt::BlockingQueuedConnection);
    return resultat;
}

QString cheminRetenu(const QString &cle)
{
    const QString chemin = chemins().value(cle).toString().trimmed();
    return (!chemin.isEmpty() && QFileInfo(chemin).isFile()) ? chemin : QString();
}

void retenir(const QString &cle, const QString &chemin)
{
    QJsonObject c = chemins();
    const QString ch = chemin.trimmed();
    if (!ch.isEmpty()) {
        c.insert(cle, ch);
        QStringList r = refus();
        if (r.removeAll(cle))
            poserRefus(r); // on redemande, donc on ne refuse plus
    } else {
        c.remove(cle);
    }
    config::poser(CLE_CHEMINS, c);
    config::enregistrer();
}

bool refuse(const QString &cle)
{
    return refus().contains(cle);
}

void noterRefus(const QString &cle)
{
    QStringList r = refus();
    if (!r.contains(cle))
        r.append(cle);
    poserRefus(r);
    config::enregistrer();
}

QString chercher(const QString &cle)
{
    if (!table().contains(cle))
        return QString();
    const Fiche &f = table().value(cle);
    for (const QString &nom : f.exes) {
        const QString trouve = QStandardPaths::findExecutable(nom);
        if (!trouve.isEmpty())
            return QDir::toNativeSeparators(trouve);
    }
    for (const QString &motif : f.dossiers) {
        if (motif.contains(QLatin1Char('*')) || motif.contains(QLatin1Char('?'))) {
            // Plusieurs versions : la dernière dans l'ordre alphabétique.
            QStringList candidats = globber(motif);
            std::sort(candidats.begin(), candidats.end());
            for (auto it = candidats.crbegin(); it != candidats.crend(); ++it)
                if (QFileInfo(*it).isFile())
                    return QDir::toNativeSeparators(*it);
        } else if (QFileInfo(motif).isFile()) {
            return motif;
        }
    }
    return QString();
}

QString trouver(const QString &cle)
{
    const QString connu = cheminRetenu(cle);
    if (!connu.isEmpty())
        return connu;
    const QString trouve = chercher(cle);
    if (!trouve.isEmpty())
        retenir(cle, trouve);
    return trouve;
}

QStringList convertisseursPour(const QString &extBrute)
{
    const QString ext = extBrute.toLower();
    if (ext == QLatin1String(".xcf"))
        return {QStringLiteral("imagemagick"), QStringLiteral("gimp")};
    QStringList ordre;
    for (const QString &c : {QStringLiteral("word"), QStringLiteral("libreoffice")})
        if (table().value(c).formats.contains(ext))
            ordre << c;
    for (auto it = table().begin(); it != table().end(); ++it)
        if (it.value().formats.contains(ext) && !ordre.contains(it.key()))
            ordre << it.key();
    return ordre;
}

QString demander(const QString &cle, const QString &ext, QWidget *parent)
{
    if (!table().contains(cle) || refuse(cle))
        return QString();
    const Fiche f = table().value(cle);
    const int reponse = auPremierPlan([&]() -> QVariant {
                            return int(QMessageBox::question(
                                parent, QStringLiteral("Feuillet"),
                                QStringLiteral("Feuillet ne sait pas ouvrir les fichiers %1 tout seul.\n\n"
                                               "Il peut se servir de %2 pour %3, mais ne "
                                               "l'a pas trouvé sur cet ordinateur.\n\n"
                                               "Voulez-vous indiquer où il est installé ?\n\n"
                                               "Si vous répondez Non, la question ne sera plus posée. Vous pourrez "
                                               "toujours ouvrir le document dans son logiciel habituel et "
                                               "l'imprimer vers l'imprimante « Feuillet ».")
                                    .arg(ext, f.nom, f.quoi),
                                QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes));
                        }).toInt();
    if (reponse != QMessageBox::Yes) {
        // Un « Non » vaut pour le FORMAT, pas seulement pour ce logiciel.
        QStringList autres = convertisseursPour(ext);
        if (autres.isEmpty())
            autres << cle;
        for (const QString &a : autres)
            noterRefus(a);
        noterRefus(cle);
        return QString();
    }
#ifdef Q_OS_WIN
    const QString filtre = f.filtre;
#else
    const QString filtre = QStringLiteral("Tous les fichiers (*)");
#endif
    const QString chemin = auPremierPlan([&]() -> QVariant {
                               return QFileDialog::getOpenFileName(parent, QStringLiteral("Localiser %1").arg(f.nom),
                                                                   QString(), filtre);
                           }).toString();
    if (chemin.isEmpty())
        return QString(); // pas un refus franc : la question pourra revenir
    retenir(cle, QDir::toNativeSeparators(chemin));
    return QDir::toNativeSeparators(chemin);
}

QString identifier(const QString &chemin, const QString &ext)
{
    const QString nom = QFileInfo(chemin).completeBaseName().toLower();
    const QStringList candidats = ext.isEmpty() ? table().keys() : convertisseursPour(ext);
    for (const QString &cle : candidats)
        for (const QString &exe : table().value(cle).exes) {
            const QString racine = QFileInfo(exe).completeBaseName().toLower();
            if (nom == racine || nom.startsWith(racine))
                return cle;
        }
    return QString();
}

QPair<QString, QString> designerALaMain(const QString &ext, QWidget *parent)
{
    const QStringList cles = convertisseursPour(ext);
    if (cles.isEmpty())
        return {};
    QStringList listeNoms;
    for (const QString &c : cles)
        listeNoms << table().value(c).nom;
    const QString noms = listeNoms.join(QStringLiteral(" ou "));

    const bool choisir = auPremierPlan([&]() -> QVariant {
                             QMessageBox boite(parent);
                             boite.setWindowTitle(QStringLiteral("Feuillet"));
                             boite.setIcon(QMessageBox::Information);
                             boite.setText(QStringLiteral("Feuillet ne sait pas ouvrir les fichiers %1 tout seul, "
                                                          "et n'a trouvé ni %2 sur cet ordinateur.")
                                               .arg(ext, noms));
                             boite.setInformativeText(QStringLiteral(
                                 "Vous pouvez désigner vous-même l'un de ces logiciels s'il est "
                                 "installé ailleurs — ou, plus simplement, ouvrir le fichier dans son "
                                 "logiciel habituel et l'imprimer vers l'imprimante « Feuillet »."));
                             QPushButton *btn =
                                 boite.addButton(QStringLiteral("Désigner un logiciel…"), QMessageBox::AcceptRole);
                             boite.addButton(QStringLiteral("Fermer"), QMessageBox::RejectRole);
                             boite.exec();
                             return boite.clickedButton() == btn;
                         }).toBool();
    if (!choisir)
        return {};

#ifdef Q_OS_WIN
    const QString filtre = QStringLiteral("Exécutables (*.exe);;Tous les fichiers (*)");
#else
    const QString filtre = QStringLiteral("Tous les fichiers (*)");
#endif
    const QString chemin = auPremierPlan([&]() -> QVariant {
                               return QFileDialog::getOpenFileName(parent, QStringLiteral("Localiser %1").arg(noms),
                                                                   QString(), filtre);
                           }).toString();
    if (chemin.isEmpty())
        return {};
    const QString cle = identifier(chemin, ext);
    if (cle.isEmpty()) {
        auPremierPlan([&]() -> QVariant {
            QMessageBox::warning(parent, QStringLiteral("Feuillet"),
                                 QStringLiteral("Feuillet ne sait pas se servir de ce logiciel.\n\n"
                                                "Pour les fichiers %1, il sait piloter %2.\n\n"
                                                "Pour tout autre logiciel, imprimez depuis celui-ci vers "
                                                "l'imprimante « Feuillet ».")
                                     .arg(ext, noms));
            return QVariant();
        });
        return {};
    }
    retenir(cle, QDir::toNativeSeparators(chemin));
    return {cle, QDir::toNativeSeparators(chemin)};
}

// ---------------------------------------------------------------------------
// Les recettes
// ---------------------------------------------------------------------------
QString convertirEnPdf(const QString &soffice, const QString &fichier, const QString &dossierSortie)
{
    QProcess p;
    sansConsole(p);
    p.start(soffice, {QStringLiteral("--headless"), QStringLiteral("--convert-to"), QStringLiteral("pdf"),
                      QStringLiteral("--outdir"), QDir::toNativeSeparators(dossierSortie),
                      QDir::toNativeSeparators(fichier)});
    if (!p.waitForStarted(30000))
        throw ErreurChargement{QStringLiteral("LibreOffice n'a pas pu démarrer.")};
    if (!p.waitForFinished(120000)) {
        p.kill();
        throw ErreurChargement{QStringLiteral("LibreOffice a dépassé le délai d'attente.")};
    }
    if (p.exitStatus() != QProcess::NormalExit || p.exitCode() != 0)
        throw ErreurChargement{QStringLiteral("LibreOffice n'a pas pu convertir le fichier.\nDétail : %1")
                                   .arg(QString::fromLocal8Bit(p.readAllStandardError()))};
    const QString attendu = QDir(dossierSortie).filePath(QFileInfo(fichier).completeBaseName() + QStringLiteral(".pdf"));
    if (QFileInfo::exists(attendu))
        return attendu;
    const QStringList pdfs = QDir(dossierSortie).entryList({QStringLiteral("*.pdf")}, QDir::Files);
    if (pdfs.isEmpty())
        throw ErreurChargement{QStringLiteral("LibreOffice n'a produit aucun fichier PDF.")};
    return QDir(dossierSortie).filePath(pdfs.first());
}

QString xcfViaImagemagick(const QString &magick, const QString &fichier)
{
    // `[0]` : l'image composite du fichier, celle qu'on voit dans GIMP.
    const QString sortie = fichierTemporairePng();
    QProcess p;
    sansConsole(p);
    p.start(magick, {QDir::toNativeSeparators(fichier) + QStringLiteral("[0]"), QDir::toNativeSeparators(sortie)});
    const bool fini = p.waitForStarted(30000) && p.waitForFinished(60000);
    if (!fini)
        p.kill();
    if (!fini || p.exitCode() != 0 || QFileInfo(sortie).size() <= 0) {
        QFile::remove(sortie);
        throw ErreurChargement{QStringLiteral("ImageMagick n'a pas pu lire ce fichier XCF.")};
    }
    return sortie;
}

QString xcfViaGimp(const QString &gimp, const QString &fichier)
{
    // Script-Fu : barres obliques (les barres inverses y seraient prises pour
    // des échappements), et un gimp-quit pour que le processus rende la main.
    const QString sortie = fichierTemporairePng();
    QString entreeS = QDir::fromNativeSeparators(fichier);
    entreeS.replace(QLatin1Char('"'), QStringLiteral("\\\""));
    const QString sortieS = QDir::fromNativeSeparators(sortie);
    const QString script = QStringLiteral("(let* ((image (car (gimp-file-load RUN-NONINTERACTIVE "
                                          "\"%1\" \"%1\"))) "
                                          "(calque (car (gimp-image-flatten image)))) "
                                          "(gimp-file-save RUN-NONINTERACTIVE image calque "
                                          "\"%2\" \"%2\") "
                                          "(gimp-image-delete image))")
                               .arg(entreeS, sortieS);
    QProcess p;
    sansConsole(p);
    p.start(gimp, {QStringLiteral("-i"), QStringLiteral("-d"), QStringLiteral("-f"), QStringLiteral("-b"), script,
                   QStringLiteral("-b"), QStringLiteral("(gimp-quit 0)")});
    if (!(p.waitForStarted(30000) && p.waitForFinished(180000)))
        p.kill();
    if (QFileInfo(sortie).size() <= 0) {
        QFile::remove(sortie);
        throw ErreurChargement{QStringLiteral("GIMP n'a pas pu convertir ce fichier XCF.\nDétail : %1")
                                   .arg(QString::fromLocal8Bit(p.readAllStandardError()).left(400))};
    }
    return sortie;
}

} // namespace cv
