// historique — Annuler / Rétablir de l'Atelier.
//
// On photographie l'état complet du plan de travail après chaque
// modification et on compare à la photo précédente : toute action, même
// nouvelle, est couverte d'office. Une photo ne copie aucune image : les
// QPixmap sont partagées par Qt.
#pragma once

#include <QList>
#include <QPixmap>
#include <QSizeF>
#include <QString>

struct ElementPhoto {
    QPixmap pixmap;
    QPixmap apercu;     // copie de travail déjà calculée (peut être nulle)
    double x = 0, y = 0;
    int w = 0, h = 0;
};

struct PhotoEtat {
    bool portrait = true;
    QList<QSizeF> feuilles;
    QList<ElementPhoto> elements;
};

class HoteHistorique {
public:
    virtual ~HoteHistorique() = default;
    virtual PhotoEtat photoEtat() const = 0;
    virtual void restaurerEtat(const PhotoEtat &photo) = 0;
};

class Historique {
public:
    static constexpr int PROFONDEUR = 40;

    explicit Historique(HoteHistorique *hote);

    bool valider();
    bool peutAnnuler() const { return !m_passe.isEmpty(); }
    bool peutRetablir() const { return !m_futur.isEmpty(); }
    bool annuler();
    bool retablir();
    void oublier();

    static QString signature(const PhotoEtat &photo);

private:
    void appliquer(const PhotoEtat &photo);

    HoteHistorique *m_hote;
    QList<PhotoEtat> m_passe;
    QList<PhotoEtat> m_futur;
    PhotoEtat m_courant;
    bool m_gele = false;
};
