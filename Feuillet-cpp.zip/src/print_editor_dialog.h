// print_editor_dialog — l'ATELIER : les pages à imprimer, les éléments posés
// dessus, les deux barres de boutons, l'historique, la sauvegarde .feuillet.
#pragma once

#include "historique.h"
#include "workers.h"

#include <QDialog>
#include <QJsonArray>
#include <QLineF>
#include <QList>
#include <QPixmap>
#include <QPointF>
#include <QRectF>
#include <QSizeF>
#include <functional>
#include <optional>

class EditorView;
class GroupeBarres;
class BarreBoutons;
class LoadingOverlay;
class MainWindow;
class PaperItem;
class QDoubleSpinBox;
class QGraphicsScene;
class QLabel;
class QPushButton;
class QSlider;
class QSpinBox;
class QThread;
class QTimer;
class ResizablePixmapItem;

// Formats de feuille, en POINTS, toujours donnés DEBOUT.
constexpr double A4_L = 595.0, A4_H = 842.0;
constexpr double A5_L = 420.0, A5_H = 595.0;

class BoiteFormat : public QDialog {
    Q_OBJECT
public:
    BoiteFormat(double largeurPt, double hauteurPt, QWidget *parent = nullptr);
    QSizeF taille() const;

private:
    QDoubleSpinBox *m_l, *m_h;
};

class OmbreBarre : public QWidget {
    Q_OBJECT
public:
    static constexpr int HAUTEUR = 14;
    static constexpr int NOIR = 120;
    OmbreBarre(QWidget *parent, QWidget *barre);
    void replacer();

protected:
    bool eventFilter(QObject *obj, QEvent *ev) override;
    void paintEvent(QPaintEvent *ev) override;

private:
    QWidget *m_barre;
};

class PrintEditorDialog : public QDialog, public HoteHistorique {
    Q_OBJECT
public:
    static constexpr double GAP = 56.0;
    static constexpr int DELAI_VALIDATION = 250;
    static constexpr int THUMB = 256;

    PrintEditorDialog(const QList<QPixmap> &pixmaps, MainWindow *hote);
    ~PrintEditorDialog() override;

    QGraphicsScene *scene() const { return m_scene; }
    const QList<PaperItem *> &papers() const { return m_papers; }
    bool sortieDemandee() const { return m_sortieDemandee; }

    // Historique
    PhotoEtat photoEtat() const override;
    void restaurerEtat(const PhotoEtat &photo) override;
    void repartirDeZero();
    void marquerEnregistre();
    void demanderLaSortie() { m_sortieDemandee = true; }

    // Feuilles (le menu contextuel de la vue délègue ici)
    int feuilleIndexInsertion(double xScene) const;
    std::optional<QLineF> traitInsertion(int index) const;
    void deplacerFeuille(int depuis, int vers);
    bool feuilleDansPressePapiers() const { return m_feuilleCopiee.has_value(); }
    void copierFeuille(int index);
    void collerFeuille();
    void supprimerFeuille(int index);

    bool saveFeuillet();
    void restoreSheets(const QJsonArray &sheets);
    QRectF sheetRect(int index) const;
    QList<ResizablePixmapItem *> items() const;

protected:
    void closeEvent(QCloseEvent *e) override;

private:
    struct ContenuCopie {
        QPixmap pixmap;
        double dx, dy;
        int w, h;
    };
    struct FeuilleCopiee {
        double w, h;
        QList<ContenuCopie> items;
    };
    struct Releve {
        ResizablePixmapItem *item;
        std::optional<int> owner;
        QPointF ecart;
    };

    QWidget *construireBarreHaut();
    void poserOmbreBarre();
    void installerHistorique();
    void validerHistorique();
    void majBoutonsHistorique();
    void annuler();
    void retablir();
    void ouvrirAide();
    void ouvrirOptions();

    void setSheetCount(int count);
    void layoutSheets();
    QRectF sheetsRect() const;
    void ajouterFeuilles(int n = 0);
    void fitView();
    QList<Releve> releveContenu() const;
    void reposerContenu(const QList<Releve> &releve, const std::function<std::optional<int>(int)> &decalage);
    void insererFeuille(int position, const FeuilleCopiee &data);

    void ajouterDocument();
    void documentCharge(const QList<ImageChargee> &images, const QStringList &erreurs);
    void recentrer();
    void onZoomSlider(int v);
    void onZoomSpin(int v);
    void afficherZoom(int pourcent);
    void applyZoom(int pourcent);

    bool rienAPerdre() const;
    bool portesDeSortie();
    void quitter();

    int activeSheetIndex() const;
    QList<ResizablePixmapItem *> elementsDePage(int index) const;
    QList<int> pagesDupliquables() const;
    QString nomElement(int index) const;
    void dupliquer(int n);
    void expliquerRefus();
    void dupliquerSur(int sheetIndex, int n);
    void afficherOrientation();
    void refaireFeuilles();
    void toggleOrientation();
    void choisirFormat(const QString &nom);
    void formatPersonnalise();
    static QString nomDuFormat(double largeur, double hauteur);
    void appliquerFormat(const QString &nom, double l, double h);
    void poserElement(const QPixmap &pixmap, const QPointF &pos, int tailleMax = THUMB);

    MainWindow *m_hote;
    QGraphicsScene *m_scene;
    EditorView *m_view;
    QList<PaperItem *> m_papers;
    bool m_isPortrait = true;
    QString m_formatNom = QStringLiteral("A4");
    double m_formatL = A4_L, m_formatH = A4_H;
    bool m_chargement = false;
    LoadingOverlay *m_voile = nullptr;
    bool m_enregistre = false;
    bool m_sortieDemandee = false;
    std::optional<FeuilleCopiee> m_feuilleCopiee;
    std::optional<int> m_lastDupN;
    GroupeBarres *m_barres;
    BarreBoutons *m_barreHaut = nullptr;
    QPushButton *m_btnAnnuler = nullptr;
    QPushButton *m_btnRetablir = nullptr;
    QPushButton *m_btnImport = nullptr;
    QPushButton *m_btnFormat = nullptr;
    QPushButton *m_btnOrient = nullptr;
    QLabel *m_lblSheets = nullptr;
    QSlider *m_zoomSlider = nullptr;
    QSpinBox *m_zoomSpin = nullptr;
    Historique *m_historique = nullptr;
    QTimer *m_minuteurHist = nullptr;
    QThread *m_fil = nullptr;
    OmbreBarre *m_ombreBarre = nullptr;
};
