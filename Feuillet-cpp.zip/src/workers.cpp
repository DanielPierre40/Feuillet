#include "workers.h"

#include "origines.h"
#include "theme.h"
#include "ui_helpers.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QLabel>
#include <QPainter>
#include <QTemporaryFile>
#include <QTimer>
#include <QUuid>
#include <QVBoxLayout>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <objbase.h>
#endif

// ===========================================================================
// LoadWorker
// ===========================================================================
LoadWorker::LoadWorker(Chargeur chargeur, const QStringList &chemins)
    : m_chargeur(std::move(chargeur)), m_chemins(chemins)
{
    qRegisterMetaType<ImageChargee>("ImageChargee");
    qRegisterMetaType<QList<ImageChargee>>("QList<ImageChargee>");
}

QString LoadWorker::copieTemporaire(const QString &source)
{
    const QString suffixe = QFileInfo(source).suffix();
    const QString cible = QDir::temp().filePath(
        QStringLiteral("feuillet_ro_%1%2")
            .arg(QUuid::createUuid().toString(QUuid::Id128),
                 suffixe.isEmpty() ? QString() : QLatin1Char('.') + suffixe));
    if (QFile::copy(source, cible))
        return cible;
    return QString();
}

void LoadWorker::collecter(const QList<QImage> &resultat, const QString &nom, const QString &source,
                           QList<ImageChargee> &images, QStringList &erreurs)
{
    QList<QImage> gardees;
    for (const QImage &img : resultat)
        if (!img.isNull())
            gardees.append(img);
    const int total = int(gardees.size());
    int rang = 1;
    for (const QImage &img : gardees)
        images.append(ImageChargee{img, source, rang++, total});
    if (!total)
        erreurs.append(QStringLiteral("%1 — résultat vide").arg(nom));
}

void LoadWorker::run()
{
#ifdef Q_OS_WIN
    // Office (automatisation COM) et le décodeur d'images de Windows (WIC)
    // ont besoin de COM dans ce fil.
    const HRESULT com = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
#endif
    QList<ImageChargee> images;
    QStringList erreurs;
    QStringList copies;

    for (const QString &p : m_chemins) {
        const QString nom = QFileInfo(p).fileName();
        QString aLire = p;
        // Fichier verrouillé par un autre programme : on tente une copie.
        {
            QFile essai(p);
            if (essai.exists() && !essai.open(QIODevice::ReadOnly)) {
                const QString tmp = copieTemporaire(p);
                if (tmp.isEmpty()) {
                    erreurs.append(QStringLiteral("%1 — fichier verrouillé, copie impossible").arg(nom));
                    continue;
                }
                copies.append(tmp);
                aLire = tmp;
            }
        }
        try {
            collecter(m_chargeur(aLire), nom, p, images, erreurs);
        } catch (const ErreurChargement &e) {
            erreurs.append(QStringLiteral("%1 — %2").arg(nom, e.message));
        } catch (const std::exception &e) {
            erreurs.append(QStringLiteral("%1 — %2").arg(nom, QString::fromLocal8Bit(e.what())));
        } catch (...) {
            erreurs.append(QStringLiteral("%1 — erreur inattendue").arg(nom));
        }
    }
    for (const QString &tmp : copies)
        QFile::remove(tmp);
#ifdef Q_OS_WIN
    if (SUCCEEDED(com))
        CoUninitialize();
#endif
    emit termine(images, erreurs);
}

QList<QPixmap> pixmapsDepuis(const QList<ImageChargee> &images)
{
    QList<QPixmap> pixmaps;
    for (const ImageChargee &ic : images) {
        QPixmap pix = QPixmap::fromImage(ic.image);
        if (pix.isNull())
            continue;
        origines::noter(pix, ic.chemin, ic.page, ic.pages);
        pixmaps.append(pix);
    }
    return pixmaps;
}

// ===========================================================================
// FonduAttente
// ===========================================================================
FonduAttente::FonduAttente(QWidget *parent) : QWidget(parent)
{
    setAttribute(Qt::WA_TranslucentBackground);
    // De la presse en bois au traceur : l'ordre est celui de l'apparition.
    for (const char *nom : {":/attente_ancienne.png", ":/attente_moderne.png"}) {
        QPixmap pix(QString::fromLatin1(nom));
        if (!pix.isNull())
            m_images.append(pix);
    }
    m_timer = new QTimer(this);
    m_timer->setInterval(INTERVALLE);
    connect(m_timer, &QTimer::timeout, this, QOverload<>::of(&QWidget::update));
}

void FonduAttente::demarrer()
{
    remettreALEchelle();
    if (m_images.size() > 1) {
        m_horloge.restart();
        m_timer->start();
    }
}

void FonduAttente::arreter()
{
    m_timer->stop();
}

void FonduAttente::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    remettreALEchelle();
}

void FonduAttente::remettreALEchelle()
{
    // En pixels PHYSIQUES : sur un écran à 125 % ou 150 %, une image préparée
    // à la taille logique serait réagrandie, donc floue.
    const qreal ratio = devicePixelRatioF() > 0 ? devicePixelRatioF() : 1.0;
    const QSize cible = size() * ratio;
    m_echelle.clear();
    if (cible.isEmpty())
        return;
    for (const QPixmap &pix : m_images) {
        QPixmap mis = pix.scaled(cible, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        mis.setDevicePixelRatio(ratio);
        m_echelle.append(mis);
    }
}

void FonduAttente::paintEvent(QPaintEvent *)
{
    const int n = int(m_echelle.size());
    if (n == 0)
        return;
    const QPixmap *courante = &m_echelle[0];
    const QPixmap *suivante = nullptr;
    double avance = 0.0;
    if (n > 1) {
        const qint64 cycle = PAUSE + FONDU;
        const qint64 t = m_horloge.elapsed() % (cycle * n);
        const int i = int(t / cycle);
        const qint64 reste = t % cycle;
        avance = reste < PAUSE ? 0.0 : double(reste - PAUSE) / FONDU;
        courante = &m_echelle[i];
        suivante = &m_echelle[(i + 1) % n];
    }
    QPainter p(this);
    p.setRenderHint(QPainter::SmoothPixmapTransform);
    auto poser = [&](const QPixmap *pix, double opacite) {
        if (!pix || opacite <= 0.001)
            return;
        const qreal r = pix->devicePixelRatio() > 0 ? pix->devicePixelRatio() : 1.0;
        const double larg = pix->width() / r, haut = pix->height() / r;
        p.setOpacity(opacite);
        p.drawPixmap(int((width() - larg) / 2), int((height() - haut) / 2), *pix);
    };
    poser(courante, 1.0 - avance);
    poser(suivante, avance);
}

// ===========================================================================
// LoadingOverlay
// ===========================================================================
namespace {
const QStringList &messages()
{
    static const QStringList m = {QStringLiteral("Ça vient…"), QStringLiteral("Patience…"),
                                  QStringLiteral("On y est presque"),
                                  QStringLiteral("Conversion en cours…")};
    return m;
}
} // namespace

LoadingOverlay::LoadingOverlay(QWidget *parent) : QWidget(parent)
{
    setAttribute(Qt::WA_TransparentForMouseEvents, false);
    setAttribute(Qt::WA_StyledBackground, true);
    setStyleSheet(QStringLiteral("background: transparent;"));

    m_carte = new QWidget(this);
    m_carte->setObjectName(QStringLiteral("carteAttente"));
    m_carte->setFixedSize(380, 380);
    m_carte->setStyleSheet(QStringLiteral("QWidget#carteAttente { background: %1;"
                                          "  border: 1px solid %2; border-radius: 18px; }")
                               .arg(theme::BG_MENU, theme::ACCENT));
    ui::addShadow(m_carte, 40, 0, 8, 200);

    auto *vl = new QVBoxLayout(m_carte);
    vl->setContentsMargins(24, 24, 24, 22);
    vl->setSpacing(12);

    m_fondu = new FonduAttente(m_carte);
    m_fondu->setFixedHeight(250);
    vl->addWidget(m_fondu);

    m_lblMsg = new QLabel(messages().first());
    m_lblMsg->setAlignment(Qt::AlignCenter);
    m_lblMsg->setStyleSheet(QStringLiteral("background: transparent; border: none; color: %1;"
                                           "font-family: '%2'; font-size: 13pt; font-weight: 600;")
                                .arg(theme::FG, theme::FONT_UI));
    vl->addWidget(m_lblMsg);

    m_lblHint = new QLabel(QStringLiteral("Conversion du document…"));
    m_lblHint->setAlignment(Qt::AlignCenter);
    m_lblHint->setStyleSheet(QStringLiteral("background: transparent; border: none; color: #606878;"
                                            "font-family: '%1'; font-size: 8pt;")
                                 .arg(theme::FONT_UI));
    vl->addWidget(m_lblHint);

    m_timer = new QTimer(this);
    m_timer->setInterval(1200);
    connect(m_timer, &QTimer::timeout, this, &LoadingOverlay::animer);
    // Délai de grâce : la carte ne se montre que si le chargement dure.
    m_attente = new QTimer(this);
    m_attente->setSingleShot(true);
    connect(m_attente, &QTimer::timeout, this, &LoadingOverlay::montrer);
    hide();
}

void LoadingOverlay::animer()
{
    ++m_tick;
    m_lblMsg->setText(messages().at(m_tick % messages().size()));
}

void LoadingOverlay::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    m_carte->move((width() - m_carte->width()) / 2, (height() - m_carte->height()) / 2);
}

void LoadingOverlay::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.fillRect(rect(), QColor(0, 0, 0, 150));
}

void LoadingOverlay::start()
{
    m_attente->start(DELAI_GRACE);
}

void LoadingOverlay::montrer()
{
    if (parentWidget())
        resize(parentWidget()->size());
    raise();
    show();
    m_tick = 0;
    m_lblMsg->setText(messages().first());
    m_timer->start();
    m_fondu->demarrer();
}

void LoadingOverlay::stop()
{
    m_attente->stop();
    if (isVisible()) {
        m_timer->stop();
        m_fondu->arreter();
        hide();
    }
}
