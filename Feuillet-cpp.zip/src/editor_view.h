// editor_view — la vue de l'Atelier : zoom à la molette, déplacement du plan
// de travail, réordonnancement des feuilles, copier-coller, menus.
#pragma once

#include <QGraphicsView>
#include <QLineF>
#include <QList>
#include <QPixmap>
#include <QPointF>
#include <optional>

class PaperItem;
class PrintEditorDialog;
class QRubberBand;
class QTimer;
class ResizablePixmapItem;

class EditorView : public QGraphicsView {
    Q_OBJECT
public:
    static constexpr double ZOOM_MIN = 0.05;
    static constexpr double ZOOM_MAX = 4.00;
    static constexpr double ZOOM_STEP = 1.15;
    static constexpr int DELAI_RENDU_FIN = 160;
    static constexpr int SEUIL_CLIC = 4;
    static constexpr int ECART_COLLAGE = 12;

    explicit EditorView(QGraphicsScene *scene, QWidget *parent = nullptr);

    PrintEditorDialog *hote = nullptr;

    void debutRenduRapide();
    void programmerRenduFin();
    void rafraichirFond();

signals:
    void zoomChanged(int pourcent);

protected:
    void wheelEvent(QWheelEvent *event) override;
    void drawBackground(QPainter *painter, const QRectF &rect) override;
    void drawForeground(QPainter *painter, const QRectF &rect) override;
    void keyPressEvent(QKeyEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void contextMenuEvent(QContextMenuEvent *event) override;

private:
    struct Copie {
        QPixmap pixmap;
        QPointF pos;
        int w, h;
    };

    void renduFin();
    void assurerPlace();
    void debutPan(QMouseEvent *event);
    bool finPan();
    bool zoneDeplacement(const QPoint &point) const;
    QString cheminFond() const;
    bool fondColleALaZone() const;
    QPixmap chargerFond(const QString &chemin);
    QPixmap preparerFond(const QPixmap &source, const QString &mode, const QSize &taille) const;

    bool reordonnable() const;
    PaperItem *feuilleSousPoint(const QPoint &point) const;
    PaperItem *feuilleContenant(const QPointF &point) const;
    void suivreGlisseFeuille(QMouseEvent *event);
    void finGlisseFeuille(QMouseEvent *event);

    void menuElement(ResizablePixmapItem *itemSous, const QPoint &global);
    void menuFeuille(const QPointF &scenePos, const QPoint &global);
    void afficherInfos(ResizablePixmapItem *item);
    void doCopy(const QList<ResizablePixmapItem *> &items);
    QPointF placeACote(const Copie &copie) const;
    void doPaste();
    void doDelete(const QList<ResizablePixmapItem *> &items);
    QList<ResizablePixmapItem *> selection() const;

    QList<Copie> m_copies;
    std::optional<QPoint> m_rbOrigine;
    QRubberBand *m_rb;
    std::optional<QPoint> m_panOrigine;
    std::optional<QPoint> m_panDepart;

    std::optional<QPoint> m_fgOrigine;
    PaperItem *m_fgFeuille = nullptr;
    bool m_fgGlisse = false;
    std::optional<QLineF> m_trait;
    std::optional<int> m_indexCible;

    // Fond du bureau : tout est mis en cache.
    QString m_fondChemin;
    bool m_fondCharge = false;
    QPixmap m_fondSource;
    QString m_fondCle;
    QPixmap m_fondPret;

    QTimer *m_minuteurFin;
};
