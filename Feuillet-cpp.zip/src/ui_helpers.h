// ui_helpers — l'ombre portée des boutons et le curseur main partout.
#pragma once

class QApplication;
class QWidget;

namespace ui {

void addShadow(QWidget *widget, int blur = 18, int dx = 6, int dy = 6, int opacity = 160);

// Le curseur main sur TOUS les boutons, présents et à venir — y compris les
// commandes grisées, par un prêt de curseur au premier parent actif.
void poserCurseurs(QApplication *app);

} // namespace ui
