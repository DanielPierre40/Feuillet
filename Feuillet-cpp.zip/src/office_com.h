// office_com — Word, Excel et PowerPoint pilotés par automatisation COM,
// pour exporter un document en PDF (comme le faisait win32com en Python).
// Chaque fonction lève ErreurChargement en cas d'échec.
#pragma once

#include <QString>

namespace office {

void wordVersPdf(const QString &document, const QString &pdf);
void excelVersPdf(const QString &classeur, const QString &pdf);
void powerpointVersPdf(const QString &presentation, const QString &pdf);

} // namespace office
