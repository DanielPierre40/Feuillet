#include "infos_dialog.h"

#include "barre_titre.h"
#include "graphics_items.h"
#include "theme.h"

#include <QApplication>
#include <QDir>
#include <QFileInfo>
#include <QFrame>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QProcess>
#include <QPushButton>
#include <QVBoxLayout>

namespace {
struct Format {
    const char *nom;
    double p, g;
};
// Formats normalisés en millimètres (portrait).
const Format FORMATS_MM[] = {
    {"A3", 297.0, 420.0},     {"A4", 210.0, 297.0},     {"A5", 148.0, 210.0},
    {"A6", 105.0, 148.0},     {"B4", 250.0, 353.0},     {"B5", 176.0, 250.0},
    {"Letter", 215.9, 279.4}, {"Legal", 215.9, 355.6},
};
constexpr double TOLERANCE_MM = 4.0;
} // namespace

QString formatPapier(int largeurPx, int hauteurPx, int ppp)
{
    if (!largeurPx || !hauteurPx || !ppp)
        return QStringLiteral("—");
    const double mmL = largeurPx / double(ppp) * 25.4;
    const double mmH = hauteurPx / double(ppp) * 25.4;
    const bool portrait = mmH >= mmL;
    const double petit = portrait ? mmL : mmH, grand = portrait ? mmH : mmL;
    for (const Format &f : FORMATS_MM)
        if (qAbs(petit - f.p) <= TOLERANCE_MM && qAbs(grand - f.g) <= TOLERANCE_MM)
            return QStringLiteral("%1 (%2)").arg(QString::fromLatin1(f.nom),
                                                 portrait ? QStringLiteral("portrait")
                                                          : QStringLiteral("paysage"));
    return QStringLiteral("%1 × %2 mm").arg(mmL, 0, 'f', 0).arg(mmH, 0, 'f', 0);
}

QString poidsLisible(qint64 octets)
{
    if (octets < 1000)
        return QStringLiteral("%1 octets").arg(octets);
    const struct {
        const char *unite;
        double seuil;
    } unites[] = {{"Ko", 1e3}, {"Mo", 1e6}, {"Go", 1e9}};
    for (const auto &u : unites)
        if (octets < u.seuil * 1000)
            return QString::number(octets / u.seuil, 'f', 1).replace(QLatin1Char('.'), QLatin1Char(','))
                   + QLatin1Char(' ') + QString::fromLatin1(u.unite);
    return QString::number(octets / 1e12, 'f', 1).replace(QLatin1Char('.'), QLatin1Char(',')) + QStringLiteral(" To");
}

bool montrerDansExplorateur(const QString &chemin)
{
    const QFileInfo p(chemin);
#ifdef Q_OS_WIN
    if (p.exists()) {
        // /select, met le fichier en surbrillance dans son dossier.
        return QProcess::startDetached(QStringLiteral("explorer.exe"),
                                       {QStringLiteral("/select,"), QDir::toNativeSeparators(p.absoluteFilePath())});
    }
    if (QFileInfo(p.absolutePath()).isDir())
        return QProcess::startDetached(QStringLiteral("explorer.exe"),
                                       {QDir::toNativeSeparators(p.absolutePath())});
    return false;
#else
    const QString dossier = p.absolutePath();
    if (!QFileInfo(dossier).isDir())
        return false;
#ifdef Q_OS_MACOS
    return QProcess::startDetached(QStringLiteral("open"), {dossier});
#else
    return QProcess::startDetached(QStringLiteral("xdg-open"), {dossier});
#endif
#endif
}

InfosDialog::InfosDialog(ResizablePixmapItem *item, int ppp, QWidget *parent) : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Infos"));
    setModal(true);
    // Pas de fond ici : c'est le cadre arrondi qui porte la couleur.
    setMinimumWidth(520);

    const Origine &origine = item->origine;
    const QString chemin = origine.chemin;
    m_chemin = chemin;

    const QPixmap &pix = item->originalPixmap;
    const bool estImage = origine.estImage;
    const int nbPages = origine.pages > 0 ? origine.pages : 1;
    const int page = origine.page > 0 ? origine.page : 1;

    QString nom, emplacement;
    if (!chemin.isEmpty()) {
        nom = QFileInfo(chemin).fileName();
        if (nbPages > 1)
            nom += QStringLiteral("  —  élément %1 sur %2").arg(page).arg(nbPages);
        emplacement = QDir::toNativeSeparators(QFileInfo(chemin).absolutePath());
    } else {
        nom = QStringLiteral("(élément collé — fichier d'origine inconnu)");
        emplacement = QStringLiteral("—");
    }

    QString tailleImage;
    bool tailleGrisee = false;
    if (estImage && !pix.isNull())
        tailleImage = QStringLiteral("%1 × %2 pixels").arg(pix.width()).arg(pix.height());
    else if (estImage)
        tailleImage = QStringLiteral("—");
    else
        tailleGrisee = true; // ce n'est pas une image

    QString formatPage = QStringLiteral("—");
    if (!pix.isNull())
        formatPage = formatPapier(pix.width(), pix.height(), ppp);

    QString poids = QStringLiteral("—");
    if (!chemin.isEmpty()) {
        const QFileInfo fi(chemin);
        poids = fi.exists() ? poidsLisible(fi.size()) : QStringLiteral("(fichier introuvable)");
    }

    auto *lay = new QVBoxLayout(this);
    lay->setContentsMargins(26, 22, 26, 18);
    lay->setSpacing(14);

    auto *titre = new QLabel(QStringLiteral("Informations sur l'élément"));
    titre->setStyleSheet(QStringLiteral("color: %1; font-size: 12pt; font-weight: bold;"
                                        "font-family: '%2'; background: transparent;")
                             .arg(theme::ACCENT, theme::FONT_UI));
    lay->addWidget(titre);

    auto *grille = new QGridLayout();
    grille->setHorizontalSpacing(18);
    grille->setVerticalSpacing(10);
    grille->setColumnStretch(1, 1);
    lay->addLayout(grille);

    ligne(grille, 0, QStringLiteral("Nom du fichier"), nom);
    ligne(grille, 1, QStringLiteral("Taille de l'image"), tailleImage, tailleGrisee,
          QStringLiteral("(l'élément n'est pas une image)"));
    ligne(grille, 2, QStringLiteral("Format papier"), formatPage);
    ligne(grille, 3, QStringLiteral("Poids du fichier"), poids);
    ligne(grille, 4, QStringLiteral("Emplacement"), emplacement, false, QString(), true);

    auto *trait = new QFrame();
    trait->setFrameShape(QFrame::HLine);
    trait->setStyleSheet(QStringLiteral("color: %1; background: %1;").arg(theme::BORDER_COL));
    trait->setFixedHeight(1);
    lay->addWidget(trait);

    auto *barre = new QHBoxLayout();
    barre->setSpacing(10);
    m_btnDossier = new QPushButton(QStringLiteral("📂  Aller dans le dossier du fichier"));
    m_btnDossier->setMinimumHeight(34);
    connect(m_btnDossier, &QPushButton::clicked, this, &InfosDialog::allerAuDossier);
    m_btnDossier->setEnabled(!chemin.isEmpty() && QFileInfo(QFileInfo(chemin).absolutePath()).isDir());
    auto *btnFermer = new QPushButton(QStringLiteral("Fermer"));
    btnFermer->setMinimumHeight(34);
    connect(btnFermer, &QPushButton::clicked, this, &QDialog::accept);
    barre->addWidget(m_btnDossier);
    barre->addStretch();
    barre->addWidget(btnFermer);
    lay->addLayout(barre);

    cadre::poserCadre(this, false, false);
}

void InfosDialog::ligne(QGridLayout *grille, int rang, const QString &libelle, const QString &valeur,
                        bool grise, const QString &texteGrise, bool selectionnable)
{
    auto *lab = new QLabel(libelle + QStringLiteral(" :"));
    lab->setStyleSheet(QStringLiteral("color: %1; font-size: 9pt;"
                                      "font-family: '%2'; background: transparent;")
                           .arg(theme::FG2, theme::FONT_UI));
    lab->setAlignment(Qt::AlignRight | Qt::AlignTop);

    auto *val = new QLabel(grise ? texteGrise : (valeur.isEmpty() ? QStringLiteral("—") : valeur));
    val->setWordWrap(true);
    val->setStyleSheet(QStringLiteral("color: %1; font-size: 9pt; font-style: %2;"
                                      "font-family: '%3'; background: transparent;")
                           .arg(grise ? QStringLiteral("#6a6a6a") : theme::FG,
                                grise ? QStringLiteral("italic") : QStringLiteral("normal"), theme::FONT_UI));
    if (selectionnable && !grise)
        val->setTextInteractionFlags(Qt::TextSelectableByMouse);
    grille->addWidget(lab, rang, 0);
    grille->addWidget(val, rang, 1);
}

void InfosDialog::allerAuDossier()
{
    if (m_chemin.isEmpty())
        return;
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const bool ok = montrerDansExplorateur(m_chemin);
    QApplication::restoreOverrideCursor();
    if (ok)
        accept();
}
