#include "options_dialog.h"

#include "apparence.h"
#include "barre_titre.h"
#include "config.h"
#include "convertisseurs.h"
#include "driver_feuillet.h"
#include "memoire_fenetres.h"
#include "theme.h"
#include "ui_helpers.h"

#include <QApplication>
#include <QButtonGroup>
#include <QCheckBox>
#include <QColorDialog>
#include <QComboBox>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFontComboBox>
#include <QFrame>
#include <QHBoxLayout>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QLinearGradient>
#include <QMessageBox>
#include <QPainter>
#include <QPushButton>
#include <QRadioButton>
#include <QSaveFile>
#include <QScrollArea>
#include <QSpinBox>
#include <QTabWidget>
#include <QVBoxLayout>

namespace {

const QString BORDEAUX = QStringLiteral("#800020");

QString styleCombo()
{
    return QStringLiteral("QComboBox { background: %1; color: %2; border: 1px solid %3;"
                          "  border-radius: 3px; padding: 3px 8px; font-family: '%4'; font-size: 9pt; }"
                          "QComboBox::drop-down { border: none; }"
                          "QComboBox QAbstractItemView { background: #0c0e12; color: %2;"
                          "  selection-background-color: #1c2855; }")
        .arg(theme::BG_EDITOR, theme::FG, theme::BORDER_COL, theme::FONT_UI);
}

// Le carré gris qui devient bordeaux une fois coché. Dès qu'on écrit une
// règle ::indicator, Qt abandonne son dessin natif : il faut tout donner.
QString styleCoche()
{
    return QStringLiteral("QRadioButton { color: %1; font-size: 10pt;"
                          "  font-family: '%2'; background: transparent;"
                          "  padding: 4px 0; spacing: 9px; }"
                          "QRadioButton::indicator { width: 14px; height: 14px;"
                          "  border: 1px solid %3; border-radius: 3px;"
                          "  background: #55596a; }"
                          "QRadioButton::indicator:hover { border-color: %1; }"
                          "QRadioButton::indicator:checked { background: %4;"
                          "  border-color: #b03050; }"
                          "QRadioButton:disabled { color: %5; }")
        .arg(theme::FG, theme::FONT_UI, theme::BD_BTN, BORDEAUX, theme::FG2);
}

QString styleCase()
{
    return QStringLiteral("QCheckBox { color: %1; font-size: 9pt;"
                          "  font-family: '%2'; background: transparent;"
                          "  padding: 3px 0; spacing: 9px; }"
                          "QCheckBox::indicator { width: 14px; height: 14px;"
                          "  border: 1px solid %3; border-radius: 3px;"
                          "  background: #55596a; }"
                          "QCheckBox::indicator:hover { border-color: %1; }"
                          "QCheckBox::indicator:checked { background: %4;"
                          "  border-color: #b03050; }"
                          "QCheckBox:disabled { color: %5; }")
        .arg(theme::FG, theme::FONT_UI, theme::BD_BTN, BORDEAUX, theme::FG2);
}

QLabel *section(const QString &texte)
{
    auto *l = new QLabel(texte);
    l->setStyleSheet(QStringLiteral("color: %1; font-size: 12pt; font-weight: bold;"
                                    "font-family: '%2'; background: transparent;")
                         .arg(theme::FG, theme::FONT_UI));
    return l;
}

QLabel *aide(const QString &texte)
{
    auto *l = new QLabel(texte);
    l->setWordWrap(true);
    l->setStyleSheet(QStringLiteral("color: %1; font-size: 8pt;"
                                    "font-family: '%2'; background: transparent;")
                         .arg(theme::FG2, theme::FONT_UI));
    return l;
}

QLabel *sousTitre(const QString &texte)
{
    auto *l = new QLabel(texte);
    l->setStyleSheet(QStringLiteral("color: #8a92aa; font-size: 9pt;"
                                    "font-family: '%1'; background: transparent;")
                         .arg(theme::FONT_UI));
    return l;
}

QFrame *filet()
{
    auto *f = new QFrame();
    f->setFrameShape(QFrame::HLine);
    f->setFixedHeight(1);
    f->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BORDER_COL));
    return f;
}

QString stylePastille(const QString &couleur)
{
    return QStringLiteral("background: %1; border: 2px solid %2; border-radius: 4px;").arg(couleur, theme::BORDER_COL);
}

} // namespace

// ===========================================================================
// ApercuDegrade
// ===========================================================================
ApercuDegrade::ApercuDegrade(QWidget *parent) : QWidget(parent)
{
    setFixedHeight(HAUTEUR);
}

void ApercuDegrade::regler(const QColor &c1, const QColor &c2, const QString &sens)
{
    const bool horizontal = sens.toLower().startsWith(QLatin1Char('h'));
    if (c1 == m_c1 && c2 == m_c2 && horizontal == m_horizontal)
        return; // rien n'a bougé : pas de repeint inutile
    m_c1 = c1;
    m_c2 = c2;
    m_horizontal = horizontal;
    update();
}

void ApercuDegrade::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    // Un paintEvent maison ignore l'état grisé : on l'estompe nous-mêmes.
    if (!isEnabled())
        p.setOpacity(0.35);
    const QRect zone = rect().adjusted(0, 0, -1, -1);
    QLinearGradient deg = m_horizontal ? QLinearGradient(zone.left(), 0, zone.right(), 0)
                                       : QLinearGradient(0, zone.top(), 0, zone.bottom());
    deg.setColorAt(0.0, m_c1);
    deg.setColorAt(1.0, m_c2);
    p.setPen(QPen(QColor(theme::BORDER_COL), 1));
    p.setBrush(QBrush(deg));
    p.drawRoundedRect(zone, 4, 4);
}

// ===========================================================================
// OptionsDialog
// ===========================================================================
std::shared_ptr<QColor> OptionsDialog::rangeeCouleur(QVBoxLayout *cible, const QString &titre, const QString &texteAide,
                                                     const QString &courante, const QString &defaut, bool avecTitre)
{
    if (avecTitre)
        cible->addWidget(section(titre));
    if (!texteAide.isEmpty())
        cible->addWidget(aide(texteAide));

    auto ref = std::make_shared<QColor>(courante);
    auto *rangee = new QHBoxLayout();
    rangee->setSpacing(12);
    auto *lblHex = new QLabel(courante);
    lblHex->setStyleSheet(QStringLiteral("color: #8a92aa; font-size: 9pt; font-family: '%1'; background: transparent;")
                              .arg(theme::FONT_UI));
    auto *pastille = new QPushButton();
    pastille->setFixedSize(36, 36);
    pastille->setStyleSheet(stylePastille(courante));

    auto peindre = [ref, pastille, lblHex]() {
        pastille->setStyleSheet(stylePastille(ref->name()));
        lblHex->setText(ref->name());
    };
    m_peintres.insert(ref.get(), peindre);

    connect(pastille, &QPushButton::clicked, this, [this, ref, titre, peindre]() {
        const QColor c = QColorDialog::getColor(*ref, this, titre);
        if (c.isValid()) {
            *ref = c;
            peindre();
            rafraichirApercuMsg();
        }
    });
    auto *reset = new QPushButton(QStringLiteral("Réinitialiser"));
    reset->setFixedWidth(110);
    connect(reset, &QPushButton::clicked, this, [this, ref, defaut, peindre]() {
        *ref = QColor(defaut);
        peindre();
        rafraichirApercuMsg();
    });
    rangee->addWidget(pastille);
    rangee->addWidget(lblHex);
    rangee->addStretch();
    rangee->addWidget(reset);
    cible->addLayout(rangee);
    return ref;
}

OptionsDialog::OptionsDialog(QWidget *parent) : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Options — Feuillet"));
    setMinimumWidth(600);
    setModal(true);

    auto *root = new QVBoxLayout(this);
    root->setSpacing(0);
    root->setContentsMargins(0, 0, 0, 0);
    auto *onglets = new QTabWidget();

    // ─── Onglet 1 — Chemins ────────────────────────────────────────────
    auto *tabChemins = new QWidget();
    tabChemins->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BG_WIN));
    auto *bl = new QVBoxLayout(tabChemins);
    bl->setContentsMargins(28, 24, 28, 20);
    bl->setSpacing(14);

    bl->addWidget(section(QStringLiteral("Dossier référent")));
    bl->addWidget(sousTitre(QStringLiteral("Dossier de travail habituel")));
    auto *rowRef = new QHBoxLayout();
    rowRef->setSpacing(8);
    m_referent = new QLineEdit();
    m_referent->setPlaceholderText(QStringLiteral("Ex : D:\\Mes documents\\Impressions"));
    m_referent->setText(config::dossierReferent());
    m_referent->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    auto *btnRef = new QPushButton(QStringLiteral("Parcourir…"));
    btnRef->setFixedWidth(100);
    connect(btnRef, &QPushButton::clicked, this, &OptionsDialog::parcourirReferent);
    auto *btnRefVide = new QPushButton(QStringLiteral("✕"));
    btnRefVide->setFixedWidth(30);
    btnRefVide->setToolTip(QStringLiteral("Ne plus imposer de dossier de départ"));
    connect(btnRefVide, &QPushButton::clicked, m_referent, &QLineEdit::clear);
    rowRef->addWidget(m_referent);
    rowRef->addWidget(btnRef);
    rowRef->addWidget(btnRefVide);
    bl->addLayout(rowRef);
    bl->addWidget(aide(QStringLiteral(
        "Toutes les boîtes de fichiers s'ouvriront ici : ouvrir un document, "
        "en ajouter un à l'Atelier, sauvegarder un feuillet, exporter "
        "ou importer la configuration, choisir une image de fond. "
        "Laissé vide, chaque boîte s'ouvre là où Windows l'avait laissée.")));
    bl->addSpacing(6);
    bl->addWidget(filet());
    bl->addSpacing(6);

    bl->addWidget(section(QStringLiteral("Lecteur PDF par défaut")));
    bl->addWidget(sousTitre(QStringLiteral("Programme qui ouvre les PDF fabriqués par Feuillet")));
    auto *rowPdf = new QHBoxLayout();
    rowPdf->setSpacing(8);
    m_lecteurPdf = new QLineEdit();
    m_lecteurPdf->setPlaceholderText(QStringLiteral("Laissé vide : le lecteur PDF par défaut de Windows"));
    m_lecteurPdf->setText(config::lecteurPdf());
    m_lecteurPdf->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    auto *btnPdf = new QPushButton(QStringLiteral("Parcourir…"));
    btnPdf->setFixedWidth(100);
    btnPdf->setCursor(Qt::PointingHandCursor);
    connect(btnPdf, &QPushButton::clicked, this, &OptionsDialog::parcourirLecteurPdf);
    auto *btnPdfVide = new QPushButton(QStringLiteral("✕"));
    btnPdfVide->setFixedWidth(30);
    btnPdfVide->setCursor(Qt::PointingHandCursor);
    btnPdfVide->setToolTip(QStringLiteral("Revenir au lecteur PDF de Windows"));
    connect(btnPdfVide, &QPushButton::clicked, m_lecteurPdf, &QLineEdit::clear);
    rowPdf->addWidget(m_lecteurPdf);
    rowPdf->addWidget(btnPdf);
    rowPdf->addWidget(btnPdfVide);
    bl->addLayout(rowPdf);
    m_ouvrirPdf = new QCheckBox(QStringLiteral("Ouvrir après l'impression en PDF"));
    m_ouvrirPdf->setChecked(config::ouvrirPdfApres());
    m_ouvrirPdf->setCursor(Qt::PointingHandCursor);
    m_ouvrirPdf->setStyleSheet(styleCase());
    bl->addWidget(m_ouvrirPdf);
    bl->addWidget(aide(QStringLiteral(
        "« Imprimer ▸ Imprimer en PDF » fabrique le fichier, puis le "
        "montre aussitôt dans ce lecteur. Décochez la case pour que "
        "Feuillet se contente de l'écrire sans rien ouvrir.")));
    bl->addSpacing(6);
    bl->addWidget(filet());
    bl->addSpacing(10);
    bl->addWidget(filet());
    bl->addSpacing(6);

    bl->addWidget(section(QStringLiteral("Configuration")));
    auto *rowCfg = new QHBoxLayout();
    rowCfg->setSpacing(10);
    auto *btnExp = new QPushButton(QStringLiteral("📤  Exporter la configuration…"));
    auto *btnImp = new QPushButton(QStringLiteral("📥  Importer la configuration…"));
    connect(btnExp, &QPushButton::clicked, this, &OptionsDialog::exporterConfig);
    connect(btnImp, &QPushButton::clicked, this, &OptionsDialog::importerConfig);
    rowCfg->addWidget(btnExp);
    rowCfg->addWidget(btnImp);
    rowCfg->addStretch();
    bl->addLayout(rowCfg);
    bl->addStretch();
    onglets->addTab(tabChemins, QStringLiteral("🗂  Chemins"));

    // ─── Onglet 2 — Interface ──────────────────────────────────────────
    auto *tabInterface = new QWidget();
    tabInterface->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BG_WIN));
    auto *bi = new QVBoxLayout(tabInterface);
    bi->setContentsMargins(28, 28, 28, 20);
    bi->setSpacing(10);

    bi->addWidget(section(QStringLiteral("Arrière-plan du bureau")));
    bi->addWidget(aide(QStringLiteral("Fond de la zone d'édition autour des pages. Jamais imprimé.")));

    m_groupeFond = new QButtonGroup(this);
    // Un bouton radio, plus le bloc en retrait qui lui appartient.
    auto radio = [&](const QString &valeur, const QString &texte) -> QVBoxLayout * {
        auto *btn = new QRadioButton(texte);
        btn->setCursor(Qt::PointingHandCursor);
        btn->setStyleSheet(styleCoche());
        m_groupeFond->addButton(btn);
        m_radiosFond.insert(valeur, btn);
        bi->addWidget(btn);
        auto *boite = new QWidget();
        boite->setStyleSheet(QStringLiteral("background: transparent;"));
        auto *dedans = new QVBoxLayout(boite);
        dedans->setContentsMargins(26, 0, 0, 6);
        dedans->setSpacing(6);
        bi->addWidget(boite);
        m_boitesFond.insert(valeur, boite);
        return dedans;
    };

    // 1. L'image livrée avec le programme.
    QVBoxLayout *dansInt = radio(config::FOND_INTEGRE, QStringLiteral("Arrière-plan intégré"));
    dansInt->addWidget(aide(QStringLiteral("L'image de cuir fournie avec Feuillet. Aucun fichier à installer.")));

    // 2. Couleur unie.
    QVBoxLayout *dansUni = radio(config::FOND_COULEUR, QStringLiteral("Couleur unie"));
    m_sceneBg = rangeeCouleur(dansUni, QStringLiteral("Couleur du bureau"), QString(),
                              config::lireTexte(QStringLiteral("scene_bg"), theme::SCENE_BG), theme::SCENE_BG, false);

    // 3. Dégradé, avec ses propres couleurs et un aperçu.
    QVBoxLayout *dansDeg = radio(config::FOND_DEGRADE, QStringLiteral("Couleur dégradée"));
    m_deg1 = std::make_shared<QColor>(config::lireTexte(QStringLiteral("scene_bg_deg1"), theme::SCENE_BG));
    m_deg2 = std::make_shared<QColor>(config::lireTexte(
        QStringLiteral("scene_bg_deg2"), config::lireTexte(QStringLiteral("scene_bg2"), config::SCENE_BG2)));
    m_apercuDeg = new ApercuDegrade();
    auto *rowDeg = new QHBoxLayout();
    rowDeg->setSpacing(8);
    auto pastilleDeg = [&](std::shared_ptr<QColor> ref, const QString &legende) {
        auto *btn = new QPushButton();
        btn->setFixedSize(34, 34);
        btn->setCursor(Qt::PointingHandCursor);
        btn->setToolTip(legende);
        auto *lbl = new QLabel();
        lbl->setFixedWidth(66);
        lbl->setStyleSheet(QStringLiteral("color: #8a92aa; font-size: 9pt; font-family: '%1';"
                                          "background: transparent;")
                               .arg(theme::FONT_UI));
        auto peindre = [ref, btn, lbl]() {
            btn->setStyleSheet(stylePastille(ref->name()));
            lbl->setText(ref->name());
        };
        m_peintres.insert(ref.get(), peindre);
        connect(btn, &QPushButton::clicked, this, [this, ref, legende, peindre]() {
            const QColor c = QColorDialog::getColor(*ref, this, legende);
            if (c.isValid()) {
                *ref = c;
                peindre();
                majDegrade();
            }
        });
        peindre();
        rowDeg->addWidget(btn);
        rowDeg->addWidget(lbl);
    };
    pastilleDeg(m_deg1, QStringLiteral("Couleur de départ"));
    auto *fleche = new QLabel(QStringLiteral("→"));
    fleche->setStyleSheet(QStringLiteral("color: %1; font-size: 12pt; background: transparent;").arg(theme::FG2));
    rowDeg->addWidget(fleche);
    pastilleDeg(m_deg2, QStringLiteral("Couleur d'arrivée"));

    auto *lblSens = sousTitre(QStringLiteral("Sens :"));
    m_sens = new QComboBox();
    m_sens->addItems({QStringLiteral("Vertical"), QStringLiteral("Horizontal")});
    const int rangSens = m_sens->findText(config::lireTexte(QStringLiteral("scene_bg_sens"), QStringLiteral("Vertical")));
    if (rangSens >= 0)
        m_sens->setCurrentIndex(rangSens);
    m_sens->setFixedWidth(120);
    m_sens->setStyleSheet(styleCombo());
    connect(m_sens, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [this]() { majDegrade(); });
    auto *btnDegReset = new QPushButton(QStringLiteral("Réinitialiser"));
    btnDegReset->setFixedWidth(110);
    connect(btnDegReset, &QPushButton::clicked, this, [this]() {
        *m_deg1 = QColor(theme::SCENE_BG);
        *m_deg2 = QColor(config::SCENE_BG2);
        m_sens->setCurrentIndex(0);
        m_peintres.value(m_deg1.get())();
        m_peintres.value(m_deg2.get())();
        majDegrade();
    });
    rowDeg->addSpacing(14);
    rowDeg->addWidget(lblSens);
    rowDeg->addWidget(m_sens);
    rowDeg->addStretch();
    rowDeg->addWidget(btnDegReset);
    dansDeg->addLayout(rowDeg);
    dansDeg->addWidget(m_apercuDeg);
    majDegrade();

    // 4. Une image à soi.
    QVBoxLayout *dansPerso = radio(config::FOND_FICHIER, QStringLiteral("Arrière-plan personnalisé"));
    auto *rowImg = new QHBoxLayout();
    rowImg->setSpacing(8);
    m_bgImage = new QLineEdit();
    m_bgImage->setPlaceholderText(QStringLiteral("Chemin vers une image (PNG, JPG…)"));
    m_bgImage->setText(config::lireTexte(QStringLiteral("scene_bg_image")));
    m_bgImage->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    auto *btnImg = new QPushButton(QStringLiteral("Parcourir…"));
    btnImg->setFixedWidth(100);
    auto *btnImgVide = new QPushButton(QStringLiteral("✕"));
    btnImgVide->setFixedWidth(30);
    btnImgVide->setToolTip(QStringLiteral("Oublier cette image"));
    connect(btnImg, &QPushButton::clicked, this, [this]() {
        const QString chemin = QFileDialog::getOpenFileName(
            this, QStringLiteral("Choisir une image de fond"), depart(),
            QStringLiteral("Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp *.tif *.tiff)"));
        if (!chemin.isEmpty()) {
            m_bgImage->setText(QDir::toNativeSeparators(chemin));
            m_radiosFond.value(config::FOND_FICHIER)->setChecked(true);
        }
    });
    connect(btnImgVide, &QPushButton::clicked, m_bgImage, &QLineEdit::clear);
    rowImg->addWidget(m_bgImage);
    rowImg->addWidget(btnImg);
    rowImg->addWidget(btnImgVide);
    dansPerso->addLayout(rowImg);
    auto *rowMode = new QHBoxLayout();
    rowMode->setSpacing(10);
    m_bgMode = new QComboBox();
    m_bgMode->addItems({QStringLiteral("Remplir"), QStringLiteral("Étirer"), QStringLiteral("Mosaïque")});
    const int rangMode = m_bgMode->findText(config::lireTexte(QStringLiteral("scene_bg_mode"), QStringLiteral("Remplir")));
    if (rangMode >= 0)
        m_bgMode->setCurrentIndex(rangMode);
    m_bgMode->setFixedWidth(120);
    m_bgMode->setStyleSheet(styleCombo());
    rowMode->addWidget(sousTitre(QStringLiteral("Mode :")));
    rowMode->addWidget(m_bgMode);
    rowMode->addStretch();
    dansPerso->addLayout(rowMode);

    // Ce qui est actif suit ce qui est coché.
    auto suivreFond = [this]() {
        for (auto it = m_boitesFond.begin(); it != m_boitesFond.end(); ++it)
            it.value()->setEnabled(m_radiosFond.value(it.key())->isChecked());
    };
    for (QRadioButton *btn : std::as_const(m_radiosFond))
        connect(btn, &QRadioButton::toggled, this, suivreFond);
    m_radiosFond.value(config::sourceFond())->setChecked(true);
    suivreFond();

    bi->addSpacing(12);
    m_paperBg = rangeeCouleur(bi, QStringLiteral("Couleur de la page"),
                              QStringLiteral("Couleur de la page à l'écran. Jamais imprimée (l'impression reste "
                                             "toujours blanche)."),
                              config::lireTexte(QStringLiteral("paper_bg"), QStringLiteral("#e8e8e8")),
                              QStringLiteral("#e8e8e8"));

    bi->addSpacing(12);
    m_titlebar = rangeeCouleur(
        bi, QStringLiteral("Couleur de la barre de titre"),
        QStringLiteral("Barre de titre des fenêtres de Feuillet — celle qui porte le "
                       "trait, le carré et la croix. Feuillet la dessine lui-même, elle "
                       "prend donc n'importe quelle couleur ; le texte et les boutons "
                       "s'y adaptent, clairs sur fond sombre et l'inverse. Les boîtes "
                       "fabriquées par Windows (choix de fichier, choix de couleur) "
                       "gardent la barre du système."),
        config::lireTexte(QStringLiteral("titlebar_color"), apparence::titlebarDefaut()), apparence::titlebarDefaut());

    bi->addSpacing(12);
    bi->addWidget(section(QStringLiteral("Police des boîtes de message")));
    bi->addWidget(aide(QStringLiteral("S'applique à toutes les fenêtres de message de Feuillet. Leur "
                                      "taille suit celle du texte : une grande police donne une grande "
                                      "fenêtre, rien n'est jamais coupé.")));
    const apparence::PoliceMessages pm = apparence::policeMessages();
    auto *rowMsg = new QHBoxLayout();
    rowMsg->setSpacing(10);
    m_msgFont = new QFontComboBox();
    m_msgFont->setCurrentFont(QFont(pm.famille));
    m_msgFont->setMinimumWidth(220);
    m_msgFont->setStyleSheet(QStringLiteral("QFontComboBox { background: %1; color: %2;"
                                            "  border: 1px solid %3; border-radius: 3px;"
                                            "  padding: 3px 8px; font-family: '%4'; font-size: 9pt; }"
                                            "QFontComboBox::drop-down { border: none; }"
                                            "QFontComboBox QAbstractItemView { background: #0c0e12; color: %2;"
                                            "  selection-background-color: #1c2855; }")
                                 .arg(theme::BG_EDITOR, theme::FG, theme::BORDER_COL, theme::FONT_UI));
    m_msgSize = new QSpinBox();
    m_msgSize->setRange(apparence::MSG_TAILLE_MIN, apparence::MSG_TAILLE_MAX);
    m_msgSize->setValue(pm.taille);
    m_msgSize->setSuffix(QStringLiteral(" pt"));
    m_msgSize->setFixedWidth(80);
    m_msgSize->setStyleSheet(QStringLiteral("QSpinBox { background: %1; color: %2;"
                                            "  border: 1px solid %3; border-radius: 3px;"
                                            "  padding: 3px 6px; font-family: '%4'; font-size: 9pt; }")
                                 .arg(theme::BG_EDITOR, theme::FG, theme::BORDER_COL, theme::FONT_UI));
    rowMsg->addWidget(m_msgFont);
    rowMsg->addWidget(sousTitre(QStringLiteral("Taille :")));
    rowMsg->addWidget(m_msgSize);
    rowMsg->addStretch();
    bi->addLayout(rowMsg);
    m_msgColor = rangeeCouleur(bi, QStringLiteral("Couleur du texte des messages"),
                               QStringLiteral("Couleur des lettres dans les fenêtres de message."), pm.couleur,
                               apparence::msgCouleurDefaut());
    m_apercuMsg = new QLabel(QStringLiteral("Aperçu — Feuillet vous dira quelque chose ainsi."));
    m_apercuMsg->setWordWrap(true);
    bi->addSpacing(6);
    bi->addWidget(m_apercuMsg);
    connect(m_msgFont, &QFontComboBox::currentFontChanged, this, [this]() { rafraichirApercuMsg(); });
    connect(m_msgSize, QOverload<int>::of(&QSpinBox::valueChanged), this, [this]() { rafraichirApercuMsg(); });
    rafraichirApercuMsg();
    bi->addStretch();

    auto *defile = new QScrollArea();
    defile->setWidget(tabInterface);
    defile->setWidgetResizable(true);
    defile->setFrameShape(QFrame::NoFrame);
    defile->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BG_WIN));
    onglets->addTab(defile, QStringLiteral("🎨  Interface"));

    // ─── Onglet 3 — Qualité de rendu ───────────────────────────────────
    auto *tabQualite = new QWidget();
    tabQualite->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BG_WIN));
    auto *bq = new QVBoxLayout(tabQualite);
    bq->setContentsMargins(28, 28, 28, 20);
    bq->setSpacing(10);
    bq->addWidget(section(QStringLiteral("Résolution de rendu des documents")));
    bq->addWidget(aide(QStringLiteral(
        "S'applique à tout ce que Feuillet doit convertir en image : PDF, "
        "documents Word / Excel / PowerPoint / OpenDocument, HTML, TXT et SVG.\n\n"
        "Les images (JPG, PNG, TIFF, RAW, PSD…) ne sont jamais rééchantillonnées : "
        "elles conservent toujours leur résolution d'origine, quelle que soit "
        "la taille à laquelle vous les placez sur la page.\n\n"
        "300 ppp convient à l'immense majorité des impressions. 600 ppp n'apporte "
        "un gain visible que sur des documents très denses (petits caractères, "
        "plans, tableaux serrés) et alourdit nettement la mémoire et les fichiers "
        ".feuillet.")));
    bq->addSpacing(8);
    auto *rowDpi = new QHBoxLayout();
    rowDpi->setSpacing(10);
    m_dpi = new QComboBox();
    m_choixDpi = {{QStringLiteral("Écran — 96 ppp (rapide)"), 96},
                  {QStringLiteral("Correcte — 150 ppp"), 150},
                  {QStringLiteral("Impression — 300 ppp  (recommandé)"), 300},
                  {QStringLiteral("Fine — 400 ppp"), 400},
                  {QStringLiteral("Maximale — 600 ppp  (lourd)"), 600}};
    for (const auto &c : std::as_const(m_choixDpi))
        m_dpi->addItem(c.first);
    {
        const int courant = config::renderDpi();
        int meilleur = 0;
        for (int i = 1; i < m_choixDpi.size(); ++i)
            if (qAbs(m_choixDpi[i].second - courant) < qAbs(m_choixDpi[meilleur].second - courant))
                meilleur = i;
        m_dpi->setCurrentIndex(meilleur);
    }
    m_dpi->setFixedWidth(260);
    m_dpi->setStyleSheet(styleCombo());
    rowDpi->addWidget(sousTitre(QStringLiteral("Qualité :")));
    rowDpi->addWidget(m_dpi);
    rowDpi->addStretch();
    bq->addLayout(rowDpi);
    bq->addSpacing(6);
    bq->addWidget(aide(QStringLiteral("La modification s'applique aux documents ouverts ensuite ; "
                                      "les éléments déjà posés sur la page gardent leur rendu actuel.")));
    bq->addStretch();
    onglets->addTab(tabQualite, QStringLiteral("🖨  Qualité"));

    // ─── Onglet 4 — Driver ─────────────────────────────────────────────
    auto *tabDriver = new QWidget();
    tabDriver->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BG_WIN));
    auto *bd = new QVBoxLayout(tabDriver);
    bd->setContentsMargins(28, 28, 28, 20);
    bd->setSpacing(10);
    bd->addWidget(section(QStringLiteral("Imprimante virtuelle « Feuillet »")));
    bd->addWidget(aide(QStringLiteral(
        "Installe une imprimante Windows nommée « Feuillet ». Ensuite, dans "
        "n'importe quel logiciel, Fichier ▸ Imprimer ▸ Feuillet enverra le "
        "document directement dans l'Atelier, chacune de "
        "ses pages arrivant comme un élément posé sur la page.\n\n"
        "Techniquement : l'imprimante s'appuie sur le pilote « Microsoft Print "
        "to PDF » déjà présent dans Windows, et un guetteur invisible, démarré "
        "avec la session, ouvre Feuillet dès qu'une impression arrive. Comme "
        "l'installation part d'ici, le driver connaît le chemin exact de "
        "Feuillet ; si vous déplacez le programme un jour, il suffira de "
        "cliquer à nouveau sur « Installer le driver ».\n\n"
        "La création de l'imprimante demande une élévation : Windows affichera "
        "une fenêtre de contrôle de compte d'utilisateur.")));
    bd->addSpacing(8);
    m_drvRogner = new QCheckBox(QStringLiteral("Rogner les bords blancs des impressions reçues"));
    m_drvRogner->setChecked(config::driverRognerBlanc());
    m_drvRogner->setCursor(Qt::PointingHandCursor);
    m_drvRogner->setStyleSheet(styleCase());
    bd->addWidget(m_drvRogner);
    bd->addWidget(aide(QStringLiteral(
        "Un logiciel qui imprime dessine toujours sur une page entière : une "
        "image imprimée depuis GIMP arriverait encapsulée dans une A4 blanche. "
        "Cette option détecte le contenu réel de chaque page reçue et rogne le "
        "blanc autour — l'image arrive alors nue, comme à l'import direct du "
        "fichier. Décochez-la si vous préférez recevoir les pages entières, "
        "marges comprises (du texte imprimé, par exemple, perd lui aussi ses "
        "marges quand elle est active).")));
    bd->addSpacing(8);
    m_etatDriver = sousTitre(QString());
    m_etatDriver->setWordWrap(true);
    bd->addWidget(m_etatDriver);
    bd->addSpacing(6);
    auto *rowDrv = new QHBoxLayout();
    rowDrv->setSpacing(10);
    m_btnInstaller = new QPushButton(QStringLiteral("🖨  Installer le driver"));
    m_btnInstaller->setMinimumHeight(36);
    m_btnInstaller->setMinimumWidth(190);
    connect(m_btnInstaller, &QPushButton::clicked, this, &OptionsDialog::installerDriver);
    ui::addShadow(m_btnInstaller);
    m_btnDesinstaller = new QPushButton(QStringLiteral("Désinstaller le driver"));
    m_btnDesinstaller->setMinimumHeight(36);
    connect(m_btnDesinstaller, &QPushButton::clicked, this, &OptionsDialog::desinstallerDriver);
    rowDrv->addWidget(m_btnInstaller);
    rowDrv->addWidget(m_btnDesinstaller);
    rowDrv->addStretch();
    bd->addLayout(rowDrv);
    bd->addStretch();
    onglets->addTab(tabDriver, QStringLiteral("🧩  Driver"));
    rafraichirEtatDriver();

    // Onglet sélectionné : bordeaux, règle commune de la suite.
    onglets->setStyleSheet(QStringLiteral("QTabWidget::pane { background: %1; border: none;"
                                          "  border-top: 1px solid %2; }"
                                          "QTabBar::tab { background: %3; color: #8a92aa; border: none;"
                                          "  padding: 8px 22px; font-family: '%4'; font-size: 9pt; }"
                                          "QTabBar::tab:selected { background: %5; color: #ffffff;"
                                          "  font-weight: bold; border-bottom: 2px solid %5; }"
                                          "QTabBar::tab:hover:!selected { color: %6; }")
                               .arg(theme::BG_WIN, theme::BORDER_COL, theme::TOOLBAR_BG, theme::FONT_UI, BORDEAUX,
                                    theme::ACCENT));
    root->addWidget(onglets);

    // ─── Barre du bas ──────────────────────────────────────────────────
    auto *barre = new QWidget();
    barre->setStyleSheet(QStringLiteral("background: %1; border-top: 1px solid %2;")
                             .arg(theme::TOOLBAR_BG, theme::BORDER_COL));
    auto *barL = new QHBoxLayout(barre);
    barL->setContentsMargins(16, 10, 16, 10);
    barL->setSpacing(8);
    auto *ok = new QPushButton(QStringLiteral("✔  Enregistrer"));
    ok->setMinimumHeight(34);
    auto *annuler = new QPushButton(QStringLiteral("Annuler"));
    annuler->setMinimumHeight(34);
    connect(ok, &QPushButton::clicked, this, &OptionsDialog::enregistrerEtFermer);
    connect(annuler, &QPushButton::clicked, this, &QDialog::reject);
    ui::addShadow(ok);
    barL->addStretch();
    barL->addWidget(ok);
    barL->addWidget(annuler);
    root->addWidget(barre);

    cadre::poserCadre(this, false, false);
    memoire::retenir(this, QStringLiteral("options"));
}

void OptionsDialog::majDegrade()
{
    m_apercuDeg->regler(*m_deg1, *m_deg2, m_sens->currentText());
}

void OptionsDialog::rafraichirApercuMsg()
{
    if (!m_apercuMsg || !m_msgColor)
        return;
    m_apercuMsg->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: %3pt;"
                                              "background: %4; border: 1px solid %5;"
                                              "border-radius: 3px; padding: 10px 12px;")
                                   .arg(m_msgColor->name(), m_msgFont->currentFont().family())
                                   .arg(m_msgSize->value())
                                   .arg(theme::BG_EDITOR, theme::BORDER_COL));
}

void OptionsDialog::rafraichirEtatDriver()
{
#ifndef Q_OS_WIN
    m_etatDriver->setText(QStringLiteral("État : l'imprimante virtuelle n'est disponible que sous Windows."));
    m_btnInstaller->setEnabled(false);
    m_btnDesinstaller->setEnabled(false);
#else
    const bool inst = driver::imprimanteInstallee();
    const bool guet = driver::guetteurActif();
    QString etat;
    if (inst) {
        etat = QStringLiteral("État : imprimante « Feuillet » installée ✔");
        etat += guet ? QStringLiteral("  ·  guetteur actif ✔")
                     : QStringLiteral("  ·  guetteur arrêté ✘ (cliquez sur « Installer le driver » pour le relancer)");
    } else {
        etat = QStringLiteral("État : imprimante « Feuillet » non installée.");
    }
    m_etatDriver->setText(etat);
    m_btnDesinstaller->setEnabled(inst);
#endif
}

void OptionsDialog::installerDriver()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const driver::Resultat r = driver::installer();
    QApplication::restoreOverrideCursor();
    if (r.ok)
        QMessageBox::information(this, QStringLiteral("Driver Feuillet"), r.message);
    else
        QMessageBox::critical(this, QStringLiteral("Driver Feuillet"), r.message);
    rafraichirEtatDriver();
}

void OptionsDialog::desinstallerDriver()
{
    if (QMessageBox::question(this, QStringLiteral("Driver Feuillet"),
                              QStringLiteral("Retirer l'imprimante « Feuillet » et arrêter le guetteur ?"),
                              QMessageBox::Yes | QMessageBox::No, QMessageBox::No)
        != QMessageBox::Yes)
        return;
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const driver::Resultat r = driver::desinstaller();
    QApplication::restoreOverrideCursor();
    if (r.ok)
        QMessageBox::information(this, QStringLiteral("Driver Feuillet"), r.message);
    else
        QMessageBox::warning(this, QStringLiteral("Driver Feuillet"), r.message);
    rafraichirEtatDriver();
}

void OptionsDialog::parcourirReferent()
{
    QString dep = m_referent->text().trimmed();
    if (dep.isEmpty())
        dep = config::departFichier();
    const QString dossier =
        QFileDialog::getExistingDirectory(this, QStringLiteral("Choisir le dossier référent"), dep);
    if (!dossier.isEmpty())
        m_referent->setText(QDir::toNativeSeparators(dossier));
}

QString OptionsDialog::depart(const QString &nomPropose) const
{
    // Le champ prime : un dossier tout juste choisi sert avant l'enregistrement.
    const QString saisi = m_referent->text().trimmed();
    if (!saisi.isEmpty() && QFileInfo(saisi).isDir())
        return nomPropose.isEmpty() ? saisi : QDir(saisi).filePath(nomPropose);
    return config::departFichier(nomPropose);
}

int OptionsDialog::dpiChoisi() const
{
    const int i = m_dpi->currentIndex();
    if (i >= 0 && i < m_choixDpi.size())
        return m_choixDpi[i].second;
    return config::DEFAULT_RENDER_DPI;
}

QString OptionsDialog::valeurFond() const
{
    for (auto it = m_radiosFond.begin(); it != m_radiosFond.end(); ++it)
        if (it.value()->isChecked())
            return it.key();
    return config::FOND_INTEGRE;
}

void OptionsDialog::enregistrerEtFermer()
{
    config::poser(QStringLiteral("dossier_referent"), m_referent->text().trimmed());
    config::poser(QStringLiteral("scene_bg"), m_sceneBg->name());
    config::poser(QStringLiteral("paper_bg"), m_paperBg->name());
    config::poser(QStringLiteral("scene_bg_source"), valeurFond());
    config::poser(QStringLiteral("scene_bg_deg1"), m_deg1->name());
    config::poser(QStringLiteral("scene_bg_deg2"), m_deg2->name());
    config::poser(QStringLiteral("scene_bg_sens"), m_sens->currentText());
    config::poser(QStringLiteral("scene_bg_image"), m_bgImage->text().trimmed());
    config::poser(QStringLiteral("scene_bg_mode"), m_bgMode->currentText());
    config::poser(QStringLiteral("render_dpi"), dpiChoisi());
    config::poser(QStringLiteral("driver_rogner_blanc"), m_drvRogner->isChecked());
    config::poser(QStringLiteral("lecteur_pdf"), m_lecteurPdf->text().trimmed());
    config::poser(QStringLiteral("ouvrir_pdf_apres"), m_ouvrirPdf->isChecked());
    config::poser(QStringLiteral("titlebar_color"), m_titlebar->name());
    config::poser(QStringLiteral("msg_font"), m_msgFont->currentFont().family());
    config::poser(QStringLiteral("msg_font_size"), m_msgSize->value());
    config::poser(QStringLiteral("msg_font_color"), m_msgColor->name());
    config::enregistrer();
    // Ces réglages prennent effet tout de suite.
    apparence::appliquerStyle(qApp);
    apparence::reappliquerTitlebar();
    cadre::recolorerTout();
    accept();
}

void OptionsDialog::parcourirLecteurPdf()
{
    QString dep = m_lecteurPdf->text().trimmed();
    if (dep.isEmpty())
        dep = depart();
    const QString chemin = QFileDialog::getOpenFileName(this, QStringLiteral("Choisir le lecteur PDF"), dep,
                                                        QStringLiteral("Programmes (*.exe);;Tous les fichiers (*)"));
    if (!chemin.isEmpty())
        m_lecteurPdf->setText(QDir::toNativeSeparators(chemin));
}

void OptionsDialog::exporterConfig()
{
    const QString chemin = QFileDialog::getSaveFileName(this, QStringLiteral("Exporter la configuration"),
                                                        depart(QStringLiteral("feuillet_config.json")),
                                                        QStringLiteral("Fichier JSON (*.json)"));
    if (chemin.isEmpty())
        return;
    QJsonObject cfg;
    // Les chemins des convertisseurs voyagent avec la configuration.
    cfg.insert(QStringLiteral("convertisseurs"), config::lire(QStringLiteral("convertisseurs")).toObject());
    cfg.insert(QStringLiteral("dossier_referent"), m_referent->text().trimmed());
    cfg.insert(QStringLiteral("scene_bg"), m_sceneBg->name());
    cfg.insert(QStringLiteral("paper_bg"), m_paperBg->name());
    cfg.insert(QStringLiteral("scene_bg_source"), valeurFond());
    cfg.insert(QStringLiteral("scene_bg_deg1"), m_deg1->name());
    cfg.insert(QStringLiteral("scene_bg_deg2"), m_deg2->name());
    cfg.insert(QStringLiteral("scene_bg_sens"), m_sens->currentText());
    cfg.insert(QStringLiteral("scene_bg_image"), m_bgImage->text().trimmed());
    cfg.insert(QStringLiteral("scene_bg_mode"), m_bgMode->currentText());
    cfg.insert(QStringLiteral("render_dpi"), dpiChoisi());
    cfg.insert(QStringLiteral("driver_rogner_blanc"), m_drvRogner->isChecked());
    cfg.insert(QStringLiteral("titlebar_color"), m_titlebar->name());
    cfg.insert(QStringLiteral("msg_font"), m_msgFont->currentFont().family());
    cfg.insert(QStringLiteral("msg_font_size"), m_msgSize->value());
    cfg.insert(QStringLiteral("msg_font_color"), m_msgColor->name());
    QSaveFile f(chemin);
    if (f.open(QIODevice::WriteOnly) && f.write(QJsonDocument(cfg).toJson(QJsonDocument::Indented)) >= 0
        && f.commit())
        QMessageBox::information(this, QStringLiteral("Export"), QStringLiteral("Configuration exportée avec succès."));
    else
        QMessageBox::critical(this, QStringLiteral("Erreur"), QStringLiteral("Impossible d'exporter :\n%1").arg(chemin));
}

void OptionsDialog::importerConfig()
{
    const QString chemin = QFileDialog::getOpenFileName(this, QStringLiteral("Importer une configuration"), depart(),
                                                        QStringLiteral("Fichier JSON (*.json)"));
    if (chemin.isEmpty())
        return;
    QFile f(chemin);
    QJsonParseError err;
    const QJsonDocument doc = f.open(QIODevice::ReadOnly) ? QJsonDocument::fromJson(f.readAll(), &err) : QJsonDocument();
    if (!doc.isObject()) {
        QMessageBox::critical(this, QStringLiteral("Erreur"), QStringLiteral("Impossible d'importer :\n%1").arg(chemin));
        return;
    }
    const QJsonObject cfg = doc.object();
    QJsonObject chemins = cfg.value(QStringLiteral("convertisseurs")).toObject();
    if (!cfg.value(QStringLiteral("convertisseurs")).isObject()) {
        chemins.insert(QStringLiteral("word"), cfg.value(QStringLiteral("msoffice_word")).toString());
        chemins.insert(QStringLiteral("libreoffice"), cfg.value(QStringLiteral("libreoffice_soffice")).toString());
    }
    for (auto it = chemins.begin(); it != chemins.end(); ++it)
        if (cv::table().contains(it.key()))
            cv::retenir(it.key(), it.value().toString());
    if (cfg.contains(QStringLiteral("dossier_referent")))
        m_referent->setText(cfg.value(QStringLiteral("dossier_referent")).toString());
    if (cfg.contains(QStringLiteral("render_dpi"))) {
        const int dpi = cfg.value(QStringLiteral("render_dpi")).toInt(config::DEFAULT_RENDER_DPI);
        int meilleur = 0;
        for (int i = 1; i < m_choixDpi.size(); ++i)
            if (qAbs(m_choixDpi[i].second - dpi) < qAbs(m_choixDpi[meilleur].second - dpi))
                meilleur = i;
        m_dpi->setCurrentIndex(meilleur);
    }
    if (cfg.contains(QStringLiteral("driver_rogner_blanc")))
        m_drvRogner->setChecked(cfg.value(QStringLiteral("driver_rogner_blanc")).toBool());
    auto couleur = [&](const char *cle, const std::shared_ptr<QColor> &ref) {
        const QString v = cfg.value(QLatin1String(cle)).toString();
        if (!v.isEmpty() && QColor(v).isValid()) {
            *ref = QColor(v);
            if (m_peintres.contains(ref.get()))
                m_peintres.value(ref.get())();
        }
    };
    couleur("titlebar_color", m_titlebar);
    couleur("msg_font_color", m_msgColor);
    couleur("scene_bg", m_sceneBg);
    couleur("paper_bg", m_paperBg);
    couleur("scene_bg_deg1", m_deg1);
    couleur("scene_bg_deg2", m_deg2);
    if (cfg.contains(QStringLiteral("scene_bg_sens"))) {
        const int r = m_sens->findText(cfg.value(QStringLiteral("scene_bg_sens")).toString());
        if (r >= 0)
            m_sens->setCurrentIndex(r);
    }
    if (cfg.contains(QStringLiteral("scene_bg_image")))
        m_bgImage->setText(cfg.value(QStringLiteral("scene_bg_image")).toString());
    if (cfg.contains(QStringLiteral("scene_bg_mode"))) {
        const int r = m_bgMode->findText(cfg.value(QStringLiteral("scene_bg_mode")).toString());
        if (r >= 0)
            m_bgMode->setCurrentIndex(r);
    }
    const QString source = cfg.value(QStringLiteral("scene_bg_source")).toString();
    if (m_radiosFond.contains(source))
        m_radiosFond.value(source)->setChecked(true);
    if (!cfg.value(QStringLiteral("msg_font")).toString().isEmpty())
        m_msgFont->setCurrentFont(QFont(cfg.value(QStringLiteral("msg_font")).toString()));
    if (cfg.value(QStringLiteral("msg_font_size")).toInt() > 0)
        m_msgSize->setValue(cfg.value(QStringLiteral("msg_font_size")).toInt());
    majDegrade();
    rafraichirApercuMsg();
    QMessageBox::information(this, QStringLiteral("Import"),
                             QStringLiteral("Configuration importée.\nCliquez sur Enregistrer pour l'appliquer."));
}
