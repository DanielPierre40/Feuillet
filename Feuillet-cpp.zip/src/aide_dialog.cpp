#include "aide_dialog.h"

#include "apparence.h"
#include "barre_titre.h"
#include "memoire_fenetres.h"
#include "theme.h"
#include "ui_helpers.h"
#include "version.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>

namespace {
const QString TEXTE = QStringLiteral("Vous trouverez toute l'aide nécessaire dans le fichier PDF joint au "
                                     "programme au moment du téléchargement.");
const QString FOND = QStringLiteral("#14171d");
} // namespace

AideDialog::AideDialog(QWidget *parent) : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Aide — Feuillet"));
    setModal(true);
    const apparence::PoliceMessages p = apparence::policeMessages();
    const int largeur = LARGEUR + qMax(0, p.taille - 10) * 30;
    setMinimumWidth(LARGEUR_MINI + qMax(0, p.taille - 10) * 20);

    auto *corps = new QVBoxLayout(this);
    corps->setContentsMargins(28, 20, 28, 22);
    corps->setSpacing(0);

    auto *titre = new QLabel(QStringLiteral("❔   Aide"));
    titre->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: %3pt;"
                                        "font-weight: 600; background: transparent;")
                             .arg(theme::FG, p.famille)
                             .arg(p.taille + 4));
    corps->addWidget(titre);

    auto *sep = new QWidget();
    sep->setFixedHeight(1);
    sep->setStyleSheet(QStringLiteral("background: %1;").arg(cadre::LISERE));
    corps->addSpacing(14);
    corps->addWidget(sep);
    corps->addSpacing(18);

    m_mot = new QLabel(TEXTE);
    m_mot->setWordWrap(true);
    m_mot->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    m_mot->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: %3pt;"
                                        "background: transparent;")
                             .arg(p.couleur, p.famille)
                             .arg(p.taille));
    corps->addWidget(m_mot);

    auto *ver = new QLabel(QStringLiteral("Version du programme : n° %1").arg(QStringLiteral(FEUILLET_VERSION)));
    ver->setStyleSheet(QStringLiteral("color: #8a92aa; font-family: '%1';"
                                      " font-size: %2pt; background: transparent;")
                           .arg(p.famille)
                           .arg(qMax(8, p.taille - 1)));
    // Ce qui dépasse s'accumule ICI : version et bouton restent collés en bas.
    corps->addStretch();
    m_ressort = corps->itemAt(corps->count() - 1);
    corps->addSpacing(12);
    corps->addWidget(ver);
    corps->addSpacing(22);

    auto *rangee = new QHBoxLayout();
    rangee->addStretch();
    auto *fermer = new QPushButton(QStringLiteral("Fermer"));
    fermer->setMinimumHeight(int(p.taille * 3.6));
    fermer->setMinimumWidth(int(p.taille * 13));
    fermer->setCursor(Qt::PointingHandCursor);
    fermer->setStyleSheet(QStringLiteral("QPushButton { background: %1; color: %2;"
                                         "  border: 1px solid %3; border-radius: 3px;"
                                         "  padding: 5px 18px;"
                                         "  font-family: '%4'; font-size: %5pt; }"
                                         "QPushButton:hover { background: %6; color: %7;"
                                         "  border-color: %7; }"
                                         "QPushButton:pressed { background: %8; }")
                              .arg(theme::BG_BTN, theme::FG, theme::BD_BTN, p.famille)
                              .arg(qMax(8, p.taille - 1))
                              .arg(theme::BG_BTN_HOV, theme::ACCENT, theme::BG_BTN_PRS));
    connect(fermer, &QPushButton::clicked, this, &QDialog::accept);
    fermer->setDefault(true);
    ui::addShadow(fermer);
    rangee->addWidget(fermer);
    corps->addLayout(rangee);

    cadre::poserCadre(this, false, false, FOND);
    resize(largeur, sizeHint().height());
    cadre::poserPoignee(this);
    // Une taille retenue est une taille CHOISIE : on ne la reprend pas.
    if (memoire::retenir(this, QStringLiteral("aide")))
        m_hauteurLibre = true;
}

void AideDialog::resizeEvent(QResizeEvent *e)
{
    QDialog::resizeEvent(e);
    if (!m_enAjustement && m_hauteurPosee >= 0 && height() != m_hauteurPosee)
        m_hauteurLibre = true;
    ajusterHauteur();
}

void AideDialog::showEvent(QShowEvent *e)
{
    QDialog::showEvent(e);
    if (m_habillage < 0) {
        if (layout())
            layout()->activate();
        // La place en trop (le ressort) est RETIRÉE de la mesure.
        m_habillage = height() - m_mot->height() - (m_ressort ? m_ressort->geometry().height() : 0);
    }
    ajusterHauteur();
}

void AideDialog::ajusterHauteur()
{
    if (m_enAjustement || m_habillage < 0)
        return;
    if (layout())
        layout()->activate();
    const int largeur = m_mot->width();
    if (largeur <= 0)
        return;
    // Mesuré à la règle, par les métriques de la police : heightForWidth rend
    // la hauteur figée dès qu'on en a figé une.
    const int hauteur = m_mot->fontMetrics()
                            .boundingRect(QRect(0, 0, largeur, 100000), Qt::TextWordWrap, m_mot->text())
                            .height()
                        + 4;
    const int voulue = m_habillage + hauteur;
    if (m_mot->height() == hauteur && minimumHeight() == voulue)
        if (m_hauteurLibre || height() == voulue)
            return;
    m_enAjustement = true;
    m_mot->setFixedHeight(hauteur);
    // Bornée PAR LE BAS seulement : le texte n'est jamais coupé.
    setMinimumHeight(voulue);
    if (m_hauteurLibre) {
        if (height() < voulue) {
            resize(width(), voulue);
            m_hauteurPosee = voulue;
        }
    } else {
        resize(width(), voulue);
        m_hauteurPosee = voulue;
    }
    m_enAjustement = false;
}
