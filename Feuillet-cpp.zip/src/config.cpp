#include "config.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QMutex>
#include <QMutexLocker>
#include <QSaveFile>

namespace config {

namespace {

QRecursiveMutex &verrou()
{
    static QRecursiveMutex m;
    return m;
}

QJsonObject charger()
{
    QFile f(cheminFichier());
    if (f.open(QIODevice::ReadOnly)) {
        QJsonParseError err;
        const QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
        if (err.error == QJsonParseError::NoError && doc.isObject())
            return doc.object();
    }
    QJsonObject defaut;
    defaut.insert(QStringLiteral("msoffice_word"), QString());
    defaut.insert(QStringLiteral("libreoffice_soffice"), QString());
    defaut.insert(QStringLiteral("render_dpi"), DEFAULT_RENDER_DPI);
    return defaut;
}

QJsonObject &cfg()
{
    static QJsonObject c = charger();
    return c;
}

} // namespace

QString cheminFichier()
{
    return QDir(QDir::homePath()).filePath(QStringLiteral(".feuillet_config.json"));
}

QJsonValue lire(const QString &cle, const QJsonValue &defaut)
{
    QMutexLocker l(&verrou());
    const QJsonValue v = cfg().value(cle);
    return v.isUndefined() ? defaut : v;
}

QString lireTexte(const QString &cle, const QString &defaut)
{
    const QJsonValue v = lire(cle);
    if (v.isString())
        return v.toString();
    if (v.isDouble())
        return QString::number(v.toDouble());
    if (v.isBool())
        return v.toBool() ? QStringLiteral("True") : QStringLiteral("False");
    return defaut;
}

bool lireBool(const QString &cle, bool defaut)
{
    // Clé absente : la valeur par défaut (un QJsonValue vide vaut « null »,
    // qui, lui, se lit faux — il ne faut pas les confondre).
    const QJsonValue v = lire(cle, QJsonValue(QJsonValue::Undefined));
    if (v.isUndefined())
        return defaut;
    if (v.isBool())
        return v.toBool();
    if (v.isDouble())
        return v.toDouble() != 0.0;
    if (v.isString())
        return !v.toString().isEmpty();
    if (v.isNull())
        return false;
    return defaut;
}

void poser(const QString &cle, const QJsonValue &valeur)
{
    QMutexLocker l(&verrou());
    cfg().insert(cle, valeur);
}

void retirer(const QString &cle)
{
    QMutexLocker l(&verrou());
    cfg().remove(cle);
}

QJsonObject tout()
{
    QMutexLocker l(&verrou());
    return cfg();
}

void remplacer(const QJsonObject &nouvelle)
{
    QMutexLocker l(&verrou());
    cfg() = nouvelle;
}

bool enregistrer()
{
    QByteArray donnees;
    {
        QMutexLocker l(&verrou());
        donnees = QJsonDocument(cfg()).toJson(QJsonDocument::Indented);
    }
    QSaveFile f(cheminFichier());
    if (!f.open(QIODevice::WriteOnly))
        return false;
    f.write(donnees);
    return f.commit();
}

int renderDpi()
{
    const QJsonValue v = lire(QStringLiteral("render_dpi"), DEFAULT_RENDER_DPI);
    int dpi = DEFAULT_RENDER_DPI;
    if (v.isDouble())
        dpi = int(v.toDouble());
    else if (v.isString()) {
        bool ok = false;
        const int n = v.toString().toInt(&ok);
        if (ok)
            dpi = n;
    }
    return qBound(MIN_RENDER_DPI, dpi, MAX_RENDER_DPI);
}

bool driverRognerBlanc()
{
    return lireBool(QStringLiteral("driver_rogner_blanc"), true);
}

QString sourceFond()
{
    const QString valeur = lireTexte(QStringLiteral("scene_bg_source")).trimmed();
    if (valeur == FOND_INTEGRE || valeur == FOND_COULEUR || valeur == FOND_DEGRADE
        || valeur == FOND_FICHIER)
        return valeur;
    // Anciennes configurations : un chemin d'image déjà en place est respecté.
    if (!lireTexte(QStringLiteral("scene_bg_image")).trimmed().isEmpty())
        return FOND_FICHIER;
    return FOND_INTEGRE;
}

QString dossierReferent()
{
    return lireTexte(QStringLiteral("dossier_referent")).trimmed();
}

QString lecteurPdf()
{
    return lireTexte(QStringLiteral("lecteur_pdf")).trimmed();
}

bool ouvrirPdfApres()
{
    return lireBool(QStringLiteral("ouvrir_pdf_apres"), true);
}

QString departFichier(const QString &nomPropose)
{
    const QString dossier = dossierReferent();
    if (dossier.isEmpty() || !QFileInfo(dossier).isDir())
        return nomPropose;
    return nomPropose.isEmpty() ? dossier : QDir(dossier).filePath(nomPropose);
}

QJsonObject agencementBarres()
{
    const QJsonValue v = lire(QStringLiteral("agencement_barres"));
    return v.isObject() ? v.toObject() : QJsonObject();
}

void setAgencementBarres(const QJsonObject &agencement)
{
    // Écrit tout de suite : l'Atelier est reconstruit à chaque impression.
    poser(QStringLiteral("agencement_barres"), agencement);
    enregistrer();
}

} // namespace config
