#include "apres_impression.h"

#include "barre_titre.h"
#include "theme.h"
#include "ui_helpers.h"

#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>

QList<ApresImpressionDialog::Porte> ApresImpressionDialog::portesImpression()
{
    return {
        {QStringLiteral("↩️   Revenir au travail actuel"),
         QStringLiteral("Retour à l'Atelier, la mise en page intacte — pour réimprimer, "
                        "retoucher ou sauvegarder."),
         REVENIR, true},
        {QStringLiteral("💾   Sauvegarder le feuillet, puis quitter"),
         QStringLiteral("La mise en page est enregistrée en .feuillet ; Feuillet se ferme "
                        "ensuite tout seul."),
         SAUVER, false},
        {QStringLiteral("🔄   Nouveau travail"),
         QStringLiteral("Retour à l'accueil pour ouvrir d'autres fichiers. La mise en page "
                        "en cours est abandonnée."),
         NOUVEAU, false},
        {QStringLiteral("✕   Quitter Feuillet"), QStringLiteral("Fermeture immédiate, sans rien enregistrer."),
         QUITTER, false},
    };
}

ApresImpressionDialog::ApresImpressionDialog(QWidget *parent, const QString &titreFenetre,
                                             const QString &titre, const QString &sousTitre,
                                             const QList<Porte> &portes, int defaut)
    : QDialog(parent), m_choix(defaut)
{
    setWindowTitle(titreFenetre);
    setModal(true);
    setMinimumWidth(460);

    auto *root = new QVBoxLayout(this);
    root->setContentsMargins(28, 24, 28, 24);
    root->setSpacing(0);

    auto *lblTitre = new QLabel(titre);
    lblTitre->setAlignment(Qt::AlignCenter);
    lblTitre->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: 16pt;"
                                           "font-weight: 600; background: transparent;")
                                .arg(theme::FG, theme::FONT_UI));
    root->addWidget(lblTitre);

    auto *sous = new QLabel(sousTitre);
    sous->setAlignment(Qt::AlignCenter);
    sous->setWordWrap(true);
    sous->setStyleSheet(QStringLiteral("color: #8a92aa; font-family: '%1'; font-size: 10pt;"
                                       "background: transparent; margin-top: 4px;")
                            .arg(theme::FONT_UI));
    root->addWidget(sous);

    auto *sep = new QWidget();
    sep->setFixedHeight(1);
    sep->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BORDER_COL));
    root->addSpacing(18);
    root->addWidget(sep);
    root->addSpacing(18);

    for (int i = 0; i < portes.size(); ++i)
        ajouterBouton(root, portes[i], i == portes.size() - 1);

    cadre::poserCadre(this, false, false);
}

void ApresImpressionDialog::ajouterBouton(QVBoxLayout *layout, const Porte &porte, bool dernier)
{
    const QString bordure = porte.principale ? theme::ACCENT : theme::BD_BTN;
    auto *btn = new QPushButton(porte.texte);
    btn->setMinimumHeight(48);
    btn->setCursor(Qt::PointingHandCursor);
    btn->setStyleSheet(QStringLiteral("QPushButton { background: %1; color: %2;"
                                      "  border: 1px solid %3; border-radius: 4px;"
                                      "  padding: 8px 16px; text-align: left;"
                                      "  font-family: '%4'; font-size: 11pt; }"
                                      "QPushButton:hover { background: %5; color: %6;"
                                      "  border-color: %6; }"
                                      "QPushButton:pressed { background: %7; }")
                           .arg(theme::BG_BTN, theme::FG, bordure, theme::FONT_UI, theme::BG_BTN_HOV,
                                theme::ACCENT, theme::BG_BTN_PRS));
    const int choix = porte.choix;
    connect(btn, &QPushButton::clicked, this, [this, choix]() {
        m_choix = choix;
        accept();
    });
    ui::addShadow(btn);
    layout->addWidget(btn);

    auto *lbl = new QLabel(porte.explication);
    lbl->setWordWrap(true);
    lbl->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: 8pt;"
                                      "background: transparent; margin: 4px 4px 0 4px;")
                           .arg(theme::FG2, theme::FONT_UI));
    layout->addWidget(lbl);
    if (!dernier)
        layout->addSpacing(16);
}

int ApresImpressionDialog::demander()
{
    exec();
    return m_choix;
}

int demanderDestination(QWidget *parent)
{
    const QList<ApresImpressionDialog::Porte> portes = {
        {QStringLiteral("📄   Imprimer en PDF"),
         QStringLiteral("Feuillet fabrique lui-même le fichier PDF, sans passer par une "
                        "imprimante. Il demande seulement où le ranger."),
         ApresImpressionDialog::PDF, true},
        {QStringLiteral("🖨️   Imprimantes de l'ordinateur"),
         QStringLiteral("Ouvre la fenêtre d'impression de Windows : choix de l'imprimante, "
                        "des pages et des réglages."),
         ApresImpressionDialog::IMPRIMANTE, false},
    };
    ApresImpressionDialog d(parent, QStringLiteral("Imprimer — Feuillet"), QStringLiteral("🖨️   Imprimer"),
                            QStringLiteral("Où envoyer les pages ?"), portes, ApresImpressionDialog::ANNULER);
    return d.demander();
}

int demanderAvantDeQuitter(QWidget *parent)
{
    const QList<ApresImpressionDialog::Porte> portes = {
        {QStringLiteral("💾   Sauvegarder le feuillet, puis quitter"),
         QStringLiteral("La mise en page est enregistrée en .feuillet ; Feuillet se "
                        "ferme ensuite tout seul. Un feuillet enregistré se rouvre "
                        "depuis l'accueil, par « Importer un feuillet »."),
         ApresImpressionDialog::SAUVER, true},
        {QStringLiteral("✕   Quitter sans enregistrer"),
         QStringLiteral("Fermeture immédiate. La mise en page en cours est perdue."),
         ApresImpressionDialog::QUITTER, false},
        {QStringLiteral("←   Revenir à l'Atelier"), QStringLiteral("Rien n'est fermé : on retourne à la mise en page."),
         ApresImpressionDialog::ANNULER, false},
    };
    ApresImpressionDialog d(parent, QStringLiteral("Quitter Feuillet"), QStringLiteral("✕   Quitter Feuillet"),
                            QStringLiteral("Le travail en cours n'a pas été enregistré."), portes,
                            ApresImpressionDialog::ANNULER);
    return d.demander();
}
