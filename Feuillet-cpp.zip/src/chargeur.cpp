#include "chargeur.h"

#include "config.h"
#include "convertisseurs.h"
#include "driver_feuillet.h"
#include "lecteurs_images.h"
#include "office_com.h"
#include "workers.h"

#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QFileInfo>
#include <QImageReader>
#include <QMessageBox>
#include <QPainter>
#include <QPdfDocument>
#include <QProcess>
#include <QSet>
#include <QStringDecoder>
#include <QSvgRenderer>
#include <QTemporaryDir>
#include <QTextDocument>
#include <QThread>

#include <cmath>

namespace chargeur {

namespace {

const QSet<QString> WORD_EXTS = {QStringLiteral(".docx"), QStringLiteral(".doc"), QStringLiteral(".rtf"),
                                 QStringLiteral(".odt")};
const QSet<QString> EXCEL_EXTS = {QStringLiteral(".xlsx"), QStringLiteral(".xls"), QStringLiteral(".ods"),
                                  QStringLiteral(".csv")};
const QSet<QString> PPT_EXTS = {QStringLiteral(".pptx"), QStringLiteral(".ppt"), QStringLiteral(".odp")};
const QSet<QString> PILLOW_EXTS = {QStringLiteral(".psd"),  QStringLiteral(".cr2"),  QStringLiteral(".nef"),
                                   QStringLiteral(".arw"),  QStringLiteral(".dng"),  QStringLiteral(".heic"),
                                   QStringLiteral(".heif"), QStringLiteral(".tif"),  QStringLiteral(".tiff"),
                                   QStringLiteral(".bmp"),  QStringLiteral(".gif"),  QStringLiteral(".webp"),
                                   QStringLiteral(".ico"),  QStringLiteral(".avif")};

bool estOffice(const QString &ext)
{
    return WORD_EXTS.contains(ext) || EXCEL_EXTS.contains(ext) || PPT_EXTS.contains(ext)
           || ext == QLatin1String(".epub");
}

QString extension(const QString &chemin)
{
    const QString s = QFileInfo(chemin).suffix().toLower();
    return s.isEmpty() ? QString() : QLatin1Char('.') + s;
}

// --- PDF -------------------------------------------------------------------
QList<QImage> chargerPdf(const QString &chemin, bool rogner)
{
    QPdfDocument d(nullptr);
    d.load(chemin);
    const int nb = qMax(1, d.pageCount());

    // Budget mémoire : sur un long document, on abaisse la résolution.
    int dpi = config::renderDpi();
    double total = 0.0;
    for (int i = 0; i < nb; ++i) {
        const QSizeF pts = d.pagePointSize(i);
        total += (pts.width() > 0 ? pts.width() : 595) * (pts.height() > 0 ? pts.height() : 842);
    }
    total *= (dpi / 72.0) * (dpi / 72.0);
    if (total > config::MAX_DOCUMENT_PIXELS)
        dpi = qMax(config::MIN_RENDER_DPI, int(dpi * std::sqrt(config::MAX_DOCUMENT_PIXELS / total)));

    QList<QImage> pages;
    for (int i = 0; i < nb; ++i) {
        const QSizeF pts = d.pagePointSize(i);
        const QSize taille = tailleRendu(pts.width(), pts.height(), dpi);
        const QImage rendu = d.render(i, taille);
        if (rendu.isNull())
            continue;
        QImage blanc(rendu.size(), QImage::Format_RGB32);
        blanc.fill(Qt::white);
        {
            QPainter p(&blanc);
            p.setRenderHint(QPainter::SmoothPixmapTransform, true);
            p.drawImage(0, 0, rendu);
        }
        pages.append(rogner ? rognerBordsBlancs(blanc) : blanc);
    }
    d.close();
    if (pages.isEmpty())
        throw ErreurChargement{QStringLiteral("Le PDF n'a pas pu être rendu.\n"
                                              "Essayez une résolution plus basse dans Options ▸ Qualité de rendu.")};
    return pages;
}

void attendreFichier(const QString &chemin, int delaiMs = 5000)
{
    QElapsedTimer t;
    t.start();
    while (t.elapsed() < delaiMs) {
        QFile f(chemin);
        if (f.exists() && f.open(QIODevice::ReadOnly) && f.read(4).size() == 4)
            return;
        QThread::msleep(150);
    }
    throw ErreurChargement{QStringLiteral("Le fichier PDF généré est inaccessible après %1 s : %2")
                               .arg(delaiMs / 1000)
                               .arg(QDir::toNativeSeparators(chemin))};
}

// --- HTML / TXT ------------------------------------------------------------
QString decoderTexte(const QByteArray &brut)
{
    // UTF-8 strict d'abord…
    {
        QStringDecoder dec(QStringDecoder::Utf8, QStringDecoder::Flag::Stateless);
        const QString t = dec.decode(brut);
        if (!dec.hasError())
            return t;
    }
    // … puis Windows-1252 (le Latin-1 de Windows, avec €, œ, guillemets…).
    static const char16_t cp1252[32] = {
        0x20AC, 0x0081, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, 0x02C6, 0x2030, 0x0160,
        0x2039, 0x0152, 0x008D, 0x017D, 0x008F, 0x0090, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022,
        0x2013, 0x2014, 0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0x009D, 0x017E, 0x0178};
    QString t;
    t.reserve(brut.size());
    for (char c : brut) {
        const uchar u = uchar(c);
        t.append(u >= 0x80 && u < 0xA0 ? QChar(cp1252[u - 0x80]) : QChar(u));
    }
    return t;
}

QList<QImage> chargerTexte(const QString &chemin, bool html)
{
    QFile f(chemin);
    if (!f.open(QIODevice::ReadOnly))
        throw ErreurChargement{QStringLiteral("Fichier illisible.")};
    const QString texte = decoderTexte(f.readAll());

    const double PAGE_W = 595.0, PAGE_H = 842.0;
    QTextDocument td;
    if (html)
        td.setHtml(texte);
    else
        td.setPlainText(texte);
    // Ne PAS appeler setTextWidth() après setPageSize() : la pagination
    // serait désactivée.
    td.setPageSize(QSizeF(PAGE_W, PAGE_H));
    const int nb = qMax(1, td.pageCount());

    int dpi = config::renderDpi();
    const double total = PAGE_W * PAGE_H * nb * (dpi / 72.0) * (dpi / 72.0);
    if (total > config::MAX_DOCUMENT_PIXELS)
        dpi = qMax(config::MIN_RENDER_DPI, int(dpi * std::sqrt(config::MAX_DOCUMENT_PIXELS / total)));

    QList<QImage> pages;
    for (int i = 0; i < nb; ++i) {
        const QSize taille = tailleRendu(PAGE_W, PAGE_H, dpi);
        QImage img(taille, QImage::Format_RGB32);
        img.fill(Qt::white);
        QPainter p(&img);
        p.setRenderHint(QPainter::Antialiasing, true);
        p.setRenderHint(QPainter::TextAntialiasing, true);
        // On dessine en points puis on agrandit : le texte reste net.
        p.scale(taille.width() / PAGE_W, taille.height() / PAGE_H);
        p.translate(0, -i * PAGE_H);
        td.drawContents(&p, QRectF(0, i * PAGE_H, PAGE_W, PAGE_H));
        p.end();
        pages.append(img);
    }
    return pages;
}

// --- SVG -------------------------------------------------------------------
QImage chargerSvg(const QString &chemin)
{
    QSvgRenderer r(chemin);
    if (!r.isValid())
        throw ErreurChargement{QStringLiteral("Fichier SVG illisible ou invalide.")};
    // Taille naturelle du dessin, ramenée dans une A4 sans déformation.
    const QSize nat = r.defaultSize();
    double w = nat.width() > 0 ? nat.width() : 595.0;
    double h = nat.height() > 0 ? nat.height() : 842.0;
    const double fit = qMin(595.0 / w, 842.0 / h);
    if (fit < 1.0) {
        w *= fit;
        h *= fit;
    }
    const QSize taille = tailleRendu(w, h, config::renderDpi());
    QImage img(taille, QImage::Format_RGB32);
    img.fill(Qt::white);
    QPainter p(&img);
    p.setRenderHint(QPainter::Antialiasing, true);
    r.render(&p, QRectF(0, 0, taille.width(), taille.height()));
    p.end();
    return img;
}

// --- Images ----------------------------------------------------------------
QImage lireParQt(const QString &chemin)
{
    QImageReader r(chemin);
    r.setDecideFormatFromContent(true);
    if (r.format() == "ico" || r.format() == "icns") {
        // Une icône porte plusieurs tailles : on garde la plus grande.
        QImage meilleure;
        const int n = qMax(1, r.imageCount());
        for (int i = 0; i < n; ++i) {
            if (i > 0 && !r.jumpToImage(i))
                break;
            const QImage img = r.read();
            if (!img.isNull() && qint64(img.width()) * img.height() > qint64(meilleure.width()) * meilleure.height())
                meilleure = img;
        }
        return meilleure;
    }
    return r.read();
}

QImage chargerImage(const QString &chemin)
{
    const QString ext = extension(chemin);
    QImage img;
    if (lecteurs::estExtensionRaw(ext))
        img = lecteurs::lireRaw(chemin);
    if (img.isNull())
        img = lireParQt(chemin);
    if (img.isNull())
        img = lecteurs::lirePsd(chemin);
    if (img.isNull())
        img = lecteurs::lireWic(chemin);
    if (img.isNull() && !lecteurs::estExtensionRaw(ext))
        img = lecteurs::lireRaw(chemin);
    if (img.isNull()) {
        if (lecteurs::estExtensionRaw(ext) && !lecteurs::rawDisponible())
            throw ErreurChargement{QStringLiteral("Ce fichier RAW n'a pas pu être lu : installez l'extension "
                                                  "« Images RAW » de Microsoft, ou imprimez-le vers "
                                                  "l'imprimante « Feuillet » depuis votre logiciel photo.")};
        throw ErreurChargement{QStringLiteral("Format d'image non reconnu.")};
    }
    return surBlanc(img);
}

// --- XCF -------------------------------------------------------------------
QByteArray xcfBrut(const QString &chemin)
{
    QFile f(chemin);
    if (!f.open(QIODevice::ReadOnly))
        return QByteArray();
    const QByteArray brut = f.readAll();
    return brut.startsWith("gimp xcf ") ? brut : QByteArray();
}

QByteArray xcfVignetteParasite(const QByteArray &raw)
{
    if (raw.size() < 26)
        return QByteArray();
    QByteArray verStr = raw.mid(9, 4);
    while (verStr.endsWith('\0'))
        verStr.chop(1);
    int ver = 0;
    if (verStr.startsWith('v'))
        ver = verStr.mid(1).toInt();
    qint64 pos = 14 + 12;
    if (ver >= 4)
        pos += 4;
    auto u32 = [&raw](qint64 p) -> quint32 {
        return (quint32(uchar(raw[int(p)])) << 24) | (quint32(uchar(raw[int(p + 1)])) << 16)
               | (quint32(uchar(raw[int(p + 2)])) << 8) | quint32(uchar(raw[int(p + 3)]));
    };
    while (pos + 8 <= raw.size()) {
        const quint32 type = u32(pos), lg = u32(pos + 4);
        pos += 8;
        if (type == 0)
            break;
        if (type == 21 && lg > 0) {
            const qint64 fin = pos + lg;
            qint64 p = pos;
            while (p < fin) {
                if (p + 4 > fin)
                    break;
                const quint32 lgNom = u32(p);
                p += 4;
                if (lgNom == 0 || p + lgNom > fin)
                    break;
                const QByteArray nom = raw.mid(int(p), int(lgNom) - 1).toLower();
                p += lgNom;
                if (p + 8 > fin)
                    break;
                const quint32 lgDonnees = u32(p + 4);
                p += 8;
                if (p + lgDonnees > fin)
                    break;
                const QByteArray donnees = raw.mid(int(p), int(lgDonnees));
                p += lgDonnees;
                if (nom.contains("thumbnail") || nom.contains("preview"))
                    if (donnees.startsWith("\xff\xd8") || donnees.startsWith("\x89PNG\r\n\x1a\n"))
                        return donnees;
            }
        }
        pos += lg;
    }
    return QByteArray();
}

QByteArray xcfViaXcf2png(const QString &chemin)
{
    QProcess p;
    p.start(QStringLiteral("xcf2png"), {chemin, QStringLiteral("-o"), QStringLiteral("-")});
    if (!p.waitForStarted(3000) || !p.waitForFinished(8000)) {
        p.kill();
        return QByteArray();
    }
    if (p.exitCode() == 0)
        return p.readAllStandardOutput();
    return QByteArray();
}

QByteArray xcfJpegInterne(const QByteArray &raw)
{
    qint64 pos = 0;
    for (;;) {
        const qint64 idx = raw.indexOf("\xff\xd8\xff", pos);
        if (idx < 0)
            break;
        qint64 fin = raw.indexOf("\xff\xd9", idx + 3);
        if (fin < 0)
            break;
        fin += 2;
        if (fin - idx > 500)
            return raw.mid(int(idx), int(fin - idx));
        pos = idx + 1;
    }
    return QByteArray();
}

QImage xcfPar(const QString &cle, const QString &exe, const QString &chemin)
{
    QString png;
    try {
        png = cle == QLatin1String("imagemagick") ? cv::xcfViaImagemagick(exe, chemin) : cv::xcfViaGimp(exe, chemin);
    } catch (...) {
        return QImage();
    }
    QImage img(png);
    QFile::remove(png);
    return img;
}

QImage xcfViaConvertisseur(const QString &chemin, QWidget *parent)
{
    const QStringList cles = cv::convertisseursPour(QStringLiteral(".xcf"));
    for (const QString &cle : cles) {
        const QString exe = cv::trouver(cle);
        if (exe.isEmpty())
            continue;
        const QImage img = xcfPar(cle, exe, chemin);
        if (!img.isNull())
            return img;
    }
    // Aucun n'est installé : on demande, pour le premier non refusé.
    for (const QString &cle : cles) {
        if (cv::refuse(cle))
            continue;
        const QString exe = cv::demander(cle, QStringLiteral(".xcf"), parent);
        if (exe.isEmpty())
            return QImage();
        return xcfPar(cle, exe, chemin);
    }
    return QImage();
}

QImage chargerXcf(const QString &chemin, QWidget *parent)
{
    const QImage pleine = xcfViaConvertisseur(chemin, parent);
    if (!pleine.isNull())
        return surBlanc(pleine);

    const QByteArray raw = xcfBrut(chemin);
    QImage vignette;
    if (!raw.isEmpty()) {
        for (const QByteArray &donnees : {xcfVignetteParasite(raw), xcfViaXcf2png(chemin), xcfJpegInterne(raw)}) {
            if (donnees.isEmpty())
                continue;
            const QImage img = QImage::fromData(donnees);
            if (!img.isNull()) {
                vignette = img;
                break;
            }
        }
    }
    if (!vignette.isNull()) {
        const int l = vignette.width(), h = vignette.height();
        cv::auPremierPlan([&]() -> QVariant {
            QMessageBox::warning(parent, QStringLiteral("Qualité réduite"),
                                 QStringLiteral("Ce fichier XCF n'a pu être lu qu'à travers l'aperçu de "
                                                "faible résolution que GIMP y range (%1 × %2 pixels) : il sortira "
                                                "flou à l'impression.\n\n"
                                                "Pour l'obtenir à sa vraie taille, ouvrez-le dans GIMP et "
                                                "exportez-le en PNG — ou imprimez-le vers l'imprimante « Feuillet ».")
                                     .arg(l)
                                     .arg(h));
            return QVariant();
        });
        return surBlanc(vignette);
    }

    const auto [cle, exe] = cv::designerALaMain(QStringLiteral(".xcf"), parent);
    if (!exe.isEmpty()) {
        const QImage img = xcfPar(cle, exe, chemin);
        if (!img.isNull())
            return surBlanc(img);
    }
    throw ErreurChargement{QStringLiteral("Impossible de lire ce fichier XCF.\n\n"
                                          "Ouvrez-le dans GIMP et imprimez-le vers l'imprimante « Feuillet ».")};
}

// --- Documents bureautiques -------------------------------------------------
QString voisin(const QString &wordExe, const QString &nom)
{
    QDir dossier = QFileInfo(wordExe).absoluteDir();
    const auto fichiers = dossier.entryInfoList(QDir::Files);
    for (const QFileInfo &f : fichiers)
        if (f.fileName().compare(nom, Qt::CaseInsensitive) == 0)
            return f.absoluteFilePath();
    return QString();
}

QList<QImage> viaLibreOffice(const QString &chemin, QString soffice)
{
    if (soffice.isEmpty())
        soffice = cv::trouver(QStringLiteral("libreoffice"));
    if (soffice.isEmpty())
        throw ErreurChargement{QStringLiteral("LibreOffice est introuvable sur cet ordinateur.\n\n"
                                              "Ouvrez le document dans son logiciel habituel et "
                                              "imprimez-le vers l'imprimante « Feuillet ».")};
    QTemporaryDir tmp(QDir::temp().filePath(QStringLiteral("feuillet_lo_XXXXXX")));
    if (!tmp.isValid())
        throw ErreurChargement{QStringLiteral("Dossier temporaire impossible à créer.")};
    const QString pdf = cv::convertirEnPdf(soffice, chemin, tmp.path());
    attendreFichier(pdf);
    return chargerPdf(pdf, false);
}

QList<QImage> viaOfficeCom(const QString &chemin, int sorte)
{
    QTemporaryDir tmp(QDir::temp().filePath(QStringLiteral("feuillet_XXXXXX")));
    if (!tmp.isValid())
        throw ErreurChargement{QStringLiteral("Dossier temporaire impossible à créer.")};
    const QString pdf = QDir(tmp.path()).filePath(QFileInfo(chemin).completeBaseName() + QStringLiteral(".pdf"));
    if (sorte == 0)
        office::wordVersPdf(chemin, pdf);
    else if (sorte == 1)
        office::excelVersPdf(chemin, pdf);
    else
        office::powerpointVersPdf(chemin, pdf);
    attendreFichier(pdf);
    return chargerPdf(pdf, false);
}

QList<QImage> convertirOffice(const QString &chemin, const QString &ext, const QString &cle, const QString &exe)
{
    if (cle == QLatin1String("word")) {
        if (WORD_EXTS.contains(ext))
            return viaOfficeCom(chemin, 0);
        if (EXCEL_EXTS.contains(ext)) {
            if (voisin(exe, QStringLiteral("EXCEL.EXE")).isEmpty())
                throw ErreurChargement{QStringLiteral("Excel introuvable à côté de Word.")};
            return viaOfficeCom(chemin, 1);
        }
        if (voisin(exe, QStringLiteral("POWERPNT.EXE")).isEmpty())
            throw ErreurChargement{QStringLiteral("PowerPoint introuvable à côté de Word.")};
        return viaOfficeCom(chemin, 2);
    }
    return viaLibreOffice(chemin, exe);
}

QList<QImage> chargerOffice(const QString &chemin, const QString &ext, QWidget *parent)
{
    const QStringList cles = cv::convertisseursPour(ext);
    for (const QString &cle : cles) {
        const QString exe = cv::trouver(cle);
        if (exe.isEmpty())
            continue;
        try {
            return convertirOffice(chemin, ext, cle, exe);
        } catch (...) {
            continue; // ce convertisseur a échoué : au suivant
        }
    }
    for (const QString &cle : cles) {
        if (cv::refuse(cle))
            continue;
        const QString exe = cv::demander(cle, ext, parent);
        if (!exe.isEmpty())
            return convertirOffice(chemin, ext, cle, exe);
        break; // refus franc : inutile de proposer l'autre
    }
    const auto [cle, exe] = cv::designerALaMain(ext, parent);
    if (!exe.isEmpty())
        return convertirOffice(chemin, ext, cle, exe);
    throw ErreurChargement{QStringLiteral("Ce document n'a pas pu être ouvert.\n\n"
                                          "Ouvrez-le dans son logiciel habituel et imprimez-le vers "
                                          "l'imprimante « Feuillet ».")};
}

// Sans ce garde-fou, LibreOffice rend fidèlement des pages de charabia pour
// n'importe quel binaire.
bool ressembleAUnDocument(const QString &chemin)
{
    QFile f(chemin);
    if (!f.open(QIODevice::ReadOnly))
        return false;
    const QByteArray tete = f.read(4096);
    if (tete.isEmpty())
        return false;
    if (tete.startsWith("PK\x03\x04"))
        return true; // odt, docx, xlsx…
    if (tete.startsWith(QByteArray("\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", 8)))
        return true; // doc, xls, ppt
    if (tete.contains('\0'))
        return false;
    int lisibles = 0;
    for (char c : tete) {
        const uchar u = uchar(c);
        if (u >= 32 || u == 9 || u == 10 || u == 13)
            ++lisibles;
    }
    return double(lisibles) / tete.size() > 0.95;
}

QList<QImage> chargerInconnu(const QString &chemin, std::atomic<bool> *formatInconnu)
{
    try {
        return {chargerImage(chemin)};
    } catch (...) {
    }
    const QString soffice = cv::trouver(QStringLiteral("libreoffice"));
    if (!soffice.isEmpty() && ressembleAUnDocument(chemin)) {
        try {
            return viaLibreOffice(chemin, soffice);
        } catch (...) {
        }
    }
    if (formatInconnu)
        *formatInconnu = true;
    throw ErreurChargement{DEJA_DIT};
}

} // namespace

// ===========================================================================
QSize tailleRendu(double wPt, double hPt, int dpi)
{
    const double facteur = dpi / 72.0;
    int w = qMax(1, int(std::round((wPt > 0 ? wPt : 595) * facteur)));
    int h = qMax(1, int(std::round((hPt > 0 ? hPt : 842) * facteur)));
    if (qint64(w) * h > config::MAX_RENDER_PIXELS) {
        const double reduc = std::sqrt(double(config::MAX_RENDER_PIXELS) / (double(w) * h));
        w = qMax(1, int(w * reduc));
        h = qMax(1, int(h * reduc));
    }
    return QSize(w, h);
}

QImage surBlanc(const QImage &img)
{
    if (img.isNull())
        return img;
    QImage r(img.size(), QImage::Format_RGB32);
    r.fill(Qt::white);
    QPainter p(&r);
    p.drawImage(0, 0, img);
    p.end();
    return r;
}

bool vientDuDriver(const QString &chemin)
{
    const QString dossier = QFileInfo(chemin).absoluteDir().canonicalPath();
    const QString impressions = QDir(driver::dossierImpressions()).canonicalPath();
    return !impressions.isEmpty() && dossier.compare(impressions, Qt::CaseInsensitive) == 0;
}

QImage rognerBordsBlancs(const QImage &img)
{
    const int W = img.width(), H = img.height();
    if (W < 8 || H < 8)
        return img;
    // L'analyse se fait sur une copie réduite : aussi fiable, quasi instantané.
    const QImage petit = img.scaled(600, 600, Qt::KeepAspectRatio, Qt::FastTransformation)
                             .convertToFormat(QImage::Format_RGB888);
    const int w = petit.width(), h = petit.height();
    int x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (int y = 0; y < h; ++y) {
        const uchar *l = petit.constScanLine(y);
        for (int x = 0; x < w; ++x) {
            const uchar *px = l + x * 3;
            if (px[0] < 247 || px[1] < 247 || px[2] < 247) {
                x0 = qMin(x0, x);
                y0 = qMin(y0, y);
                x1 = qMax(x1, x);
                y1 = qMax(y1, y);
            }
        }
    }
    if (x1 < 0)
        return img; // page vierge : intacte
    const double fx = double(W) / w, fy = double(H) / h;
    const int marge = int(qMax(fx, fy)) + 2;
    const int ax0 = qMax(0, int(x0 * fx) - marge);
    const int ay0 = qMax(0, int(y0 * fy) - marge);
    const int ax1 = qMin(W, int((x1 + 1) * fx) + marge);
    const int ay1 = qMin(H, int((y1 + 1) * fy) + marge);
    if ((ax1 - ax0) >= W * 0.97 && (ay1 - ay0) >= H * 0.97)
        return img; // rien à gagner
    return img.copy(ax0, ay0, ax1 - ax0, ay1 - ay0);
}

QList<QImage> charger(const QString &chemin, QWidget *parent, std::atomic<bool> *formatInconnu)
{
    const QString ext = extension(chemin);
    if (ext == QLatin1String(".pdf"))
        return chargerPdf(chemin, vientDuDriver(chemin) && config::driverRognerBlanc());
    if (ext == QLatin1String(".html") || ext == QLatin1String(".htm"))
        return chargerTexte(chemin, true);
    if (ext == QLatin1String(".txt"))
        return chargerTexte(chemin, false);
    if (ext == QLatin1String(".svg"))
        return {chargerSvg(chemin)};
    if (estOffice(ext))
        return chargerOffice(chemin, ext, parent);
    if (ext == QLatin1String(".xcf"))
        return {chargerXcf(chemin, parent)};
    if (PILLOW_EXTS.contains(ext) || lecteurs::estExtensionRaw(ext))
        return {chargerImage(chemin)};
    const QImage img = lireParQt(chemin);
    if (!img.isNull())
        return {surBlanc(img)};
    return chargerInconnu(chemin, formatInconnu);
}

} // namespace chargeur
