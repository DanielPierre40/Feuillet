#include "origines.h"

#include <QFileInfo>
#include <QHash>
#include <QList>
#include <QSet>

namespace {

constexpr int MAX_ENTREES = 2000;

QHash<qint64, Origine> &registre()
{
    static QHash<qint64, Origine> r;
    return r;
}

QList<qint64> &ordre()
{
    static QList<qint64> o;
    return o;
}

} // namespace

QJsonObject Origine::versJson() const
{
    QJsonObject o;
    o.insert(QStringLiteral("chemin"), chemin);
    o.insert(QStringLiteral("page"), page);
    o.insert(QStringLiteral("pages"), pages);
    o.insert(QStringLiteral("est_image"), estImage);
    return o;
}

Origine Origine::depuisJson(const QJsonObject &o)
{
    Origine r;
    r.chemin = o.value(QStringLiteral("chemin")).toString();
    r.page = o.value(QStringLiteral("page")).toInt(1);
    r.pages = o.value(QStringLiteral("pages")).toInt(1);
    r.estImage = o.value(QStringLiteral("est_image")).toBool(origines::estImage(r.chemin));
    return r;
}

namespace origines {

bool estImage(const QString &chemin)
{
    static const QSet<QString> ext = {
        QStringLiteral("png"), QStringLiteral("jpg"), QStringLiteral("jpeg"),
        QStringLiteral("jpe"), QStringLiteral("jfif"), QStringLiteral("gif"),
        QStringLiteral("bmp"), QStringLiteral("tif"), QStringLiteral("tiff"),
        QStringLiteral("webp"), QStringLiteral("ico"), QStringLiteral("tga"),
        QStringLiteral("ppm"), QStringLiteral("pgm"), QStringLiteral("pbm"),
        QStringLiteral("xbm"), QStringLiteral("xpm"), QStringLiteral("svg"),
        QStringLiteral("xcf"), QStringLiteral("psd"), QStringLiteral("cr2"),
        QStringLiteral("nef"), QStringLiteral("arw"), QStringLiteral("dng"),
        QStringLiteral("heic"), QStringLiteral("heif"), QStringLiteral("avif"),
        QStringLiteral("raf"), QStringLiteral("orf"), QStringLiteral("rw2"),
        QStringLiteral("pef"), QStringLiteral("sr2"),
    };
    if (chemin.isEmpty())
        return false;
    return ext.contains(QFileInfo(chemin).suffix().toLower());
}

void noter(const QPixmap &pixmap, const QString &chemin, int page, int pages)
{
    if (pixmap.isNull() || chemin.isEmpty())
        return;
    const qint64 cle = pixmap.cacheKey();
    Origine o;
    o.chemin = chemin;
    o.page = page;
    o.pages = pages;
    o.estImage = estImage(chemin);
    if (!registre().contains(cle))
        ordre().append(cle);
    registre().insert(cle, o);
    while (ordre().size() > MAX_ENTREES)
        registre().remove(ordre().takeFirst());
}

Origine lire(const QPixmap &pixmap)
{
    if (pixmap.isNull())
        return Origine();
    return registre().value(pixmap.cacheKey());
}

} // namespace origines
