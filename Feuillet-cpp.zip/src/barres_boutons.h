// barres_boutons — barres d'outils dont les boutons se déplacent au
// glisser-déposer, d'une barre à l'autre, avec curseur et trait orange.
// Séparateurs transparents de largeur libre, renommage et apparence des
// boutons au clic droit ; tout est retenu dans la configuration.
#pragma once

#include <QDialog>
#include <QJsonObject>
#include <QMap>
#include <QPlainTextEdit>
#include <QPointer>
#include <QWidget>
#include <functional>
#include <optional>

class QCheckBox;
class QFontComboBox;
class QHBoxLayout;
class QMenu;
class QPushButton;
class QSpinBox;
class GroupeBarres;

inline const QString ORANGE = QStringLiteral("#e8770a");

QPixmap curseurOrange();
QPixmap vignette(QWidget *widget);
// Attache un menu SANS setMenu(), pour que le bouton reste déplaçable.
QMenu *ouvrirMenuAuClic(QPushButton *bouton, QMenu *menu);
QString feuilleApparence(const QJsonObject &apparence);

class ChampLibelle : public QPlainTextEdit {
    Q_OBJECT
public:
    explicit ChampLibelle(const QString &texte, QWidget *parent = nullptr);

protected:
    void keyPressEvent(QKeyEvent *ev) override;
};

class BoiteRenommage : public QDialog {
    Q_OBJECT
public:
    explicit BoiteRenommage(const QString &texte, QWidget *parent = nullptr);
    QString libelle() const;

private:
    ChampLibelle *m_champ;
};

class BoiteApparence : public QDialog {
    Q_OBJECT
public:
    BoiteApparence(const QString &texteBouton, const QJsonObject &apparence, QWidget *parent = nullptr);
    // L'apparence choisie, ou un objet vide pour « réglages d'origine ».
    QJsonObject resultat() const;
    bool retourOrigine() const { return m_retourOrigine; }

private:
    QJsonObject apparenceCourante() const;
    void rafraichir();
    void choisirCouleur();
    void choisirFond();

    bool m_retourOrigine = false;
    QFontComboBox *m_police;
    QCheckBox *m_gras;
    QCheckBox *m_italique;
    QSpinBox *m_taille;
    QString m_couleur;
    QPushButton *m_btnCouleur;
    QString m_fond;
    QPushButton *m_btnFond;
    QCheckBox *m_caseFond;
    QPushButton *m_apercu;
};

class Separateur : public QWidget {
    Q_OBJECT
public:
    explicit Separateur(int largeur = 40, QWidget *parent = nullptr);
    void reglerLargeur(int largeur);
    int largeur() const { return m_largeur; }

protected:
    void mousePressEvent(QMouseEvent *ev) override;

private:
    int m_largeur = 40;
};

class BarreBoutons : public QWidget {
    Q_OBJECT
public:
    BarreBoutons(const QString &nom, GroupeBarres *groupe, QWidget *parent = nullptr);

    QString nom() const { return m_nom; }
    QHBoxLayout *layoutH() const { return m_layout; }

    void collerAuPrecedent(const QList<QWidget *> &compagnons);
    void recoller();
    void ajusterHauteur();
    void inserer(QWidget *objet, int index);
    void menuContextuel(const QPoint &pos, const QPoint &posGlobale);

protected:
    void dragEnterEvent(QDragEnterEvent *ev) override;
    void dragMoveEvent(QDragMoveEvent *ev) override;
    void dragLeaveEvent(QDragLeaveEvent *ev) override;
    void dropEvent(QDropEvent *ev) override;
    void contextMenuEvent(QContextMenuEvent *ev) override;
    void showEvent(QShowEvent *ev) override;
    void paintEvent(QPaintEvent *ev) override;

private:
    QList<QPair<int, QWidget *>> occupants() const;
    QPair<int, int> viser(int x) const;
    void nouveauSeparateur(int rang);
    void demanderLargeur(Separateur *sep);
    std::optional<int> saisirLargeur(int valeur);

    QString m_nom;
    GroupeBarres *m_groupe;
    QHBoxLayout *m_layout;
    std::optional<int> m_trait;
    QList<QPointer<QWidget>> m_colles;
};

class GroupeBarres : public QObject {
    Q_OBJECT
public:
    using Rappel = std::function<void(const QJsonObject &)>;
    explicit GroupeBarres(QObject *parent = nullptr, Rappel auChangement = nullptr);

    void ajouterBarre(BarreBoutons *barre) { m_barres.append(barre); }
    QList<BarreBoutons *> barres() const { return m_barres; }
    void ajusterBarres();
    QWidget *rendreDeplacable(QWidget *objet, const QString &nom);

    void declarerEtats(QPushButton *bouton, const QMap<QString, QString> &libelles, const QString &etat);
    void changerEtat(QPushButton *bouton, const QString &etat);

    void appliquerApparence(QWidget *objet);
    void modifierApparence(QPushButton *bouton, QWidget *parent);
    void renommer(QPushButton *bouton, QWidget *parent);

    QWidget *objet(const QString &nom) const { return m_objets.value(nom); }
    bool connait(const QString &nom) const { return m_objets.contains(nom); }

    Separateur *creerSeparateur(int largeur);
    void supprimerSeparateur(Separateur *sep);

    QJsonObject agencement() const;
    bool appliquer(const QJsonObject &agencement);
    void enregistrer();
    void figerDispositionUsine();
    void remettreAZero();

private:
    friend class Glisseur;
    QString cle(const QString &nom) const;
    void appliquerLibelle(const QString &nom);
    QString nomLibre() const;
    void viderSeparateurs();

    QList<BarreBoutons *> m_barres;
    QMap<QString, QWidget *> m_objets;
    QMap<QString, QJsonObject> m_apparences;
    QMap<QString, QString> m_libelles;
    QMap<QString, QString> m_libellesUsine;
    QMap<QString, QString> m_etats;
    QObject *m_glisseur;
    QJsonObject m_usine;
    bool m_usineFigee = false;
    Rappel m_auChangement;
};
