#include "driver_feuillet.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QPrinterInfo>
#include <QProcess>
#include <QSaveFile>
#include <QSettings>
#include <QStandardPaths>
#include <QTextStream>
#include <QThread>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <shellapi.h>
#endif

namespace driver {

namespace {

const QString NOM_IMPRIMANTE = QStringLiteral("Feuillet");
const QString NOM_PILOTE_PDF = QStringLiteral("Microsoft Print to PDF");
const QString NOM_FONCTION_PDF = QStringLiteral("Printing-PrintToPDFServices-Features");
const wchar_t *NOM_MUTEX = L"Local\\FeuilletImprimanteGuetteur";
const QString CLE_RUN = QStringLiteral("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run");
const QString VALEUR_RUN = QStringLiteral("FeuilletImprimante");
constexpr int JOURS_CONSERVATION = 30;
constexpr int INTERVALLE_MS = 700;

QString exe()
{
    return QDir::toNativeSeparators(QCoreApplication::applicationFilePath());
}

QString psQuote(const QString &texte)
{
    QString t = texte;
    return QLatin1Char('\'') + t.replace(QLatin1Char('\''), QStringLiteral("''")) + QLatin1Char('\'');
}

struct Sortie {
    int code;
    QString texte;
};

Sortie powershell(const QString &commande)
{
    QProcess p;
#ifdef Q_OS_WIN
    p.setCreateProcessArgumentsModifier([](QProcess::CreateProcessArguments *a) {
        a->flags |= CREATE_NO_WINDOW;
    });
#endif
    p.start(QStringLiteral("powershell"),
            {QStringLiteral("-NoProfile"), QStringLiteral("-NonInteractive"), QStringLiteral("-Command"), commande});
    if (!p.waitForStarted(15000))
        return {1, QStringLiteral("PowerShell n'a pas pu démarrer")};
    if (!p.waitForFinished(240000)) {
        p.kill();
        return {1, QStringLiteral("délai dépassé")};
    }
    const QString texte = QString::fromLocal8Bit(p.readAllStandardOutput())
                          + QString::fromLocal8Bit(p.readAllStandardError());
    return {p.exitStatus() == QProcess::NormalExit ? p.exitCode() : 1, texte};
}

#ifdef Q_OS_WIN
// ShellExecuteEx « runas » sur Feuillet.exe. Codes : celui du processus,
// -1 (UAC refusé / lancement impossible), -2 (délai dépassé).
int executerEleve(const QStringList &arguments, int attenteS = 300)
{
    QStringList cites;
    for (const QString &a : arguments)
        cites << QLatin1Char('"') + a + QLatin1Char('"');
    const std::wstring params = cites.join(QLatin1Char(' ')).toStdWString();
    const std::wstring fichier = exe().toStdWString();
    const std::wstring dossier = QDir::toNativeSeparators(QCoreApplication::applicationDirPath()).toStdWString();

    SHELLEXECUTEINFOW sei{};
    sei.cbSize = sizeof(sei);
    sei.fMask = SEE_MASK_NOCLOSEPROCESS;
    sei.lpVerb = L"runas";
    sei.lpFile = fichier.c_str();
    sei.lpParameters = params.c_str();
    sei.lpDirectory = dossier.c_str();
    sei.nShow = SW_HIDE;
    if (!ShellExecuteExW(&sei)) {
        journal(QStringLiteral("Élévation refusée ou impossible (erreur %1)").arg(GetLastError()));
        return -1;
    }
    if (!sei.hProcess)
        return -1;
    if (WaitForSingleObject(sei.hProcess, DWORD(attenteS) * 1000) != WAIT_OBJECT_0) {
        CloseHandle(sei.hProcess);
        return -2;
    }
    DWORD code = 0;
    GetExitCodeProcess(sei.hProcess, &code);
    CloseHandle(sei.hProcess);
    return int(code);
}
#endif

bool piloteDisponible()
{
    return powershell(QStringLiteral("Get-PrinterDriver -Name %1 -ErrorAction Stop | Out-Null")
                          .arg(psQuote(NOM_PILOTE_PDF)))
               .code
           == 0;
}

void nettoyerVieillesImpressions()
{
    const QDateTime seuil = QDateTime::currentDateTime().addDays(-JOURS_CONSERVATION);
    QDir d(dossierImpressions());
    const auto fichiers = d.entryInfoList({QStringLiteral("impression_*.pdf")}, QDir::Files);
    for (const QFileInfo &f : fichiers)
        if (f.lastModified() < seuil)
            QFile::remove(f.absoluteFilePath());
}

QString nomUnique()
{
    const QString base = QDateTime::currentDateTime().toString(QStringLiteral("'impression_'yyyyMMdd_HHmmss"));
    QDir d(dossierImpressions());
    QString dest = d.filePath(base + QStringLiteral(".pdf"));
    int n = 1;
    while (QFileInfo::exists(dest)) {
        ++n;
        dest = d.filePath(QStringLiteral("%1_%2.pdf").arg(base).arg(n));
    }
    return dest;
}

} // namespace

// ---------------------------------------------------------------------------
QString dossierDonnees()
{
    QString base = qEnvironmentVariable("LOCALAPPDATA");
    if (base.isEmpty())
        base = QDir::homePath();
    return QDir(base).filePath(QStringLiteral("Feuillet"));
}
QString dossierSpool() { return QDir(dossierDonnees()).filePath(QStringLiteral("spool")); }
QString fichierSpool() { return QDir(dossierSpool()).filePath(QStringLiteral("feuillet_spool.pdf")); }
QString dossierImpressions() { return QDir(dossierDonnees()).filePath(QStringLiteral("impressions")); }
QString fichierConfig() { return QDir(dossierDonnees()).filePath(QStringLiteral("imprimante.json")); }
QString drapeauStop() { return QDir(dossierDonnees()).filePath(QStringLiteral("guetteur_stop")); }
QString fichierLog() { return QDir(dossierDonnees()).filePath(QStringLiteral("imprimante.log")); }

void journal(const QString &msg)
{
    QDir().mkpath(dossierDonnees());
    QFile f(fichierLog());
    if (!f.open(QIODevice::Append | QIODevice::Text))
        return;
    QTextStream ts(&f);
    ts.setEncoding(QStringConverter::Utf8);
    ts << QDateTime::currentDateTime().toString(QStringLiteral("[dd/MM/yyyy HH:mm:ss] ")) << msg << '\n';
}

bool imprimanteInstallee()
{
#ifdef Q_OS_WIN
    return QPrinterInfo::availablePrinterNames().contains(NOM_IMPRIMANTE);
#else
    return false;
#endif
}

bool guetteurActif()
{
#ifdef Q_OS_WIN
    HANDLE h = CreateMutexW(nullptr, FALSE, NOM_MUTEX);
    const bool deja = GetLastError() == ERROR_ALREADY_EXISTS;
    if (h)
        CloseHandle(h);
    return deja;
#else
    return false;
#endif
}

Resultat installer()
{
#ifndef Q_OS_WIN
    return {false, QStringLiteral("L'imprimante virtuelle n'est disponible que sous Windows.")};
#else
    // 1) Dossiers + configuration (relue à chaque impression par le guetteur).
    QDir().mkpath(dossierSpool());
    QDir().mkpath(dossierImpressions());
    QJsonObject cfg;
    cfg.insert(QStringLiteral("feuillet"), exe());
    cfg.insert(QStringLiteral("spool"), QDir::toNativeSeparators(fichierSpool()));
    cfg.insert(QStringLiteral("impressions"), QDir::toNativeSeparators(dossierImpressions()));
    {
        QSaveFile f(fichierConfig());
        if (f.open(QIODevice::WriteOnly)) {
            f.write(QJsonDocument(cfg).toJson(QJsonDocument::Indented));
            f.commit();
        }
    }

    // 2) Guetteur au démarrage de session (clé Run, sans élévation).
    {
        QSettings run(CLE_RUN, QSettings::NativeFormat);
        run.setValue(VALEUR_RUN, QStringLiteral("\"%1\" --guetteur").arg(exe()));
        run.sync();
        if (run.status() != QSettings::NoError)
            return {false, QStringLiteral("Impossible d'inscrire le guetteur au démarrage.")};
    }

    // 3) Partie élevée : pilote PDF, port fichier, imprimante.
    journal(QStringLiteral("Installation demandée — lancement de la partie élevée"));
    const int rc = executerEleve({QStringLiteral("--admin-installer"), QDir::toNativeSeparators(fichierSpool())});
    if (rc == -1)
        return {false, QStringLiteral("L'élévation a été refusée (fenêtre UAC annulée).\n"
                                      "L'imprimante n'a pas été créée.")};
    if (rc == -2)
        return {false, QStringLiteral("L'installation a dépassé le délai d'attente.")};
    if (rc == 2)
        return {false, QStringLiteral("Le pilote « Microsoft Print to PDF » est introuvable et n'a "
                                      "pas pu être activé.\nActivez-le dans : Panneau de "
                                      "configuration ▸ Programmes ▸ Activer ou désactiver des "
                                      "fonctionnalités Windows ▸ Imprimer au format PDF Microsoft, "
                                      "puis recommencez.")};
    if (rc == 3)
        return {false, QStringLiteral("La création du port d'impression a échoué.\n"
                                      "Consultez le journal : ")
                           + QDir::toNativeSeparators(fichierLog())};
    if (rc == 4)
        return {false, QStringLiteral("La création de l'imprimante « Feuillet » a échoué.\n"
                                      "Consultez le journal : ")
                           + QDir::toNativeSeparators(fichierLog())};
    if (rc != 0)
        return {false, QStringLiteral("Échec de l'installation (code %1).\nJournal : %2")
                           .arg(rc)
                           .arg(QDir::toNativeSeparators(fichierLog()))};

    // 4) Démarrage immédiat du guetteur.
    if (!guetteurActif()) {
        if (!QProcess::startDetached(exe(), {QStringLiteral("--guetteur")}, QCoreApplication::applicationDirPath()))
            return {true, QStringLiteral("Imprimante « Feuillet » installée, mais le guetteur n'a "
                                         "pas pu démarrer tout de suite.\n"
                                         "Il démarrera à la prochaine ouverture de session.")};
    }
    journal(QStringLiteral("Installation terminée avec succès"));
    return {true, QStringLiteral("L'imprimante « Feuillet » est installée.\n\n"
                                 "Dans n'importe quel logiciel : Fichier ▸ Imprimer ▸ Feuillet — "
                                 "la fenêtre de mise en page s'ouvrira, le contenu du document "
                                 "posé en éléments sur la page.")};
#endif
}

Resultat desinstaller()
{
#ifndef Q_OS_WIN
    return {false, QStringLiteral("L'imprimante virtuelle n'est disponible que sous Windows.")};
#else
    // 1) Arrêt du guetteur par drapeau (aucun taskkill).
    QDir().mkpath(dossierDonnees());
    {
        QFile f(drapeauStop());
        if (f.open(QIODevice::WriteOnly))
            f.write("stop");
    }
    QElapsedTimer t;
    t.start();
    while (guetteurActif() && t.elapsed() < 5000)
        QThread::msleep(200);
    QFile::remove(drapeauStop());

    // 2) Clé Run.
    {
        QSettings run(CLE_RUN, QSettings::NativeFormat);
        run.remove(VALEUR_RUN);
    }

    // 3) Partie élevée : imprimante + port.
    journal(QStringLiteral("Désinstallation demandée — lancement de la partie élevée"));
    const int rc = executerEleve({QStringLiteral("--admin-desinstaller"), QDir::toNativeSeparators(fichierSpool())});
    if (rc == -1)
        return {false, QStringLiteral("L'élévation a été refusée (fenêtre UAC annulée).\n"
                                      "L'imprimante n'a pas été retirée — le guetteur, lui, "
                                      "est bien arrêté.")};
    if (rc != 0)
        return {false, QStringLiteral("La désinstallation a rencontré un problème (code %1).\nJournal : %2")
                           .arg(rc)
                           .arg(QDir::toNativeSeparators(fichierLog()))};
    journal(QStringLiteral("Désinstallation terminée"));
    return {true, QStringLiteral("L'imprimante « Feuillet » a été désinstallée.")};
#endif
}

// ---------------------------------------------------------------------------
// Partie ÉLEVÉE (exécutée en administrateur, sans fenêtre)
// ---------------------------------------------------------------------------
int adminInstaller(const QString &spool)
{
    if (!piloteDisponible()) {
        journal(QStringLiteral("Pilote PDF absent — tentative d'activation de la fonctionnalité Windows"));
        powershell(QStringLiteral("Enable-WindowsOptionalFeature -Online -FeatureName %1 -All -NoRestart | Out-Null")
                       .arg(psQuote(NOM_FONCTION_PDF)));
        QThread::sleep(2);
        if (!piloteDisponible()) {
            journal(QStringLiteral("Pilote PDF toujours absent après activation"));
            return 2;
        }
    }
    // Repartir proprement si une installation précédente traîne.
    powershell(QStringLiteral("Remove-Printer -Name %1 -ErrorAction SilentlyContinue").arg(psQuote(NOM_IMPRIMANTE)));
    QThread::sleep(1);

    // Port fichier : un port local dont le nom EST le chemin du fichier.
    const QString testPort = QStringLiteral("Get-PrinterPort -Name %1 -ErrorAction Stop | Out-Null").arg(psQuote(spool));
    if (powershell(testPort).code != 0) {
        const Sortie s = powershell(QStringLiteral("Add-PrinterPort -Name %1").arg(psQuote(spool)));
        if (s.code != 0 && powershell(testPort).code != 0) {
            journal(QStringLiteral("Échec Add-PrinterPort : ") + s.texte.trimmed());
            return 3;
        }
    }
    const Sortie s = powershell(QStringLiteral("Add-Printer -Name %1 -DriverName %2 -PortName %3")
                                    .arg(psQuote(NOM_IMPRIMANTE), psQuote(NOM_PILOTE_PDF), psQuote(spool)));
    if (s.code != 0) {
        journal(QStringLiteral("Échec Add-Printer : ") + s.texte.trimmed());
        return 4;
    }
    journal(QStringLiteral("Partie élevée : imprimante et port créés"));
    return 0;
}

int adminDesinstaller(const QString &spool)
{
    powershell(QStringLiteral("Remove-Printer -Name %1 -ErrorAction SilentlyContinue").arg(psQuote(NOM_IMPRIMANTE)));
    QThread::sleep(1);
    powershell(QStringLiteral("Remove-PrinterPort -Name %1 -ErrorAction SilentlyContinue").arg(psQuote(spool)));
    journal(QStringLiteral("Partie élevée : imprimante et port retirés"));
    return 0;
}

// ---------------------------------------------------------------------------
// GUETTEUR — surveille le spool et ouvre Feuillet à chaque impression
// ---------------------------------------------------------------------------
int guetteur()
{
#ifndef Q_OS_WIN
    return 0;
#else
    // Instance unique — le mutex reste tenu tant que le guetteur vit.
    HANDLE h = CreateMutexW(nullptr, FALSE, NOM_MUTEX);
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        if (h)
            CloseHandle(h);
        return 0;
    }
    journal(QStringLiteral("Guetteur démarré"));
    QDir().mkpath(dossierSpool());
    QDir().mkpath(dossierImpressions());
    nettoyerVieillesImpressions();

    const QString spool = fichierSpool();
    for (;;) {
        if (QFileInfo::exists(drapeauStop())) {
            journal(QStringLiteral("Guetteur arrêté (drapeau de stop)"));
            break;
        }
        const QFileInfo fi(spool);
        if (fi.exists() && fi.size() > 0) {
            const QString dest = nomUnique();
            // Tant que le spouleur écrit encore, le déplacement est refusé : on
            // réessaiera au prochain tour. S'il réussit, le fichier est complet.
            const std::wstring de = QDir::toNativeSeparators(spool).toStdWString();
            const std::wstring vers = QDir::toNativeSeparators(dest).toStdWString();
            if (MoveFileExW(de.c_str(), vers.c_str(), MOVEFILE_REPLACE_EXISTING)) {
                journal(QStringLiteral("Impression reçue → ") + QFileInfo(dest).fileName());
                QString feuillet = exe();
                QFile f(fichierConfig());
                if (f.open(QIODevice::ReadOnly)) {
                    const QJsonObject cfg = QJsonDocument::fromJson(f.readAll()).object();
                    const QString lu = cfg.value(QStringLiteral("feuillet")).toString();
                    if (!lu.isEmpty() && QFileInfo(lu).isFile())
                        feuillet = lu;
                }
                if (!QProcess::startDetached(feuillet, {QDir::toNativeSeparators(dest)},
                                             QFileInfo(feuillet).absolutePath()))
                    journal(QStringLiteral("Impossible de lancer Feuillet : ") + feuillet);
            }
        }
        QThread::msleep(INTERVALLE_MS);
    }
    if (h)
        CloseHandle(h);
    return 0;
#endif
}

} // namespace driver
