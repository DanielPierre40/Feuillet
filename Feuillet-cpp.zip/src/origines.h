// origines — d'où vient chaque image posée sur la feuille.
//
// La provenance est notée UNE fois, par le chargeur, et rangée sous la clé de
// cache de la QPixmap. Toutes les copies d'une même image partagent cette
// clé : un élément collé, dupliqué ou recomposé retrouve sa provenance seul.
#pragma once

#include <QJsonObject>
#include <QPixmap>
#include <QString>

struct Origine {
    QString chemin;
    int page = 1;
    int pages = 1;
    bool estImage = false;
    bool valide() const { return !chemin.isEmpty(); }

    QJsonObject versJson() const;
    static Origine depuisJson(const QJsonObject &o);
};

namespace origines {

bool estImage(const QString &chemin);
void noter(const QPixmap &pixmap, const QString &chemin, int page = 1, int pages = 1);
Origine lire(const QPixmap &pixmap);

} // namespace origines
