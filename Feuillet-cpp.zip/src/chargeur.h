// chargeur — le chargement universel : tout ce qui entre dans Feuillet passe
// par ici et en ressort sous forme d'images (une par page pour un document).
//
// Tourne dans le fil de chargement : rend des QImage (les QPixmap ne se
// fabriquent que sur le fil de l'interface). Lève ErreurChargement.
#pragma once

#include <QImage>
#include <QList>
#include <QSize>
#include <QString>
#include <atomic>

class QWidget;

namespace chargeur {

// Marque d'un échec qui a DÉJÀ dit ce qu'il avait à dire dans sa propre
// fenêtre : la liste récapitulative des fichiers non chargés le passe.
inline const QString DEJA_DIT = QString(QChar(0x2400));

// `parent` sert aux questions posées (sur le fil de l'interface) ;
// `formatInconnu` est levé quand le fichier n'a pu être reconnu.
QList<QImage> charger(const QString &chemin, QWidget *parent, std::atomic<bool> *formatInconnu);

bool vientDuDriver(const QString &chemin);
QImage rognerBordsBlancs(const QImage &img);
QSize tailleRendu(double wPt, double hPt, int dpi);
QImage surBlanc(const QImage &img);

} // namespace chargeur
