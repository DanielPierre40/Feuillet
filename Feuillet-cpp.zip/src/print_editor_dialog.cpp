#include "print_editor_dialog.h"

#include "aide_dialog.h"
#include "apres_impression.h"
#include "barre_titre.h"
#include "barres_boutons.h"
#include "chargeur.h"
#include "choix_pages.h"
#include "config.h"
#include "editor_view.h"
#include "graphics_items.h"
#include "main_window.h"
#include "memoire_fenetres.h"
#include "options_dialog.h"
#include "theme.h"
#include "ui_helpers.h"

#include <QApplication>
#include <QBuffer>
#include <QDir>
#include <QCloseEvent>
#include <QDoubleSpinBox>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QGraphicsScene>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QJsonDocument>
#include <QJsonObject>
#include <QKeySequence>
#include <QLabel>
#include <QLinearGradient>
#include <QMenu>
#include <QMessageBox>
#include <QPainter>
#include <QPushButton>
#include <QSaveFile>
#include <QShortcut>
#include <QSlider>
#include <QSpinBox>
#include <QThread>
#include <QTimer>
#include <QVBoxLayout>

#include <algorithm>
#include <cmath>

namespace {
constexpr double MM_PAR_POINT = 25.4 / 72.0;
double enMm(double pt) { return pt * MM_PAR_POINT; }
double enPoints(double mm) { return mm / MM_PAR_POINT; }

QByteArray pngBase64(const QPixmap &pix)
{
    QByteArray ba;
    QBuffer buf(&ba);
    buf.open(QIODevice::WriteOnly);
    pix.save(&buf, "PNG");
    return ba.toBase64();
}
} // namespace

// ===========================================================================
// BoiteFormat — taille sur mesure, en millimètres
// ===========================================================================
BoiteFormat::BoiteFormat(double largeurPt, double hauteurPt, QWidget *parent) : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Taille personnalisée"));
    auto *colonne = new QVBoxLayout(this);
    colonne->setSpacing(10);
    auto *forme = new QFormLayout();
    forme->setSpacing(10);
    auto champ = [](double mm) {
        auto *c = new QDoubleSpinBox();
        c->setRange(20.0, 2000.0); // de la carte de visite à l'affiche
        c->setDecimals(1);
        c->setSuffix(QStringLiteral(" mm"));
        c->setValue(mm);
        return c;
    };
    m_l = champ(enMm(largeurPt));
    m_h = champ(enMm(hauteurPt));
    forme->addRow(QStringLiteral("Largeur :"), m_l);
    forme->addRow(QStringLiteral("Hauteur :"), m_h);
    colonne->addLayout(forme);
    auto *note = new QLabel(QStringLiteral("La feuille est décrite debout ; le bouton Portrait / Paysage\n"
                                           "la couche ensuite si besoin."));
    note->setStyleSheet(QStringLiteral("color: %1; font-size: 9pt;").arg(theme::FG2));
    colonne->addWidget(note);
    auto *boutons = new QHBoxLayout();
    auto *ok = new QPushButton(QStringLiteral("OK"));
    ok->setDefault(true);
    connect(ok, &QPushButton::clicked, this, &QDialog::accept);
    auto *annuler = new QPushButton(QStringLiteral("Annuler"));
    connect(annuler, &QPushButton::clicked, this, &QDialog::reject);
    boutons->addStretch();
    boutons->addWidget(ok);
    boutons->addWidget(annuler);
    colonne->addLayout(boutons);
    cadre::poserCadre(this, false, false);
}

QSizeF BoiteFormat::taille() const
{
    return QSizeF(enPoints(m_l->value()), enPoints(m_h->value()));
}

// ===========================================================================
// OmbreBarre — ombre douce portée par la barre du haut sur le plan de travail
// ===========================================================================
OmbreBarre::OmbreBarre(QWidget *parent, QWidget *barre) : QWidget(parent), m_barre(barre)
{
    // Sans cela, le voile intercepterait les clics destinés au plan de travail.
    setAttribute(Qt::WA_TransparentForMouseEvents);
    setAttribute(Qt::WA_NoSystemBackground);
    setAttribute(Qt::WA_TranslucentBackground);
    barre->installEventFilter(this);
    parent->installEventFilter(this);
    replacer();
    show();
}

void OmbreBarre::replacer()
{
    QWidget *porteur = parentWidget();
    if (!porteur)
        return;
    // La géométrie de la barre est dans le repère de SON parent : on convertit.
    const QPoint coin = m_barre->mapTo(porteur, QPoint(0, m_barre->height()));
    setGeometry(coin.x(), coin.y(), m_barre->width(), HAUTEUR);
    raise();
}

bool OmbreBarre::eventFilter(QObject *, QEvent *ev)
{
    const QEvent::Type t = ev->type();
    if (t == QEvent::Resize || t == QEvent::Move || t == QEvent::Show || t == QEvent::LayoutRequest)
        replacer();
    return false;
}

void OmbreBarre::paintEvent(QPaintEvent *)
{
    QLinearGradient deg(0, 0, 0, height());
    deg.setColorAt(0.0, QColor(0, 0, 0, NOIR));
    deg.setColorAt(0.35, QColor(0, 0, 0, NOIR / 3));
    deg.setColorAt(1.0, QColor(0, 0, 0, 0));
    QPainter p(this);
    p.fillRect(rect(), deg);
}

// ===========================================================================
// PrintEditorDialog — l'Atelier
// ===========================================================================
PrintEditorDialog::PrintEditorDialog(const QList<QPixmap> &pixmaps, MainWindow *hote)
    : QDialog(hote), m_hote(hote)
{
    setWindowTitle(QStringLiteral("Atelier — Feuillet"));
    resize(1100, 850);
    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);
    m_scene = new QGraphicsScene(this);
    // Les barres se déclarent au groupe en se construisant.
    m_barres = new GroupeBarres(this, [](const QJsonObject &a) { config::setAgencementBarres(a); });
    m_view = new EditorView(m_scene);
    m_view->hote = this;
    // Pas d'antialiasing sur la vue : il n'y a que des rectangles à bord droit.
    m_view->setRenderHint(QPainter::SmoothPixmapTransform);
    setSheetCount(1);

    layout->addWidget(construireBarreHaut());
    layout->addWidget(m_view);
    for (int idx = 0; idx < pixmaps.size(); ++idx) {
        // Cascade bouclée : au-delà de 18 éléments on repart du coin.
        const double off = (idx % 18) * 30;
        poserElement(pixmaps[idx], QPointF(20 + off, 20 + off));
    }

    auto *barreBas = new BarreBoutons(QStringLiteral("bas"), m_barres, this);
    // Sélecteur « BarreBoutons » : la règle ne vise que la barre.
    barreBas->setStyleSheet(QStringLiteral("BarreBoutons { background: %1; border-top: 1px solid %2; }")
                                .arg(theme::TOOLBAR_BG, theme::BORDER_COL));
    QHBoxLayout *barL = barreBas->layoutH();
    barL->setContentsMargins(12, 8, 12, 8);
    barL->setSpacing(8);

    auto bouton = [](const QString &texte) {
        auto *b = new QPushButton(texte);
        b->setMinimumHeight(36);
        return b;
    };
    QPushButton *btnSave = bouton(QStringLiteral("💾  Sauvegarder le feuillet…"));
    QPushButton *btnPrint = bouton(QStringLiteral("🖨️  Imprimer"));
    QPushButton *btnQuit = bouton(QStringLiteral("✕  Quitter"));
    QPushButton *btnRetour = bouton(QStringLiteral("← Retour"));
    connect(btnSave, &QPushButton::clicked, this, [this]() { saveFeuillet(); });
    connect(btnPrint, &QPushButton::clicked, this, &QDialog::accept);
    connect(btnQuit, &QPushButton::clicked, this, &PrintEditorDialog::quitter);
    connect(btnRetour, &QPushButton::clicked, this, &QDialog::reject);

    QPushButton *btnDup = bouton(QStringLiteral("⧉  Dupliquer  ▾"));
    btnDup->setToolTip(QStringLiteral("Remplit une page de plusieurs copies de son élément.\n"
                                      "Ne s'applique qu'aux pages ne portant qu'un seul élément ;\n"
                                      "si plusieurs pages y répondent, Feuillet demande lesquelles."));
    auto *menuDup = new QMenu(btnDup);
    menuDup->addAction(QStringLiteral("×2  —  2 copies (1 × 2)"), this, [this]() { dupliquer(2); });
    menuDup->addAction(QStringLiteral("×4  —  4 copies (2 × 2)"), this, [this]() { dupliquer(4); });
    menuDup->addAction(QStringLiteral("×8  —  8 copies (2 × 4)"), this, [this]() { dupliquer(8); });
    menuDup->addAction(QStringLiteral("×16  — 16 copies (4 × 4)"), this, [this]() { dupliquer(16); });
    // setMenu() ouvrirait le menu dès l'appui et empêcherait le déplacement.
    ouvrirMenuAuClic(btnDup, menuDup);

    m_btnFormat = bouton(QStringLiteral("📐  Format  ▾"));
    m_btnFormat->setToolTip(QStringLiteral("Taille des feuilles à imprimer.\n"
                                           "Le contenu déjà posé garde sa place relative sur sa page."));
    auto *menuFormat = new QMenu(m_btnFormat);
    menuFormat->addAction(QStringLiteral("A4  —  210 × 297 mm"), this, [this]() { choisirFormat(QStringLiteral("A4")); });
    menuFormat->addAction(QStringLiteral("A5  —  148 × 210 mm"), this, [this]() { choisirFormat(QStringLiteral("A5")); });
    menuFormat->addSeparator();
    menuFormat->addAction(QStringLiteral("Taille personnalisée…"), this, [this]() { formatPersonnalise(); });
    ouvrirMenuAuClic(m_btnFormat, menuFormat);

    m_btnOrient = bouton(QStringLiteral("⬒  Paysage"));
    connect(m_btnOrient, &QPushButton::clicked, this, &PrintEditorDialog::toggleOrientation);
    ui::addShadow(m_btnOrient);
    for (QPushButton *b : {btnSave, btnDup, m_btnFormat, btnPrint, btnQuit, btnRetour})
        ui::addShadow(b);

    auto *lblZoom = new QLabel(QStringLiteral("🔍"));
    lblZoom->setStyleSheet(QStringLiteral("background: transparent; border: none; padding: 0 3px; "
                                          "color: %1; font-size: 13pt;")
                               .arg(theme::FG));
    m_zoomSlider = new QSlider(Qt::Horizontal);
    m_zoomSlider->setRange(5, 400);
    m_zoomSlider->setValue(100);
    m_zoomSlider->setFixedWidth(160);
    m_zoomSlider->setToolTip(QStringLiteral("Zoom de la vue — molette de la souris sur le plan de travail"));
    m_zoomSlider->setStyleSheet(QStringLiteral("QSlider::groove:horizontal { background: %1; height: 4px; border-radius: 2px; }"
                                               "QSlider::handle:horizontal { background: %2; width: 14px; height: 14px;"
                                               "  border-radius: 7px; margin: -5px 0; }"
                                               "QSlider::sub-page:horizontal { background: %2; border-radius: 2px; }")
                                    .arg(theme::BORDER_COL, theme::ACCENT));
    m_zoomSpin = new QSpinBox();
    m_zoomSpin->setRange(5, 400);
    m_zoomSpin->setValue(100);
    m_zoomSpin->setSuffix(QStringLiteral(" %"));
    m_zoomSpin->setFixedWidth(72);
    m_zoomSpin->setAlignment(Qt::AlignCenter);
    connect(m_zoomSlider, &QSlider::valueChanged, this, &PrintEditorDialog::onZoomSlider);
    connect(m_zoomSpin, QOverload<int>::of(&QSpinBox::valueChanged), this, &PrintEditorDialog::onZoomSpin);
    connect(m_view, &EditorView::zoomChanged, this, &PrintEditorDialog::afficherZoom);

    // Chaque bouton reçoit un nom stable : la clé de sa place retenue.
    const QList<QPair<QPushButton *, QString>> deplacables = {
        {btnSave, QStringLiteral("sauvegarder")}, {btnDup, QStringLiteral("dupliquer")},
        {m_btnFormat, QStringLiteral("format")},  {m_btnOrient, QStringLiteral("orientation")},
        {btnPrint, QStringLiteral("imprimer")},   {btnQuit, QStringLiteral("quitter")},
        {btnRetour, QStringLiteral("retour")}};
    for (const auto &[b, nom] : deplacables)
        m_barres->rendreDeplacable(b, nom);
    // Le bouton d'orientation a DEUX libellés, chacun renommable à part.
    m_barres->declarerEtats(m_btnOrient,
                            {{QStringLiteral("portrait"), QStringLiteral("⬒  Paysage")},
                             {QStringLiteral("paysage"), QStringLiteral("⬓  Portrait")}},
                            m_isPortrait ? QStringLiteral("portrait") : QStringLiteral("paysage"));

    barL->addWidget(btnSave);
    barL->addWidget(btnDup);
    barL->addWidget(m_btnFormat);
    barL->addWidget(m_btnOrient);
    barL->addStretch();
    barL->addWidget(lblZoom);
    barL->addWidget(m_zoomSlider);
    barL->addWidget(m_zoomSpin);
    barL->addWidget(btnPrint);
    barL->addWidget(btnQuit);
    barL->addWidget(btnRetour);
    // Le curseur de zoom reste collé au bouton qui le précède.
    barreBas->collerAuPrecedent({lblZoom, m_zoomSlider, m_zoomSpin});
    layout->addWidget(barreBas);

    // Disposition d'usine notée, puis celle de l'utilisateur rétablie.
    m_barres->figerDispositionUsine();
    m_barres->appliquer(config::agencementBarres());
    fitView();
    installerHistorique();
    cadre::poserCadre(this);
    // L'ombre de la barre vient APRÈS le cadre : même repère que la barre.
    poserOmbreBarre();
    memoire::retenir(this, QStringLiteral("atelier"));
}

PrintEditorDialog::~PrintEditorDialog()
{
    delete m_historique;
}

// ---------------------------------------------------------------------------
// Annuler / Rétablir
// ---------------------------------------------------------------------------
void PrintEditorDialog::installerHistorique()
{
    m_historique = new Historique(this);
    m_minuteurHist = new QTimer(this);
    m_minuteurHist->setSingleShot(true);
    m_minuteurHist->setInterval(DELAI_VALIDATION);
    connect(m_minuteurHist, &QTimer::timeout, this, &PrintEditorDialog::validerHistorique);
    connect(m_scene, &QGraphicsScene::changed, this, [this]() { m_minuteurHist->start(); });

    connect(new QShortcut(QKeySequence::Undo, this), &QShortcut::activated, this, &PrintEditorDialog::annuler);
    connect(new QShortcut(QKeySequence::Redo, this), &QShortcut::activated, this, &PrintEditorDialog::retablir);
    // Sous Windows, Redo vaut Ctrl+Y : Ctrl+Maj+Z est libre.
    const QKeySequence ctrlMajZ(QStringLiteral("Ctrl+Shift+Z"));
    if (QKeySequence(QKeySequence::Redo) != ctrlMajZ)
        connect(new QShortcut(ctrlMajZ, this), &QShortcut::activated, this, &PrintEditorDialog::retablir);
    majBoutonsHistorique();
}

void PrintEditorDialog::validerHistorique()
{
    if (m_historique && m_historique->valider()) {
        // Un pas validé, c'est une modification RÉELLE.
        m_enregistre = false;
        majBoutonsHistorique();
    }
}

void PrintEditorDialog::majBoutonsHistorique()
{
    if (!m_historique)
        return;
    m_btnAnnuler->setEnabled(m_historique->peutAnnuler());
    m_btnRetablir->setEnabled(m_historique->peutRetablir());
}

void PrintEditorDialog::annuler()
{
    // La validation en attente est soldée d'abord.
    m_minuteurHist->stop();
    m_historique->valider();
    m_historique->annuler();
    majBoutonsHistorique();
}

void PrintEditorDialog::retablir()
{
    m_minuteurHist->stop();
    m_historique->retablir();
    majBoutonsHistorique();
}

void PrintEditorDialog::repartirDeZero()
{
    if (!m_historique)
        return;
    m_minuteurHist->stop();
    m_historique->oublier();
    majBoutonsHistorique();
}

PhotoEtat PrintEditorDialog::photoEtat() const
{
    PhotoEtat p;
    p.portrait = m_isPortrait;
    for (PaperItem *pap : m_papers)
        p.feuilles.append(pap->rect().size());
    for (ResizablePixmapItem *it : items())
        p.elements.append(ElementPhoto{it->originalPixmap, it->apercuCache(), it->pos().x(), it->pos().y(),
                                       it->pixmap().width(), it->pixmap().height()});
    return p;
}

void PrintEditorDialog::restaurerEtat(const PhotoEtat &photo)
{
    for (ResizablePixmapItem *it : items()) {
        m_scene->removeItem(it);
        delete it;
    }
    m_isPortrait = photo.portrait;
    afficherOrientation();
    setSheetCount(int(photo.feuilles.size()));
    for (int i = 0; i < m_papers.size() && i < photo.feuilles.size(); ++i)
        m_papers[i]->setRect(0, 0, photo.feuilles[i].width(), photo.feuilles[i].height());
    layoutSheets();
    for (const ElementPhoto &e : photo.elements) {
        auto *item = new ResizablePixmapItem(e.pixmap);
        if (!e.apercu.isNull())
            item->poserApercu(e.apercu);
        item->poserTaille(e.w, e.h);
        m_scene->addItem(item);
        item->setPos(e.x, e.y);
    }
}

// ---------------------------------------------------------------------------
// Barre du haut
// ---------------------------------------------------------------------------
QWidget *PrintEditorDialog::construireBarreHaut()
{
    m_barreHaut = new BarreBoutons(QStringLiteral("haut"), m_barres, this);
    m_barreHaut->setStyleSheet(QStringLiteral("BarreBoutons { background: %1; border-bottom: 1px solid %2; }")
                                   .arg(theme::TOOLBAR_BG, theme::BORDER_COL));
    QHBoxLayout *bl = m_barreHaut->layoutH();
    bl->setContentsMargins(12, 8, 12, 8);
    bl->setSpacing(8);

    auto bouton = [bl](const QString &texte, const QString &aideTexte) {
        auto *b = new QPushButton(texte);
        b->setMinimumHeight(36);
        b->setToolTip(aideTexte);
        ui::addShadow(b);
        bl->addWidget(b);
        return b;
    };
    m_btnAnnuler = bouton(QStringLiteral("Annuler"),
                          QStringLiteral("Revient sur la dernière modification  (Ctrl+Z)\n"
                                         "Déplacements, redimensionnements, ajouts, suppressions, duplications,\n"
                                         "changements d'orientation : tout est repris."));
    connect(m_btnAnnuler, &QPushButton::clicked, this, &PrintEditorDialog::annuler);
    m_btnRetablir = bouton(QStringLiteral("Rétablir"),
                           QStringLiteral("Refait ce qui vient d'être annulé  (Ctrl+Y)\n"
                                          "Toute nouvelle modification efface ce qu'il restait à rétablir."));
    connect(m_btnRetablir, &QPushButton::clicked, this, &PrintEditorDialog::retablir);
    m_btnImport = bouton(QStringLiteral("🖼️  Ajouter une image ou un document"),
                         QStringLiteral("Ouvre une image ou un document et le pose sur une NOUVELLE page,\n"
                                        "ajoutée à la suite des pages déjà présentes.\n"
                                        "Un document de plusieurs pages y dépose tous ses éléments."));
    connect(m_btnImport, &QPushButton::clicked, this, &PrintEditorDialog::ajouterDocument);
    QPushButton *btnAdd = bouton(QStringLiteral("➕  Ajouter une (ou plusieurs) pages"),
                                 QStringLiteral("Ajoute des pages à la suite de la page 1, alignées horizontalement.\n"
                                                "Chaque page est imprimée, dans l'ordre de son numéro."));
    connect(btnAdd, &QPushButton::clicked, this, [this]() { ajouterFeuilles(0); });
    QPushButton *btnRecentrer = bouton(QStringLiteral("🎯  Recentrer"),
                                       QStringLiteral("Ramène la vue sur la page 1, sans changer le zoom.\n"
                                                      "Utile après avoir fait glisser le plan de travail au loin."));
    connect(btnRecentrer, &QPushButton::clicked, this, &PrintEditorDialog::recentrer);
    QPushButton *btnOptions = bouton(QStringLiteral("⚙️  Options"),
                                     QStringLiteral("Ouvre les Options sans quitter l'Atelier :\n"
                                                    "qualité de rendu, image de fond du bureau,\n"
                                                    "driver d'impression."));
    connect(btnOptions, &QPushButton::clicked, this, &PrintEditorDialog::ouvrirOptions);
    QPushButton *btnAide = bouton(QStringLiteral("❔  Aide"),
                                  QStringLiteral("Ouvre l'aide sans quitter l'Atelier."));
    connect(btnAide, &QPushButton::clicked, this, &PrintEditorDialog::ouvrirAide);
    bl->addStretch();

    m_lblSheets = new QLabel();
    m_lblSheets->setStyleSheet(QStringLiteral("background: transparent; color: %1;"
                                              "font-family: '%2'; font-size: 9pt;")
                                   .arg(theme::FG2, theme::FONT_UI));
    bl->addWidget(m_lblSheets);
    const QList<QPair<QPushButton *, QString>> deplacables = {
        {m_btnAnnuler, QStringLiteral("annuler")},       {m_btnRetablir, QStringLiteral("retablir")},
        {m_btnImport, QStringLiteral("ajouter_document")}, {btnAdd, QStringLiteral("ajouter_pages")},
        {btnRecentrer, QStringLiteral("recentrer")},     {btnOptions, QStringLiteral("options")},
        {btnAide, QStringLiteral("aide")}};
    for (const auto &[b, nom] : deplacables)
        m_barres->rendreDeplacable(b, nom);
    layoutSheets(); // renseigne le compteur de feuilles
    return m_barreHaut;
}

void PrintEditorDialog::poserOmbreBarre()
{
    QWidget *porteur = cadre::contenuDe(this);
    m_ombreBarre = new OmbreBarre(porteur ? porteur : this, m_barreHaut);
}

void PrintEditorDialog::ouvrirAide()
{
    AideDialog d(this);
    d.exec();
}

void PrintEditorDialog::ouvrirOptions()
{
    OptionsDialog d(this);
    d.exec();
    // L'image de fond du bureau se règle dans les Options.
    m_view->rafraichirFond();
}

// ---------------------------------------------------------------------------
// Feuilles
// ---------------------------------------------------------------------------
void PrintEditorDialog::setSheetCount(int count)
{
    for (PaperItem *pap : std::as_const(m_papers)) {
        m_scene->removeItem(pap);
        delete pap;
    }
    m_papers.clear();
    const double w = m_isPortrait ? m_formatL : m_formatH;
    const double h = m_isPortrait ? m_formatH : m_formatL;
    for (int i = 0; i < qMax(1, count); ++i) {
        auto *pap = new PaperItem(w, h, i);
        m_scene->addItem(pap);
        m_papers.append(pap);
    }
    layoutSheets();
}

void PrintEditorDialog::layoutSheets()
{
    double x = 0.0;
    for (int i = 0; i < m_papers.size(); ++i) {
        m_papers[i]->setPos(x, 0);
        m_papers[i]->setIndex(i);
        x += m_papers[i]->rect().width() + GAP;
    }
    m_scene->setSceneRect(sheetsRect().adjusted(-GAP, -GAP - 24, GAP, GAP));
    if (m_lblSheets) {
        const int n = int(m_papers.size());
        m_lblSheets->setText(QStringLiteral("%1 page%2 à imprimer  ·  %3")
                                 .arg(n)
                                 .arg(n > 1 ? QStringLiteral("s") : QString())
                                 .arg(m_formatNom));
    }
}

QRectF PrintEditorDialog::sheetsRect() const
{
    if (m_papers.isEmpty())
        return QRectF(0, 0, 595, 842);
    QRectF r = m_papers.first()->scenePageRect();
    for (PaperItem *pap : m_papers)
        r = r.united(pap->scenePageRect());
    return r;
}

QRectF PrintEditorDialog::sheetRect(int index) const
{
    if (m_papers.isEmpty())
        return QRectF(0, 0, 595, 842);
    index = qBound(0, index, int(m_papers.size()) - 1);
    return m_papers[index]->scenePageRect();
}

void PrintEditorDialog::ajouterFeuilles(int n)
{
    if (n < 1) {
        bool ok = false;
        n = QInputDialog::getInt(this, QStringLiteral("Ajouter des pages"), QStringLiteral("Nombre de pages à ajouter :"),
                                 1, 1, 20, 1, &ok);
        if (!ok)
            return;
    }
    QList<QPair<ResizablePixmapItem *, QPointF>> garde;
    for (ResizablePixmapItem *it : items())
        garde.append({it, it->pos()});
    setSheetCount(int(m_papers.size()) + n);
    for (const auto &[it, pos] : garde)
        it->setPos(pos);
    fitView();
}

QList<ResizablePixmapItem *> PrintEditorDialog::items() const
{
    // Du dessous vers le dessus : l'historique et la sauvegarde reposent
    // ainsi les éléments dans leur ordre d'empilement d'origine.
    QList<ResizablePixmapItem *> r;
    const auto tous = m_scene->items(Qt::AscendingOrder);
    for (QGraphicsItem *it : tous)
        if (auto *e = qgraphicsitem_cast<ResizablePixmapItem *>(it))
            r.append(e);
    return r;
}

void PrintEditorDialog::fitView()
{
    m_view->fitInView(sheetsRect().adjusted(-GAP, -GAP - 24, GAP, GAP), Qt::KeepAspectRatio);
    afficherZoom(int(std::round(m_view->transform().m11() * 100)));
}

void PrintEditorDialog::poserElement(const QPixmap &pixmap, const QPointF &pos, int tailleMax)
{
    auto *item = new ResizablePixmapItem(pixmap);
    item->setDisplaySize(tailleMax, tailleMax);
    m_scene->addItem(item);
    item->setPos(pos);
}

// ---------------------------------------------------------------------------
// Feuilles — copier, coller, supprimer, réordonner
// ---------------------------------------------------------------------------
QList<PrintEditorDialog::Releve> PrintEditorDialog::releveContenu() const
{
    QList<QRectF> rects;
    for (PaperItem *p : m_papers)
        rects.append(p->scenePageRect());
    QList<Releve> releve;
    for (ResizablePixmapItem *it : items()) {
        const QPointF centre = it->centreScene();
        std::optional<int> owner;
        for (int i = 0; i < rects.size(); ++i)
            if (rects[i].contains(centre)) {
                owner = i;
                break;
            }
        if (!owner) {
            releve.append({it, std::nullopt, QPointF()});
        } else {
            const QRectF &r = rects[*owner];
            releve.append({it, owner, QPointF(it->pos().x() - r.x(), it->pos().y() - r.y())});
        }
    }
    return releve;
}

void PrintEditorDialog::reposerContenu(const QList<Releve> &releve,
                                       const std::function<std::optional<int>(int)> &decalage)
{
    for (const Releve &r : releve) {
        if (!r.owner)
            continue;
        const auto nouveau = decalage(*r.owner);
        if (!nouveau)
            continue;
        const QRectF s = sheetRect(*nouveau);
        r.item->setPos(s.x() + r.ecart.x(), s.y() + r.ecart.y());
    }
}

int PrintEditorDialog::feuilleIndexInsertion(double xScene) const
{
    // Le rang bascule au milieu de chaque feuille : un geste franc.
    int rang = 0;
    for (int i = 0; i < m_papers.size(); ++i)
        if (xScene > m_papers[i]->scenePageRect().center().x())
            rang = i + 1;
    return rang;
}

std::optional<QLineF> PrintEditorDialog::traitInsertion(int index) const
{
    if (m_papers.isEmpty())
        return std::nullopt;
    QList<QRectF> rects;
    for (PaperItem *p : m_papers)
        rects.append(p->scenePageRect());
    double haut = rects.first().top(), bas = rects.first().bottom();
    for (const QRectF &r : rects) {
        haut = qMin(haut, r.top());
        bas = qMax(bas, r.bottom());
    }
    haut -= 24;
    bas += 12;
    double x;
    if (index <= 0)
        x = rects.first().left() - GAP / 2;
    else if (index >= rects.size())
        x = rects.last().right() + GAP / 2;
    else
        x = (rects[index - 1].right() + rects[index].left()) / 2;
    return QLineF(x, haut, x, bas);
}

void PrintEditorDialog::deplacerFeuille(int depuis, int vers)
{
    if (depuis < 0 || depuis >= m_papers.size())
        return;
    vers = qBound(0, vers, int(m_papers.size()));
    if (vers > depuis)
        --vers;
    if (vers == depuis)
        return;
    const QList<Releve> releve = releveContenu();
    m_papers.insert(vers, m_papers.takeAt(depuis));
    layoutSheets();
    reposerContenu(releve, [depuis, vers](int ancien) -> std::optional<int> {
        if (ancien == depuis)
            return vers;
        if (depuis < ancien && ancien <= vers)
            return ancien - 1;
        if (vers <= ancien && ancien < depuis)
            return ancien + 1;
        return ancien;
    });
}

void PrintEditorDialog::copierFeuille(int index)
{
    if (index < 0 || index >= m_papers.size())
        return;
    PaperItem *pap = m_papers[index];
    const QRectF r = pap->scenePageRect();
    FeuilleCopiee f{pap->rect().width(), pap->rect().height(), {}};
    for (ResizablePixmapItem *it : items()) {
        if (!r.contains(it->centreScene()))
            continue;
        f.items.append(ContenuCopie{it->originalPixmap, it->pos().x() - r.x(), it->pos().y() - r.y(),
                                    it->pixmap().width(), it->pixmap().height()});
    }
    m_feuilleCopiee = f;
}

void PrintEditorDialog::collerFeuille()
{
    if (!m_feuilleCopiee)
        return;
    QStringList choix;
    for (int i = 0; i < m_papers.size(); ++i)
        choix << QStringLiteral("Avant la page %1").arg(i + 1);
    choix << QStringLiteral("À la fin");
    bool ok = false;
    const QString texte = QInputDialog::getItem(this, QStringLiteral("Coller la page"),
                                                QStringLiteral("Où insérer la page copiée ?"), choix,
                                                int(choix.size()) - 1, false, &ok);
    if (!ok || !choix.contains(texte))
        return;
    insererFeuille(int(choix.indexOf(texte)), *m_feuilleCopiee);
}

void PrintEditorDialog::insererFeuille(int position, const FeuilleCopiee &data)
{
    position = qBound(0, position, int(m_papers.size()));
    const QList<Releve> releve = releveContenu();
    auto *pap = new PaperItem(data.w, data.h, position);
    m_scene->addItem(pap);
    m_papers.insert(position, pap);
    layoutSheets();
    // Les feuilles à partir de la position d'insertion ont reculé d'un rang.
    reposerContenu(releve, [position](int a) -> std::optional<int> { return a >= position ? a + 1 : a; });
    const QRectF r = sheetRect(position);
    for (const ContenuCopie &c : data.items) {
        auto *item = new ResizablePixmapItem(c.pixmap);
        item->poserTaille(c.w, c.h);
        m_scene->addItem(item);
        item->setPos(r.x() + c.dx, r.y() + c.dy);
    }
    fitView();
}

void PrintEditorDialog::supprimerFeuille(int index)
{
    if (index < 0 || index >= m_papers.size())
        return;
    if (m_papers.size() <= 1) {
        QMessageBox::information(this, QStringLiteral("Supprimer la page"),
                                 QStringLiteral("Il doit rester au moins une page."));
        return;
    }
    if (QMessageBox::question(this, QStringLiteral("Supprimer la page"),
                              QStringLiteral("Supprimer la page %1 et tout ce qu'elle porte ?").arg(index + 1),
                              QMessageBox::Yes | QMessageBox::No, QMessageBox::No)
        != QMessageBox::Yes)
        return;
    const QList<Releve> releve = releveContenu();
    QList<Releve> restants;
    for (const Releve &r : releve) {
        if (r.owner && *r.owner == index) {
            m_scene->removeItem(r.item);
            delete r.item;
        } else {
            restants.append(r);
        }
    }
    PaperItem *pap = m_papers.takeAt(index);
    m_scene->removeItem(pap);
    delete pap;
    layoutSheets();
    reposerContenu(restants, [index](int a) -> std::optional<int> { return a > index ? a - 1 : a; });
    fitView();
}

// ---------------------------------------------------------------------------
// Ajout d'une image ou d'un document sur une nouvelle feuille
// ---------------------------------------------------------------------------
void PrintEditorDialog::ajouterDocument()
{
    if (m_chargement || !m_hote)
        return;
    const QStringList chemins = QFileDialog::getOpenFileNames(this, QStringLiteral("Ajouter une image ou un document"),
                                                              config::departFichier(),
                                                              QStringLiteral("Tous les fichiers (*)"));
    if (chemins.isEmpty())
        return;
    if (!m_voile) {
        // Dans le cadre arrondi, pas sur la fenêtre.
        QWidget *porteur = cadre::contenuDe(this);
        m_voile = new LoadingOverlay(porteur ? porteur : this);
    }
    m_chargement = true;
    m_btnImport->setEnabled(false);
    m_voile->start();

    auto *fil = new QThread();
    auto *ouvrier = new LoadWorker(m_hote->chargeur(), chemins);
    ouvrier->moveToThread(fil);
    connect(fil, &QThread::started, ouvrier, &LoadWorker::run);
    connect(ouvrier, &LoadWorker::termine, this, &PrintEditorDialog::documentCharge);
    connect(ouvrier, &LoadWorker::termine, fil, &QThread::quit);
    connect(fil, &QThread::finished, ouvrier, &QObject::deleteLater);
    connect(fil, &QThread::finished, fil, &QObject::deleteLater);
    fil->start();
}

void PrintEditorDialog::documentCharge(const QList<ImageChargee> &images, const QStringList &erreursBrutes)
{
    m_chargement = false;
    m_btnImport->setEnabled(true);
    if (m_voile)
        m_voile->stop();
    // Un format inconnu se dit une fois le voile retiré.
    if (m_hote)
        m_hote->direFormatInconnu(this);
    QStringList erreurs;
    for (const QString &e : erreursBrutes)
        if (!e.endsWith(chargeur::DEJA_DIT))
            erreurs << e;
    if (!erreurs.isEmpty())
        QMessageBox::warning(this, QStringLiteral("Fichiers non chargés"),
                             QStringLiteral("Certains fichiers n'ont pas pu être ouverts :\n\n") + erreurs.join(QLatin1Char('\n')));
    const QList<QPixmap> pixmaps = pixmapsDepuis(images);
    if (pixmaps.isEmpty())
        return;
    // Une feuille neuve à la suite, puis tout le contenu posé dessus.
    ajouterFeuilles(1);
    const QRectF feuille = sheetRect(int(m_papers.size()) - 1);
    for (int idx = 0; idx < pixmaps.size(); ++idx) {
        const double off = (idx % 18) * 30;
        poserElement(pixmaps[idx], QPointF(feuille.x() + 20 + off, feuille.y() + 20 + off));
    }
    fitView();
}

void PrintEditorDialog::recentrer()
{
    if (m_papers.isEmpty())
        return;
    layoutSheets();
    const QPointF cible = sheetRect(0).center();
    const QRectF vue = m_view->mapToScene(m_view->viewport()->rect()).boundingRect();
    QRectF autour(0, 0, vue.width(), vue.height());
    autour.moveCenter(cible);
    m_scene->setSceneRect(m_scene->sceneRect().united(autour));
    m_view->centerOn(cible);
}

void PrintEditorDialog::onZoomSlider(int v)
{
    m_zoomSpin->blockSignals(true);
    m_zoomSpin->setValue(v);
    m_zoomSpin->blockSignals(false);
    applyZoom(v);
}

void PrintEditorDialog::onZoomSpin(int v)
{
    m_zoomSlider->blockSignals(true);
    m_zoomSlider->setValue(v);
    m_zoomSlider->blockSignals(false);
    applyZoom(v);
}

void PrintEditorDialog::afficherZoom(int pourcent)
{
    pourcent = qBound(5, pourcent, 400);
    for (QAbstractSlider *s : {static_cast<QAbstractSlider *>(m_zoomSlider)}) {
        s->blockSignals(true);
        s->setValue(pourcent);
        s->blockSignals(false);
    }
    m_zoomSpin->blockSignals(true);
    m_zoomSpin->setValue(pourcent);
    m_zoomSpin->blockSignals(false);
}

void PrintEditorDialog::applyZoom(int pourcent)
{
    m_view->debutRenduRapide();
    const double f = pourcent / 100.0;
    m_view->resetTransform();
    m_view->scale(f, f);
    m_view->programmerRenduFin();
}

// ---------------------------------------------------------------------------
// Sortie
// ---------------------------------------------------------------------------
void PrintEditorDialog::marquerEnregistre()
{
    // La validation en attente est soldée D'ABORD, sinon elle rabaisserait le
    // drapeau qu'on vient de lever.
    if (m_minuteurHist) {
        m_minuteurHist->stop();
        validerHistorique();
    }
    m_enregistre = true;
}

bool PrintEditorDialog::rienAPerdre() const
{
    return m_enregistre || items().isEmpty();
}

bool PrintEditorDialog::portesDeSortie()
{
    if (m_sortieDemandee)
        return true;
    if (rienAPerdre())
        return true;
    for (;;) {
        const int choix = demanderAvantDeQuitter(this);
        if (choix == ApresImpressionDialog::SAUVER) {
            if (saveFeuillet())
                return true;
            continue; // sauvegarde abandonnée : on repropose
        }
        return choix == ApresImpressionDialog::QUITTER;
    }
}

void PrintEditorDialog::quitter()
{
    if (portesDeSortie()) {
        demanderLaSortie();
        reject();
    }
}

void PrintEditorDialog::closeEvent(QCloseEvent *e)
{
    // La croix de la barre de titre passe par ici (et elle seule).
    if (portesDeSortie()) {
        demanderLaSortie();
        e->accept();
    } else {
        e->ignore();
    }
}

bool PrintEditorDialog::saveFeuillet()
{
    QString chemin = QFileDialog::getSaveFileName(this, QStringLiteral("Sauvegarder le feuillet"),
                                                  config::departFichier(), QStringLiteral("Feuillet (*.feuillet)"));
    if (chemin.isEmpty())
        return false;
    if (!chemin.endsWith(QLatin1String(".feuillet")))
        chemin += QStringLiteral(".feuillet");

    QApplication::setOverrideCursor(Qt::WaitCursor);
    QJsonArray sheets;
    for (PaperItem *pap : std::as_const(m_papers)) {
        QJsonObject s;
        s.insert(QStringLiteral("x"), pap->pos().x());
        s.insert(QStringLiteral("y"), pap->pos().y());
        s.insert(QStringLiteral("w"), pap->rect().width());
        s.insert(QStringLiteral("h"), pap->rect().height());
        sheets.append(s);
    }
    QJsonArray data;
    for (ResizablePixmapItem *it : items()) {
        QJsonObject o;
        o.insert(QStringLiteral("x"), it->pos().x());
        o.insert(QStringLiteral("y"), it->pos().y());
        o.insert(QStringLiteral("w"), it->pixmap().width());
        o.insert(QStringLiteral("h"), it->pixmap().height());
        o.insert(QStringLiteral("pixmap"), QString::fromLatin1(pngBase64(it->pixmap())));
        o.insert(QStringLiteral("original"), QString::fromLatin1(pngBase64(it->originalPixmap)));
        // La carte d'identité de l'élément survit à l'enregistrement.
        o.insert(QStringLiteral("origine"), it->origine.valide() ? QJsonValue(it->origine.versJson()) : QJsonValue());
        data.append(o);
    }
    QJsonObject racine;
    racine.insert(QStringLiteral("version"), 2);
    racine.insert(QStringLiteral("sheets"), sheets);
    racine.insert(QStringLiteral("items"), data);
    QSaveFile f(chemin);
    const bool ok = f.open(QIODevice::WriteOnly) && f.write(QJsonDocument(racine).toJson(QJsonDocument::Compact)) >= 0
                    && f.commit();
    QApplication::restoreOverrideCursor();
    if (!ok) {
        QMessageBox::critical(this, QStringLiteral("Sauvegarder le feuillet"),
                              QStringLiteral("Le fichier n'a pas pu être écrit :\n%1").arg(QDir::toNativeSeparators(chemin)));
        return false;
    }
    marquerEnregistre();
    return true;
}

void PrintEditorDialog::restoreSheets(const QJsonArray &sheets)
{
    if (sheets.isEmpty())
        return;
    const QJsonObject s0 = sheets.first().toObject();
    const double w0 = s0.value(QStringLiteral("w")).toDouble(), h0 = s0.value(QStringLiteral("h")).toDouble();
    m_isPortrait = h0 >= w0;
    // Le format se relit dans la taille de la première feuille, ramenée debout.
    m_formatL = qMin(w0, h0);
    m_formatH = qMax(w0, h0);
    m_formatNom = nomDuFormat(m_formatL, m_formatH);
    setSheetCount(int(sheets.size()));
    for (int i = 0; i < m_papers.size() && i < sheets.size(); ++i) {
        const QJsonObject s = sheets[i].toObject();
        m_papers[i]->setRect(0, 0, s.value(QStringLiteral("w")).toDouble(), s.value(QStringLiteral("h")).toDouble());
        m_papers[i]->setPos(s.value(QStringLiteral("x")).toDouble(), s.value(QStringLiteral("y")).toDouble());
    }
    layoutSheets();
    afficherOrientation();
    fitView();
}

// ---------------------------------------------------------------------------
// Duplication
// ---------------------------------------------------------------------------
int PrintEditorDialog::activeSheetIndex() const
{
    QList<ResizablePixmapItem *> sel;
    for (QGraphicsItem *it : m_scene->selectedItems())
        if (auto *r = qgraphicsitem_cast<ResizablePixmapItem *>(it))
            sel.append(r);
    const auto liste = sel.isEmpty() ? items() : sel;
    for (ResizablePixmapItem *it : liste) {
        const QPointF c = it->centreScene();
        for (int i = 0; i < m_papers.size(); ++i)
            if (m_papers[i]->scenePageRect().contains(c))
                return i;
    }
    return 0;
}

QList<ResizablePixmapItem *> PrintEditorDialog::elementsDePage(int index) const
{
    const QRectF s = sheetRect(index);
    QList<ResizablePixmapItem *> r;
    for (ResizablePixmapItem *it : items())
        if (s.contains(it->centreScene()))
            r.append(it);
    return r;
}

QList<int> PrintEditorDialog::pagesDupliquables() const
{
    QList<int> r;
    for (int i = 0; i < m_papers.size(); ++i)
        if (elementsDePage(i).size() == 1)
            r.append(i);
    return r;
}

QString PrintEditorDialog::nomElement(int index) const
{
    const QString libelle = QStringLiteral("Page %1").arg(index + 1);
    const auto elements = elementsDePage(index);
    if (elements.isEmpty())
        return libelle;
    const Origine &o = elements.first()->origine;
    if (o.chemin.isEmpty())
        return libelle;
    QString nom = QFileInfo(o.chemin).fileName();
    if (o.pages > 1)
        nom += QStringLiteral(" (page %1)").arg(o.page);
    return libelle + QStringLiteral("  —  ") + nom;
}

void PrintEditorDialog::dupliquer(int n)
{
    const QList<int> eligibles = pagesDupliquables();
    if (eligibles.isEmpty()) {
        expliquerRefus();
        return;
    }
    QList<int> cibles;
    if (eligibles.size() == 1) {
        cibles = eligibles;
    } else {
        const int actif = activeSheetIndex();
        QList<QPair<int, QString>> pages;
        for (int i : eligibles)
            pages.append({i, nomElement(i)});
        ChoixPagesDialog d(pages, n, eligibles.contains(actif) ? actif : eligibles.first(), this);
        const auto choix = d.choisir();
        if (!choix || choix->isEmpty())
            return;
        cibles = *choix;
    }
    for (int index : cibles)
        dupliquerSur(index, n);
    m_lastDupN = n;
}

void PrintEditorDialog::expliquerRefus()
{
    QStringList etat;
    for (int i = 0; i < m_papers.size(); ++i) {
        const int k = int(elementsDePage(i).size());
        etat << (k == 0 ? QStringLiteral("    Page %1 : vide").arg(i + 1)
                        : QStringLiteral("    Page %1 : %2 éléments").arg(i + 1).arg(k));
    }
    if (etat.size() > 12) {
        etat = etat.mid(0, 12);
        etat << QStringLiteral("    … et %1 autres pages").arg(m_papers.size() - 12);
    }
    QMessageBox::information(this, QStringLiteral("Dupliquer"),
                             QStringLiteral("La duplication ne s'applique qu'à une page ne portant qu'un "
                                            "seul élément : elle remplit la page de copies de cet élément.\n\n"
                                            "Aucune page ne remplit cette condition.\n\n")
                                 + etat.join(QLatin1Char('\n'))
                                 + QStringLiteral("\n\nPour dupliquer, placez l'élément voulu seul sur une page — au "
                                                  "besoin en ajoutant une page et en l'y déplaçant."));
}

void PrintEditorDialog::dupliquerSur(int sheetIndex, int n)
{
    const QRectF sheet = sheetRect(sheetIndex);
    const double ox = sheet.x(), oy = sheet.y(), PW = sheet.width(), PH = sheet.height();
    const double MARGIN = 4;

    QList<ResizablePixmapItem *> surFeuille;
    QList<QPixmap> sources;
    for (ResizablePixmapItem *it : items())
        if (sheet.contains(it->centreScene())) {
            surFeuille.append(it);
            sources.append(it->originalPixmap);
        }
    if (sources.isEmpty())
        return;

    int colsP, rowsP;
    switch (n) {
    case 2: colsP = 1; rowsP = 2; break;
    case 4: colsP = 2; rowsP = 2; break;
    case 8: colsP = 2; rowsP = 4; break;
    case 16: colsP = 4; rowsP = 4; break;
    default: {
        colsP = int(std::ceil(std::sqrt(double(n))));
        rowsP = int(std::ceil(double(n) / colsP));
    }
    }
    const bool portrait = m_papers[sheetIndex]->isPortrait();
    const int cols = portrait ? colsP : rowsP;
    const int rows = portrait ? rowsP : colsP;

    for (ResizablePixmapItem *it : surFeuille) {
        m_scene->removeItem(it);
        delete it;
    }
    const double cellW = (PW - MARGIN * (cols + 1)) / cols;
    const double cellH = (PH - MARGIN * (rows + 1)) / rows;
    int slot = 0;
    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            if (slot >= n)
                break;
            auto *item = new ResizablePixmapItem(sources[slot % sources.size()]);
            item->setDisplaySize(int(cellW), int(cellH));
            if (col * (cellW + MARGIN) + MARGIN + item->pixmap().width() > PW)
                item->setDisplaySize(int(PW - col * (cellW + MARGIN) - MARGIN * 2), int(cellH));
            if (row * (cellH + MARGIN) + MARGIN + item->pixmap().height() > PH)
                item->setDisplaySize(item->pixmap().width(), int(PH - row * (cellH + MARGIN) - MARGIN * 2));
            m_scene->addItem(item);
            const QPixmap disp = item->pixmap();
            const double x = MARGIN + col * (cellW + MARGIN) + (cellW - disp.width()) / 2;
            const double y = MARGIN + row * (cellH + MARGIN) + (cellH - disp.height()) / 2;
            item->setPos(ox + x, oy + y);
            ++slot;
        }
    }
}

// ---------------------------------------------------------------------------
// Orientation et format
// ---------------------------------------------------------------------------
void PrintEditorDialog::afficherOrientation()
{
    m_barres->changerEtat(m_btnOrient, m_isPortrait ? QStringLiteral("portrait") : QStringLiteral("paysage"));
}

void PrintEditorDialog::refaireFeuilles()
{
    // Chaque élément retrouve la place relative de son centre sur SA page.
    QList<QRectF> anciens;
    for (PaperItem *p : std::as_const(m_papers))
        anciens.append(p->scenePageRect());
    struct Placement {
        ResizablePixmapItem *it;
        int owner;
        double rx, ry;
    };
    QList<Placement> placement;
    for (ResizablePixmapItem *it : items()) {
        const QPointF c = it->centreScene();
        int owner = 0;
        for (int i = 0; i < anciens.size(); ++i)
            if (anciens[i].contains(c)) {
                owner = i;
                break;
            }
        const QRectF &r = anciens[owner];
        placement.append({it, owner, (c.x() - r.x()) / r.width(), (c.y() - r.y()) / r.height()});
    }
    setSheetCount(int(m_papers.size()));
    for (const Placement &p : placement) {
        const QRectF nr = sheetRect(p.owner);
        const QPixmap disp = p.it->pixmap();
        p.it->setPos(nr.x() + p.rx * nr.width() - disp.width() / 2.0, nr.y() + p.ry * nr.height() - disp.height() / 2.0);
    }
    // C'est le MOTEUR qu'on rappelle, pas la commande (la page porte n éléments).
    if (m_lastDupN && m_papers.size() == 1)
        dupliquerSur(0, *m_lastDupN);
    fitView();
}

void PrintEditorDialog::toggleOrientation()
{
    m_isPortrait = !m_isPortrait;
    afficherOrientation();
    refaireFeuilles();
}

void PrintEditorDialog::choisirFormat(const QString &nom)
{
    if (nom == QLatin1String("A4"))
        appliquerFormat(nom, A4_L, A4_H);
    else if (nom == QLatin1String("A5"))
        appliquerFormat(nom, A5_L, A5_H);
}

void PrintEditorDialog::formatPersonnalise()
{
    BoiteFormat boite(m_formatL, m_formatH, this);
    if (boite.exec() != QDialog::Accepted)
        return;
    const QSizeF t = boite.taille();
    appliquerFormat(nomDuFormat(t.width(), t.height()), t.width(), t.height());
}

QString PrintEditorDialog::nomDuFormat(double largeur, double hauteur)
{
    // La tolérance d'un point rattrape les arrondis.
    if (qAbs(largeur - A4_L) <= 1.0 && qAbs(hauteur - A4_H) <= 1.0)
        return QStringLiteral("A4");
    if (qAbs(largeur - A5_L) <= 1.0 && qAbs(hauteur - A5_H) <= 1.0)
        return QStringLiteral("A5");
    return QStringLiteral("%1 × %2 mm").arg(enMm(largeur), 0, 'f', 0).arg(enMm(hauteur), 0, 'f', 0);
}

void PrintEditorDialog::appliquerFormat(const QString &nom, double l, double h)
{
    m_formatNom = nom;
    m_formatL = l;
    m_formatH = h;
    refaireFeuilles();
}
