#include "choix_pages.h"

#include "barre_titre.h"
#include "theme.h"

#include <QCheckBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QScrollArea>
#include <QVBoxLayout>

ChoixPagesDialog::ChoixPagesDialog(const QList<QPair<int, QString>> &pages, int copies, int defaut,
                                   QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Dupliquer"));
    setModal(true);
    setMinimumWidth(420);

    auto *root = new QVBoxLayout(this);
    root->setContentsMargins(22, 20, 22, 18);
    root->setSpacing(12);

    auto *titre = new QLabel(QStringLiteral("Dupliquer en %1 exemplaires").arg(copies));
    titre->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: 13pt;"
                                        "font-weight: 600; background: transparent;")
                             .arg(theme::FG, theme::FONT_UI));
    root->addWidget(titre);

    auto *expli = new QLabel(QStringLiteral("Plusieurs pages ne portent qu'un seul élément. "
                                            "Sur quelles pages appliquer la duplication ?"));
    expli->setWordWrap(true);
    expli->setStyleSheet(QStringLiteral("color: #8a92aa; font-family: '%1'; font-size: 9pt;"
                                        "background: transparent;")
                             .arg(theme::FONT_UI));
    root->addWidget(expli);

    auto *interieur = new QWidget();
    auto *vl = new QVBoxLayout(interieur);
    vl->setContentsMargins(10, 8, 10, 8);
    vl->setSpacing(4);
    for (const auto &[index, libelle] : pages) {
        auto *c = new QCheckBox(libelle);
        c->setChecked(index == defaut);
        c->setStyleSheet(QStringLiteral("QCheckBox { color: %1; font-family: '%2';"
                                        "  font-size: 10pt; background: transparent; padding: 3px; }")
                             .arg(theme::FG, theme::FONT_UI));
        connect(c, &QCheckBox::toggled, this, &ChoixPagesDialog::majBouton);
        m_cases.append({c, index});
        vl->addWidget(c);
    }
    vl->addStretch();

    auto *zone = new QScrollArea();
    zone->setWidget(interieur);
    zone->setWidgetResizable(true);
    zone->setFixedHeight(qMin(260, 40 + 30 * int(pages.size())));
    zone->setStyleSheet(QStringLiteral("QScrollArea { background: %1;"
                                       "  border: 1px solid %2; border-radius: 4px; }")
                            .arg(theme::BG_EDITOR, theme::BORDER_COL));
    root->addWidget(zone);

    auto *barre = new QHBoxLayout();
    barre->setSpacing(8);
    auto *btnTout = new QPushButton(QStringLiteral("Tout cocher"));
    btnTout->setMinimumHeight(32);
    connect(btnTout, &QPushButton::clicked, this, [this]() { cocher(true); });
    barre->addWidget(btnTout);
    auto *btnRien = new QPushButton(QStringLiteral("Tout décocher"));
    btnRien->setMinimumHeight(32);
    connect(btnRien, &QPushButton::clicked, this, [this]() { cocher(false); });
    barre->addWidget(btnRien);
    barre->addStretch();
    auto *btnAnnuler = new QPushButton(QStringLiteral("Annuler"));
    btnAnnuler->setMinimumHeight(32);
    connect(btnAnnuler, &QPushButton::clicked, this, &QDialog::reject);
    barre->addWidget(btnAnnuler);
    m_btnOk = new QPushButton(QStringLiteral("Dupliquer"));
    m_btnOk->setMinimumHeight(32);
    m_btnOk->setDefault(true);
    m_btnOk->setStyleSheet(QStringLiteral("QPushButton { border-color: %1; }").arg(theme::ACCENT));
    connect(m_btnOk, &QPushButton::clicked, this, &QDialog::accept);
    barre->addWidget(m_btnOk);
    root->addLayout(barre);
    majBouton();

    cadre::poserCadre(this, false, false);
}

void ChoixPagesDialog::cocher(bool etat)
{
    for (const auto &c : std::as_const(m_cases))
        c.first->setChecked(etat);
}

void ChoixPagesDialog::majBouton()
{
    bool une = false;
    for (const auto &c : std::as_const(m_cases))
        une = une || c.first->isChecked();
    m_btnOk->setEnabled(une);
}

std::optional<QList<int>> ChoixPagesDialog::choisir()
{
    if (exec() != QDialog::Accepted)
        return std::nullopt;
    QList<int> r;
    for (const auto &c : std::as_const(m_cases))
        if (c.first->isChecked())
            r.append(c.second);
    return r;
}
