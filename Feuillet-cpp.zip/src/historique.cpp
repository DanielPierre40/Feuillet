#include "historique.h"

#include <QStringList>
#include <cmath>

Historique::Historique(HoteHistorique *hote)
    : m_hote(hote), m_courant(hote->photoEtat())
{
}

static QString arrondi(double v)
{
    // Au dixième de point : un écart d'arrondi invisible ne compte pas.
    return QString::number(std::round(v * 10.0) / 10.0, 'f', 1);
}

QString Historique::signature(const PhotoEtat &photo)
{
    QStringList feuilles;
    for (const QSizeF &f : photo.feuilles)
        feuilles << arrondi(f.width()) + QLatin1Char('x') + arrondi(f.height());

    // Les éléments sont triés : l'ordre d'empilement peut changer sans que la
    // mise en page bouge.
    QStringList elements;
    for (const ElementPhoto &e : photo.elements)
        elements << QStringLiteral("%1|%2|%3|%4|%5")
                        .arg(e.pixmap.cacheKey())
                        .arg(arrondi(e.x), arrondi(e.y))
                        .arg(e.w)
                        .arg(e.h);
    elements.sort();

    return (photo.portrait ? QStringLiteral("P;") : QStringLiteral("L;"))
           + feuilles.join(QLatin1Char(',')) + QLatin1Char(';')
           + elements.join(QLatin1Char(','));
}

bool Historique::valider()
{
    if (m_gele)
        return false;
    PhotoEtat photo = m_hote->photoEtat();
    if (signature(photo) == signature(m_courant))
        return false;
    m_passe.append(m_courant);
    while (m_passe.size() > PROFONDEUR)
        m_passe.removeFirst();
    m_futur.clear();
    m_courant = photo;
    return true;
}

bool Historique::annuler()
{
    if (m_passe.isEmpty())
        return false;
    m_futur.append(m_courant);
    m_courant = m_passe.takeLast();
    appliquer(m_courant);
    return true;
}

bool Historique::retablir()
{
    if (m_futur.isEmpty())
        return false;
    m_passe.append(m_courant);
    m_courant = m_futur.takeLast();
    appliquer(m_courant);
    return true;
}

void Historique::oublier()
{
    m_passe.clear();
    m_futur.clear();
    m_courant = m_hote->photoEtat();
}

void Historique::appliquer(const PhotoEtat &photo)
{
    // Le gel évite que la reconstruction de la scène ne s'enregistre elle-même
    // comme une action de plus.
    m_gele = true;
    m_hote->restaurerEtat(photo);
    m_gele = false;
}
