#include "graphics_items.h"

#include "config.h"
#include "theme.h"

#include <QBrush>
#include <QCursor>
#include <QFont>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsSimpleTextItem>
#include <QLinearGradient>
#include <QPainter>
#include <QPen>
#include <QPrinter>
#include <QRadialGradient>
#include <QStyleOptionGraphicsItem>

bool RenduRapide::actif = false;

namespace {

// Paliers de définition de la copie d'écran, en pixels de largeur.
const int PALIERS_HD[] = {384, 512, 768, 1024, 1536, 2048};
constexpr int PALIER_HD_MAX = 2048;

// Profil du fondu de l'ombre : décroissance douce puis longue traîne.
const double OMBRE_PROFIL[][2] = {{0.0, 1.0}, {0.18, 0.82}, {0.38, 0.54},
                                   {0.62, 0.28}, {0.82, 0.11}, {1.0, 0.0}};

void garnirStops(QGradient &g, int alpha)
{
    for (const auto &s : OMBRE_PROFIL)
        g.setColorAt(s[0], QColor(0, 0, 0, int(alpha * s[1])));
}

} // namespace

bool estImprimante(QPainter *painter)
{
    return painter && dynamic_cast<QPrinter *>(painter->device()) != nullptr;
}

void peindreOmbreDouce(QPainter *painter, const QRectF &rect, double etalement, double decalage,
                       int alpha)
{
    const QRectF r = rect.translated(0.0, decalage);
    const double E = etalement;
    painter->save();
    painter->setPen(Qt::NoPen);

    // Cœur : la bande du décalage sous le bord bas doit être pleine.
    painter->fillRect(r, QColor(0, 0, 0, alpha));

    QLinearGradient g1(0, r.top(), 0, r.top() - E);
    garnirStops(g1, alpha);
    painter->fillRect(QRectF(r.left(), r.top() - E, r.width(), E), g1);

    QLinearGradient g2(0, r.bottom(), 0, r.bottom() + E);
    garnirStops(g2, alpha);
    painter->fillRect(QRectF(r.left(), r.bottom(), r.width(), E), g2);

    QLinearGradient g3(r.left(), 0, r.left() - E, 0);
    garnirStops(g3, alpha);
    painter->fillRect(QRectF(r.left() - E, r.top(), E, r.height()), g3);

    QLinearGradient g4(r.right(), 0, r.right() + E, 0);
    garnirStops(g4, alpha);
    painter->fillRect(QRectF(r.right(), r.top(), E, r.height()), g4);

    const double coins[4][4] = {
        {r.left(), r.top(), r.left() - E, r.top() - E},
        {r.right(), r.top(), r.right(), r.top() - E},
        {r.left(), r.bottom(), r.left() - E, r.bottom()},
        {r.right(), r.bottom(), r.right(), r.bottom()},
    };
    for (const auto &c : coins) {
        QRadialGradient g(c[0], c[1], E);
        garnirStops(g, alpha);
        painter->fillRect(QRectF(c[2], c[3], E, E), g);
    }
    painter->restore();
}

// ===========================================================================
// HandleItem
// ===========================================================================
HandleItem::HandleItem(const QString &cle, ResizablePixmapItem *parent)
    : QGraphicsRectItem(-6, -6, 12, 12, parent), m_cle(cle), m_parent(parent)
{
    setBrush(QBrush(QColor(theme::FG)));
    setPen(QPen(QColor(theme::ACCENT), 2));
    setFlags(QGraphicsItem::ItemIsMovable);
    Qt::CursorShape forme = Qt::ArrowCursor;
    if (cle == QLatin1String("top_left") || cle == QLatin1String("bottom_right"))
        forme = Qt::SizeFDiagCursor;
    else if (cle == QLatin1String("top_right") || cle == QLatin1String("bottom_left"))
        forme = Qt::SizeBDiagCursor;
    else if (cle == QLatin1String("top") || cle == QLatin1String("bottom"))
        forme = Qt::SizeVerCursor;
    else if (cle == QLatin1String("left") || cle == QLatin1String("right"))
        forme = Qt::SizeHorCursor;
    setCursor(forme);
}

void HandleItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    // La copie de travail se fabrique à l'appui, où le temps ne se voit pas.
    if (m_parent)
        m_parent->preparerManipulation();
    RenduRapide::actif = true;
    QGraphicsRectItem::mousePressEvent(event);
}

void HandleItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    if (m_parent)
        m_parent->handleMove(m_cle, mapToParent(event->pos()));
}

void HandleItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    RenduRapide::actif = false;
    if (m_parent)
        m_parent->finRedimension();
    QGraphicsRectItem::mouseReleaseEvent(event);
}

void HandleItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    if (estImprimante(painter))
        return;
    // Les poignées portent la couleur du cadre de leur page.
    if (m_parent && m_parent->fraichementColle) {
        painter->setPen(QPen(QColor(COULEUR_COLLE), 2));
        painter->setBrush(brush());
        painter->drawRect(rect());
        return;
    }
    if (m_parent && m_parent->isSelected()) {
        painter->setPen(QPen(QColor(COULEUR_CHOISIE), 2));
        painter->setBrush(QBrush(QColor(COULEUR_CHOISIE)));
        painter->drawRect(rect());
        return;
    }
    QStyleOptionGraphicsItem opt(*option);
    opt.state &= ~QStyle::State_Selected;
    QGraphicsRectItem::paint(painter, &opt, widget);
}

// ===========================================================================
// PaperItem
// ===========================================================================
PaperItem::PaperItem(double w, double h, int index) : QGraphicsRectItem(0, 0, w, h), m_index(index)
{
    setPen(QPen(QColor(theme::BORDER_COL), 1));
    setZValue(-1);
    // Étiquette « Page n » au-dessus du rectangle : jamais imprimée.
    m_label = new QGraphicsSimpleTextItem(QString(), this);
    QFont font;
    font.setPointSize(9);
    font.setBold(true);
    m_label->setFont(font);
    m_label->setBrush(QBrush(QColor(theme::ACCENT)));
    m_label->setPos(0, -20);
    setIndex(index);
}

void PaperItem::setIndex(int index)
{
    m_index = index;
    m_label->setText(QStringLiteral("Page %1").arg(index + 1));
}

void PaperItem::marquerDeplacement(bool valeur)
{
    if (m_enDeplacement != valeur) {
        m_enDeplacement = valeur;
        update();
    }
}

QRectF PaperItem::boundingRect() const
{
    // Étendu de la portée de l'ombre, pour que le halo soit repeint aussi.
    const double m = OMBRE_ETALEMENT + OMBRE_DECALAGE;
    return QGraphicsRectItem::boundingRect().adjusted(-m, -m, m, m);
}

void PaperItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (estImprimante(painter)) {
        painter->setPen(Qt::NoPen);
        painter->setBrush(QColor(QStringLiteral("#ffffff")));
        painter->drawRect(rect());
        return;
    }
    peindreOmbreDouce(painter, rect());
    painter->setPen(pen());
    painter->setBrush(QColor(config::lireTexte(QStringLiteral("paper_bg"), QStringLiteral("#e8e8e8"))));
    painter->drawRect(rect());
    if (m_enDeplacement) {
        painter->setBrush(QColor(255, 59, 48, 80));
        QPen stylo(QColor(COULEUR_COLLE), 3);
        stylo.setCosmetic(true);
        painter->setPen(stylo);
        painter->drawRect(rect());
    }
}

// ===========================================================================
// ResizablePixmapItem
// ===========================================================================
ResizablePixmapItem::ResizablePixmapItem(const QPixmap &pixmap) : QGraphicsPixmapItem(pixmap)
{
    setFlags(QGraphicsItem::ItemIsMovable | QGraphicsItem::ItemIsSelectable);
    setTransformationMode(Qt::SmoothTransformation);
    // La croix à quatre flèches : l'élément se prend et se déplace.
    setCursor(Qt::SizeAllCursor);
    originalPixmap = pixmap;
    // Provenance retrouvée seule, par la clé de cache de l'image.
    origine = origines::lire(pixmap);
    rectAffiche = QRectF(0, 0, pixmap.width(), pixmap.height());
    for (const char *cle : {"top_left", "top", "top_right", "left", "right", "bottom_left",
                            "bottom", "bottom_right"})
        m_handles.insert(QString::fromLatin1(cle), new HandleItem(QString::fromLatin1(cle), this));
    updateHandlesPos();
}

QPixmap ResizablePixmapItem::fabriquerApercu(const QPixmap &pixmap)
{
    if (pixmap.isNull())
        return pixmap;
    const int cote = qMax(pixmap.width(), pixmap.height());
    if (cote <= config::PREVIEW_MAX_SIDE)
        return pixmap;
    return pixmap.scaled(config::PREVIEW_MAX_SIDE, config::PREVIEW_MAX_SIDE, Qt::KeepAspectRatio,
                         Qt::SmoothTransformation);
}

QPixmap ResizablePixmapItem::apercu()
{
    if (m_apercuCache.isNull())
        m_apercuCache = fabriquerApercu(originalPixmap);
    return m_apercuCache;
}

void ResizablePixmapItem::setDisplaySize(int maxW, int maxH)
{
    const QPixmap source = m_apercuCache.isNull() ? originalPixmap : m_apercuCache;
    const QPixmap scaled = source.scaled(qMax(1, maxW), qMax(1, maxH), Qt::KeepAspectRatio,
                                         Qt::SmoothTransformation);
    rectAffiche = QRectF(0, 0, scaled.width(), scaled.height());
    setPixmap(scaled);
    updateHandlesPos();
}

void ResizablePixmapItem::poserTaille(int w, int h)
{
    const QPixmap scaled = apercu().scaled(qMax(1, w), qMax(1, h), Qt::IgnoreAspectRatio,
                                           Qt::SmoothTransformation);
    setPixmap(scaled);
    rectAffiche = QRectF(0, 0, scaled.width(), scaled.height());
    updateHandlesPos();
}

QPixmap ResizablePixmapItem::sourceEcran(double largeurVisee)
{
    const QPixmap &orig = originalPixmap;
    const int ow = orig.width();
    // Au-delà du dernier palier, l'original est la bonne source.
    if (largeurVisee >= qMin(ow, PALIER_HD_MAX))
        return orig;
    int palier = ow;
    for (int p : PALIERS_HD)
        if (p >= largeurVisee) {
            palier = p;
            break;
        }
    palier = qMin(palier, ow);
    if (!m_hdPixmap.isNull() && m_hdPalier == palier)
        return m_hdPixmap;
    if (RenduRapide::actif)
        return m_hdPixmap; // pendant le mouvement on ne fabrique rien
    m_hdPixmap = orig.scaledToWidth(palier, Qt::SmoothTransformation);
    m_hdPalier = palier;
    return m_hdPixmap;
}

void ResizablePixmapItem::libererCacheEcran()
{
    m_hdPixmap = QPixmap();
    m_hdPalier = 0;
}

void ResizablePixmapItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option,
                                QWidget *widget)
{
    const QRectF cible(0, 0, rectAffiche.width(), rectAffiche.height());
    const QPixmap &src = originalPixmap;
    if (src.isNull() || cible.isEmpty()) {
        QGraphicsPixmapItem::paint(painter, option, widget);
        return;
    }

    // À l'impression : toujours l'original, avec lissage.
    if (estImprimante(painter)) {
        painter->save();
        painter->setRenderHint(QPainter::SmoothPixmapTransform, true);
        painter->drawPixmap(cible, src, QRectF(src.rect()));
        painter->restore();
        return;
    }

    const double largeurEcran = qAbs(painter->transform().mapRect(cible).width());
    const QPixmap vignette = pixmap();
    QPixmap source = vignette;
    if (largeurEcran > vignette.width() + 1) {
        const QPixmap hd = sourceEcran(largeurEcran);
        if (!hd.isNull() && hd.width() > vignette.width())
            source = hd;
    }

    painter->save();
    painter->setRenderHint(QPainter::SmoothPixmapTransform, !RenduRapide::actif);
    painter->drawPixmap(cible, source, QRectF(source.rect()));
    painter->restore();

    if (option && (option->state & QStyle::State_Selected)) {
        painter->save();
        // Un seul cadre pour les deux états : rouge collé, violet choisi.
        QPen stylo(QColor(fraichementColle ? COULEUR_COLLE : COULEUR_CHOISIE), 3, Qt::SolidLine);
        stylo.setCosmetic(true);
        painter->setPen(stylo);
        painter->setBrush(Qt::NoBrush);
        painter->drawRect(cible);
        painter->restore();
    }
}

QVariant ResizablePixmapItem::itemChange(GraphicsItemChange change, const QVariant &value)
{
    if (change == QGraphicsItem::ItemSelectedHasChanged)
        for (HandleItem *h : std::as_const(m_handles))
            h->update();
    return QGraphicsPixmapItem::itemChange(change, value);
}

void ResizablePixmapItem::marquerColle(bool valeur)
{
    if (fraichementColle == valeur)
        return;
    fraichementColle = valeur;
    update();
    for (HandleItem *h : std::as_const(m_handles))
        h->update();
}

void ResizablePixmapItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    marquerColle(false);
    QGraphicsPixmapItem::mouseMoveEvent(event);
}

void ResizablePixmapItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    marquerColle(false);
    QGraphicsPixmapItem::mousePressEvent(event);
}

void ResizablePixmapItem::updateHandlesPos()
{
    const QRectF r = rectAffiche;
    m_handles[QStringLiteral("top_left")]->setPos(r.left(), r.top());
    m_handles[QStringLiteral("top")]->setPos(r.center().x(), r.top());
    m_handles[QStringLiteral("top_right")]->setPos(r.right(), r.top());
    m_handles[QStringLiteral("left")]->setPos(r.left(), r.center().y());
    m_handles[QStringLiteral("right")]->setPos(r.right(), r.center().y());
    m_handles[QStringLiteral("bottom_left")]->setPos(r.left(), r.bottom());
    m_handles[QStringLiteral("bottom")]->setPos(r.center().x(), r.bottom());
    m_handles[QStringLiteral("bottom_right")]->setPos(r.right(), r.bottom());
}

void ResizablePixmapItem::handleMove(const QString &cle, const QPointF &souris)
{
    marquerColle(false);
    QRectF nr = rectAffiche;
    if (cle.contains(QLatin1String("left")))
        nr.setLeft(souris.x());
    if (cle.contains(QLatin1String("right")))
        nr.setRight(souris.x());
    if (cle.contains(QLatin1String("top")))
        nr.setTop(souris.y());
    if (cle.contains(QLatin1String("bottom")))
        nr.setBottom(souris.y());
    if (nr.width() < 20 || nr.height() < 20)
        return;
    const bool coin = cle == QLatin1String("top_left") || cle == QLatin1String("top_right")
                      || cle == QLatin1String("bottom_left") || cle == QLatin1String("bottom_right");
    if (coin && originalPixmap.width() > 0) {
        const double ratio = double(originalPixmap.height()) / originalPixmap.width();
        const double nh = nr.width() * ratio;
        if (cle.contains(QLatin1String("top")))
            nr.setTop(nr.bottom() - nh);
        else
            nr.setBottom(nr.top() + nh);
    }
    setPos(mapToParent(nr.topLeft()));
    // Pendant le glissé : mise à l'échelle rapide ; le lissage au relâchement.
    const Qt::TransformationMode mode = RenduRapide::actif ? Qt::FastTransformation
                                                           : Qt::SmoothTransformation;
    const QPixmap scaled = apercu().scaled(qMax(1, int(nr.width())), qMax(1, int(nr.height())),
                                           Qt::IgnoreAspectRatio, mode);
    rectAffiche = QRectF(0, 0, scaled.width(), scaled.height());
    setPixmap(scaled);
    updateHandlesPos();
}

void ResizablePixmapItem::finRedimension()
{
    const int w = qMax(1, int(rectAffiche.width()));
    const int h = qMax(1, int(rectAffiche.height()));
    const QPixmap scaled = apercu().scaled(w, h, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    rectAffiche = QRectF(0, 0, scaled.width(), scaled.height());
    setPixmap(scaled);
    updateHandlesPos();
    update();
}
