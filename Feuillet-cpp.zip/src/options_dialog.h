// options_dialog — les Options : Chemins, Interface, Qualité, Driver.
#pragma once

#include <QColor>
#include <QDialog>
#include <QHash>
#include <QMap>
#include <functional>
#include <memory>

class QButtonGroup;
class QCheckBox;
class QComboBox;
class QFontComboBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QRadioButton;
class QSpinBox;
class QVBoxLayout;

class ApercuDegrade : public QWidget {
    Q_OBJECT
public:
    static constexpr int HAUTEUR = 46;
    explicit ApercuDegrade(QWidget *parent = nullptr);
    void regler(const QColor &c1, const QColor &c2, const QString &sens);

protected:
    void paintEvent(QPaintEvent *e) override;

private:
    QColor m_c1{Qt::black}, m_c2{Qt::black};
    bool m_horizontal = false;
};

class OptionsDialog : public QDialog {
    Q_OBJECT
public:
    explicit OptionsDialog(QWidget *parent = nullptr);

private:
    // Une pastille de couleur, son code et un bouton de remise à zéro.
    std::shared_ptr<QColor> rangeeCouleur(QVBoxLayout *cible, const QString &titre, const QString &aide,
                                          const QString &courante, const QString &defaut, bool avecTitre = true);
    void rafraichirApercuMsg();
    void rafraichirEtatDriver();
    void installerDriver();
    void desinstallerDriver();
    void parcourirReferent();
    void parcourirLecteurPdf();
    QString depart(const QString &nomPropose = QString()) const;
    int dpiChoisi() const;
    QString valeurFond() const;
    void enregistrerEtFermer();
    void exporterConfig();
    void importerConfig();
    void majDegrade();

    QLineEdit *m_referent;
    QLineEdit *m_lecteurPdf;
    QCheckBox *m_ouvrirPdf;

    QButtonGroup *m_groupeFond;
    QMap<QString, QRadioButton *> m_radiosFond;
    QMap<QString, QWidget *> m_boitesFond;
    std::shared_ptr<QColor> m_sceneBg;
    std::shared_ptr<QColor> m_deg1, m_deg2;
    QComboBox *m_sens;
    ApercuDegrade *m_apercuDeg;
    QLineEdit *m_bgImage;
    QComboBox *m_bgMode;
    std::shared_ptr<QColor> m_paperBg;
    std::shared_ptr<QColor> m_titlebar;
    QFontComboBox *m_msgFont;
    QSpinBox *m_msgSize;
    std::shared_ptr<QColor> m_msgColor;
    QLabel *m_apercuMsg = nullptr;
    QHash<const QColor *, std::function<void()>> m_peintres;

    QComboBox *m_dpi;
    QList<QPair<QString, int>> m_choixDpi;

    QCheckBox *m_drvRogner;
    QLabel *m_etatDriver;
    QPushButton *m_btnInstaller;
    QPushButton *m_btnDesinstaller;
};
