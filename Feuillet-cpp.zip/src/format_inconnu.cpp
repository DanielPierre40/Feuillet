#include "format_inconnu.h"

#include "apparence.h"
#include "barre_titre.h"
#include "driver_feuillet.h"
#include "theme.h"
#include "ui_helpers.h"

#include <QApplication>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>

namespace {
const QString BORDEAUX = QStringLiteral("#800020");
const QString BORDEAUX_HOV = QStringLiteral("#9c0028");
const QString BORDEAUX_PRS = QStringLiteral("#5e0018");
const QString BLEU = QStringLiteral("#1f3a6e");
const QString BLEU_HOV = QStringLiteral("#2a4c8c");
const QString BLEU_PRS = QStringLiteral("#16294e");

const QString TEXTE_BASE = QStringLiteral(
    "Désolé, Feuillet ne connait pas ce format de fichier, mais rien n'est perdu.\n\n"
    "Ouvrez le programme qui lit ce fichier et imprimez avec l'imprimante virtuelle Feuillet.");
const QString TEXTE_SANS_IMPRIMANTE = TEXTE_BASE + QStringLiteral(
    "\n\nAvant toute chose, installez cette imprimante en cliquant sur le bouton ci-dessous.");
} // namespace

FormatInconnuDialog::FormatInconnuDialog(QWidget *parent) : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Feuillet"));
    setModal(true);
    const apparence::PoliceMessages p = apparence::policeMessages();
    m_famille = p.famille;
    m_taille = p.taille;
    // La largeur suit la police, et elle est fixée d'emblée : la hauteur du
    // texte replié en dépend.
    m_largeur = LARGEUR + qMax(0, m_taille - 10) * 30;
    setFixedWidth(m_largeur);

    auto *root = new QVBoxLayout(this);
    root->setContentsMargins(28, 24, 28, 22);
    root->setSpacing(0);

    auto *titre = new QLabel(QStringLiteral("📄   Format inconnu"));
    titre->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: %3pt;"
                                        "font-weight: 600; background: transparent;")
                             .arg(theme::FG, m_famille)
                             .arg(m_taille + 4));
    root->addWidget(titre);

    auto *sep = new QWidget();
    sep->setFixedHeight(1);
    sep->setStyleSheet(QStringLiteral("background: %1;").arg(theme::BORDER_COL));
    root->addSpacing(14);
    root->addWidget(sep);
    root->addSpacing(18);

    m_mot = new QLabel();
    m_mot->setWordWrap(true);
    m_mot->setFixedWidth(m_largeur - MARGES);
    m_mot->setStyleSheet(QStringLiteral("color: %1; font-family: '%2'; font-size: %3pt;"
                                        "background: transparent;")
                             .arg(p.couleur, m_famille)
                             .arg(m_taille));
    root->addWidget(m_mot);
    root->addSpacing(22);

    auto *rangee = new QHBoxLayout();
    rangee->setSpacing(12);
    m_btnInstaller = bouton(QStringLiteral("🖨   Installer l'imprimante"), BORDEAUX, BORDEAUX_HOV, BORDEAUX_PRS);
    connect(m_btnInstaller, &QPushButton::clicked, this, &FormatInconnuDialog::installerImprimante);
    m_btnAnnuler = bouton(QStringLiteral("Retour"), BLEU, BLEU_HOV, BLEU_PRS);
    connect(m_btnAnnuler, &QPushButton::clicked, this, &QDialog::reject);
    rangee->addWidget(m_btnInstaller);
    rangee->addStretch();
    rangee->addWidget(m_btnAnnuler);
    root->addLayout(rangee);

    m_btnAnnuler->setDefault(true);
    rafraichir();
    cadre::poserCadre(this, false, false);
}

QPushButton *FormatInconnuDialog::bouton(const QString &texte, const QString &fond, const QString &survol,
                                         const QString &appui)
{
    auto *btn = new QPushButton(texte);
    btn->setMinimumHeight(int(m_taille * 3.8));
    btn->setMinimumWidth(int(m_taille * 19));
    btn->setCursor(Qt::PointingHandCursor);
    btn->setStyleSheet(QStringLiteral("QPushButton { background: %1; color: #f0f2f8;"
                                      "  border: 1px solid %1; border-radius: 3px;"
                                      "  padding: 6px 18px;"
                                      "  font-family: '%2';"
                                      "  font-size: %3pt; font-weight: 600; }"
                                      "QPushButton:hover { background: %4; border-color: %5; }"
                                      "QPushButton:pressed { background: %6; }"
                                      "QPushButton:disabled { background: %7; color: %8;"
                                      "  border-color: %9; }")
                           .arg(fond, m_famille)
                           .arg(qMax(8, m_taille - 1))
                           .arg(survol, theme::ACCENT, appui, theme::BG_BTN_HOV, theme::FG2, theme::BORDER_COL));
    ui::addShadow(btn);
    return btn;
}

void FormatInconnuDialog::rafraichir()
{
    const bool presente = driver::imprimanteInstallee();
    m_mot->setText(presente ? TEXTE_BASE : TEXTE_SANS_IMPRIMANTE);
    m_mot->setFixedHeight(m_mot->heightForWidth(m_largeur - MARGES) + 4);
    m_btnInstaller->setEnabled(!presente);
    adjustSize();
}

void FormatInconnuDialog::installerImprimante()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const driver::Resultat r = driver::installer();
    QApplication::restoreOverrideCursor();
    if (r.ok)
        QMessageBox::information(this, QStringLiteral("Driver Feuillet"), r.message);
    else
        QMessageBox::critical(this, QStringLiteral("Driver Feuillet"), r.message);
    // C'est la présence de l'imprimante qui commande, pas le code de retour.
    rafraichir();
}
