// config — la configuration de Feuillet.
//
// Le fichier est le MÊME que celui de la version Python :
// ~/.feuillet_config.json. Les réglages déjà faits sont donc repris tels
// quels, et les deux versions peuvent cohabiter.
//
// Le chargement des fichiers tourne dans un fil séparé, qui peut lui aussi
// lire et écrire la configuration (chemins des convertisseurs) : tout accès
// passe donc par un verrou.
#pragma once

#include <QJsonObject>
#include <QJsonValue>
#include <QString>

namespace config {

// Résolution de rendu par défaut (points par pouce) des documents.
constexpr int DEFAULT_RENDER_DPI = 300;
constexpr int MIN_RENDER_DPI = 96;
constexpr int MAX_RENDER_DPI = 600;

// Garde-fous mémoire (voir la version Python pour le détail).
constexpr qint64 MAX_RENDER_PIXELS   = 40000000;
constexpr qint64 MAX_DOCUMENT_PIXELS = 160000000;

// Côté le plus long de la copie de travail des manipulations à la souris.
constexpr int PREVIEW_MAX_SIDE = 1600;

// Les quatre sortes d'arrière-plan du bureau de l'Atelier.
inline const QString FOND_INTEGRE = QStringLiteral("integre");
inline const QString FOND_COULEUR = QStringLiteral("couleur");
inline const QString FOND_DEGRADE = QStringLiteral("degrade");
inline const QString FOND_FICHIER = QStringLiteral("fichier");

inline const QString SCENE_BG2 = QStringLiteral("#000000");

QString cheminFichier();

// Accès élémentaires, protégés par le verrou.
QJsonValue lire(const QString &cle, const QJsonValue &defaut = QJsonValue());
QString lireTexte(const QString &cle, const QString &defaut = QString());
bool lireBool(const QString &cle, bool defaut);
void poser(const QString &cle, const QJsonValue &valeur);
void retirer(const QString &cle);
QJsonObject tout();
void remplacer(const QJsonObject &cfg);
// Écrit le fichier (écriture atomique). Rend false en cas d'échec.
bool enregistrer();

// Accesseurs repris de config.py
int renderDpi();
bool driverRognerBlanc();
QString sourceFond();
QString dossierReferent();
QString lecteurPdf();
bool ouvrirPdfApres();
QString departFichier(const QString &nomPropose = QString());
QJsonObject agencementBarres();
void setAgencementBarres(const QJsonObject &agencement);

} // namespace config
