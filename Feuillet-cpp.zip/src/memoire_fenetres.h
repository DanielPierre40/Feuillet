// memoire_fenetres — taille et position des fenêtres, retrouvées d'une fois
// sur l'autre. Une ligne par fenêtre, après poserCadre :
//
//     memoire::retenir(this, "accueil");
//
// Fiches rangées sous la clé « fenetres » de la configuration (x, y, l, h,
// max), écrites une seule fois quand la fenêtre se cache.
#pragma once

#include <QString>

class QWidget;

namespace memoire {

// Rend true si une géométrie retenue a bien été rejouée.
bool retenir(QWidget *fenetre, const QString &nom);

} // namespace memoire
