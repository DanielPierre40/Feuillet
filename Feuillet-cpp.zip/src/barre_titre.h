// barre_titre — la barre du haut, dessinée par Feuillet et non par Windows,
// le cadre arrondi cerné de gris, l'ombre douce et la poignée de taille.
//
// Une fenêtre sans cadre perd tout ce que le cadre rendait : déplacement,
// redimensionnement par les bords, réduire / agrandir, ombre. Ce module remet
// les quatre.
#pragma once

#include <QColor>
#include <QRegion>
#include <QString>
#include <QWidget>

class QLabel;
class QPushButton;
class QVBoxLayout;

namespace cadre {

constexpr int BORD = 5;           // marge de préhension tout autour
constexpr int HAUTEUR = 34;       // hauteur de la barre
inline const QString ROUGE_FERMER = QStringLiteral("#c42b1c");
inline const QString LISERE = QStringLiteral("#8a8a96"); // gris moyen
constexpr int RAYON = 10;         // coins arrondis
constexpr int OMBRE_PORTEE = 14;
constexpr int OMBRE_CHUTE = 3;
constexpr int OMBRE_NOIR = 30;
constexpr int MARGE_CADRE = OMBRE_PORTEE + OMBRE_CHUTE;

QRegion regionArrondie(const QRect &rect, int rayon);

} // namespace cadre

class BarreTitre : public QWidget {
    Q_OBJECT
public:
    BarreTitre(QWidget *fenetre, bool reduire = true, bool agrandir = true, int arrondi = 0);
    void recolorer();
    void basculer();

protected:
    void mousePressEvent(QMouseEvent *e) override;
    void mouseMoveEvent(QMouseEvent *e) override;
    void mouseReleaseEvent(QMouseEvent *e) override;
    void mouseDoubleClickEvent(QMouseEvent *e) override;

private:
    struct Bouton {
        QPushButton *btn;
        bool rouge;
    };
    static void habiller(QPushButton *btn, const QString &fond, const QString &encre, bool rouge,
                         int coin = 0);
    QPushButton *bouton(const QString &glyphe, const QString &fond, const QString &encre,
                        bool rouge = false);
    void arrondirDernier(const QString &fond, const QString &encre);
    void peindreFond(const QString &fond);
    void marges();

    QWidget *m_fenetre;
    bool m_presse = false;
    QPoint m_depart;
    int m_arrondi;
    QList<Bouton> m_boutons;
    QLabel *m_icone;
    QLabel *m_titre;
    QPushButton *m_btnAgrandir = nullptr;
};

class PoigneeTaille : public QWidget {
    Q_OBJECT
public:
    static constexpr int COTE = 16;
    static constexpr int MARGE = 3;
    PoigneeTaille(QWidget *fenetre, QWidget *hote);
    void replacer();

protected:
    bool eventFilter(QObject *objet, QEvent *e) override;
    void paintEvent(QPaintEvent *e) override;
    void mousePressEvent(QMouseEvent *e) override;
    void mouseMoveEvent(QMouseEvent *e) override;
    void mouseReleaseEvent(QMouseEvent *e) override;

private:
    QWidget *m_fenetre;
    bool m_tire = false;
    QPoint m_origine;
    QRect m_geo;
};

namespace cadre {

// Retire le cadre de Windows et pose la barre de Feuillet. `gabarit` désigne,
// quand on le donne, la colonne qui doit recevoir la barre.
bool poser(QWidget *fenetre, bool reduire = true, bool agrandir = true,
           QVBoxLayout *gabarit = nullptr, int arrondi = 0);

// Cadre arrondi cerné de gris, ombre douce et barre de titre comprises.
// Rend false si la fenêtre n'a pas le gabarit attendu (une colonne).
bool poserCadre(QWidget *fenetre, bool reduire = true, bool agrandir = true,
                const QString &fond = QString(), int rayon = RAYON, int marge = MARGE_CADRE,
                bool ombre = true);

PoigneeTaille *poserPoignee(QWidget *fenetre);

void recolorerTout();

BarreTitre *barreDe(QWidget *fenetre);
QWidget *contenuDe(QWidget *fenetre);   // le contenu du cadre arrondi, ou nullptr
QWidget *cadreDe(QWidget *fenetre);
int margeCadre(QWidget *fenetre);

} // namespace cadre
