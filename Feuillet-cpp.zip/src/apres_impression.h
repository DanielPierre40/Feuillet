// apres_impression — la fenêtre à portes de sortie : après une impression,
// avant de quitter l'Atelier, et pour choisir la destination (PDF ou
// imprimante). Le dialogue ne fait que RETOURNER le choix.
#pragma once

#include <QDialog>
#include <QList>

class QVBoxLayout;

class ApresImpressionDialog : public QDialog {
    Q_OBJECT
public:
    enum Choix {
        SAUVER = 1,     // sauvegarder le feuillet, puis quitter
        NOUVEAU = 2,    // nouveau travail : retour à l'accueil
        QUITTER = 3,    // quitter tout de suite
        ANNULER = 4,    // ne rien faire : on reste où l'on est
        PDF = 5,        // sortir un fichier PDF
        IMPRIMANTE = 6, // passer par les imprimantes de l'ordinateur
        REVENIR = 7,    // retour à l'Atelier, mise en page intacte
    };

    struct Porte {
        QString texte;
        QString explication;
        int choix;
        bool principale;
    };

    static QList<Porte> portesImpression();

    explicit ApresImpressionDialog(QWidget *parent = nullptr,
                                   const QString &titreFenetre = QStringLiteral("Impression lancée"),
                                   const QString &titre = QStringLiteral("🖨️   Impression lancée"),
                                   const QString &sousTitre = QStringLiteral("Que faire maintenant ?"),
                                   const QList<Porte> &portes = portesImpression(), int defaut = NOUVEAU);
    int demander();

private:
    void ajouterBouton(QVBoxLayout *layout, const Porte &porte, bool dernier);
    int m_choix;
};

// Où doivent aller les pages : PDF, IMPRIMANTE, ou ANNULER.
int demanderDestination(QWidget *parent = nullptr);
// SAUVER, QUITTER ou ANNULER.
int demanderAvantDeQuitter(QWidget *parent = nullptr);
