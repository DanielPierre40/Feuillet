#include "lecteurs_images.h"

#include <QFile>
#include <QSet>
#include <QtEndian>

#include <cmath>
#include <cstring>
#include <vector>

#ifdef FEUILLET_LIBRAW
#include <libraw/libraw.h>
#endif

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <objbase.h>
#include <wincodec.h>
#endif

namespace lecteurs {

// ===========================================================================
// PSD / PSB — l'image composite
// ===========================================================================
namespace {

class Lecteur {
public:
    explicit Lecteur(const QByteArray &d) : m_d(d) {}
    bool reste(qint64 n) const { return m_pos + n <= m_d.size(); }
    quint8 u8() { return reste(1) ? quint8(m_d[int(m_pos++)]) : 0; }
    quint16 u16()
    {
        if (!reste(2)) { m_pos = m_d.size(); return 0; }
        const quint16 v = qFromBigEndian<quint16>(m_d.constData() + m_pos);
        m_pos += 2;
        return v;
    }
    quint32 u32()
    {
        if (!reste(4)) { m_pos = m_d.size(); return 0; }
        const quint32 v = qFromBigEndian<quint32>(m_d.constData() + m_pos);
        m_pos += 4;
        return v;
    }
    quint64 u64()
    {
        const quint64 h = u32();
        return (h << 32) | u32();
    }
    void sauter(qint64 n) { m_pos = qMin<qint64>(m_pos + n, m_d.size()); }
    qint64 pos() const { return m_pos; }
    const char *ici() const { return m_d.constData() + m_pos; }
    qint64 taille() const { return m_d.size(); }

private:
    const QByteArray &m_d;
    qint64 m_pos = 0;
};

// Décompression PackBits d'une rangée.
bool packbits(const char *src, qint64 n, quint8 *dst, qint64 attendu)
{
    qint64 i = 0, o = 0;
    while (i < n && o < attendu) {
        const int c = qint8(src[i++]);
        if (c >= 0) {
            const int compte = c + 1;
            for (int k = 0; k < compte && i < n && o < attendu; ++k)
                dst[o++] = quint8(src[i++]);
        } else if (c != -128) {
            const int compte = 1 - c;
            if (i >= n)
                break;
            const quint8 v = quint8(src[i++]);
            for (int k = 0; k < compte && o < attendu; ++k)
                dst[o++] = v;
        }
    }
    while (o < attendu)
        dst[o++] = 0;
    return true;
}

inline quint8 versOctet(const quint8 *plan, qint64 index, int profondeur)
{
    switch (profondeur) {
    case 8:
        return plan[index];
    case 16:
        return plan[index * 2]; // octet de poids fort
    case 32: {
        const quint32 bits = qFromBigEndian<quint32>(plan + index * 4);
        float f;
        std::memcpy(&f, &bits, 4);
        return quint8(qBound(0.0f, f, 1.0f) * 255.0f + 0.5f);
    }
    default:
        return 0;
    }
}

double labF(double t)
{
    return t > 6.0 / 29.0 ? t * t * t : 3.0 * (6.0 / 29.0) * (6.0 / 29.0) * (t - 4.0 / 29.0);
}

quint8 srgb(double c)
{
    c = qBound(0.0, c, 1.0);
    c = c <= 0.0031308 ? 12.92 * c : 1.055 * std::pow(c, 1.0 / 2.4) - 0.055;
    return quint8(qBound(0.0, c * 255.0 + 0.5, 255.0));
}

} // namespace

QImage lirePsd(const QString &chemin)
{
    QFile f(chemin);
    if (!f.open(QIODevice::ReadOnly))
        return QImage();
    const QByteArray d = f.readAll();
    Lecteur r(d);
    if (d.size() < 26 || d.left(4) != "8BPS")
        return QImage();
    r.sauter(4);
    const int version = r.u16();
    if (version != 1 && version != 2)
        return QImage();
    const bool psb = version == 2;
    r.sauter(6);
    const int canaux = r.u16();
    const int hauteur = int(r.u32());
    const int largeur = int(r.u32());
    const int profondeur = r.u16();
    const int mode = r.u16();
    if (canaux < 1 || largeur <= 0 || hauteur <= 0 || largeur > 300000 || hauteur > 300000)
        return QImage();
    if (profondeur != 1 && profondeur != 8 && profondeur != 16 && profondeur != 32)
        return QImage();

    // Données de mode couleur (palette des images indexées).
    const quint32 lgMode = r.u32();
    QByteArray palette;
    if (lgMode >= 768 && r.reste(768))
        palette = QByteArray(r.ici(), 768);
    r.sauter(lgMode);
    r.sauter(r.u32());                            // ressources d'image
    r.sauter(psb ? qint64(r.u64()) : qint64(r.u32())); // calques et masques
    if (!r.reste(2))
        return QImage();
    const int compression = r.u16();

    const qint64 octetsRangee = profondeur == 1 ? (largeur + 7) / 8 : qint64(largeur) * (profondeur / 8);
    const qint64 taillePlan = octetsRangee * hauteur;
    const qint64 total = taillePlan * canaux;
    if (total <= 0 || total > qint64(4) * 1024 * 1024 * 1024)
        return QImage();
    std::vector<quint8> plans(static_cast<size_t>(total), 0);

    if (compression == 0) {
        const qint64 n = qMin(total, r.taille() - r.pos());
        std::memcpy(plans.data(), r.ici(), size_t(qMax<qint64>(0, n)));
    } else if (compression == 1) {
        const int nbRangees = hauteur * canaux;
        std::vector<quint32> comptes(static_cast<size_t>(nbRangees));
        for (int i = 0; i < nbRangees; ++i)
            comptes[size_t(i)] = psb ? r.u32() : r.u16();
        for (int i = 0; i < nbRangees; ++i) {
            const qint64 n = comptes[size_t(i)];
            if (!r.reste(n))
                break;
            packbits(r.ici(), n, plans.data() + qint64(i) * octetsRangee, octetsRangee);
            r.sauter(n);
        }
    } else if (compression == 2 || compression == 3) {
        // ZIP (zlib) : qUncompress veut la taille attendue en tête.
        QByteArray zdonnees;
        const quint32 attendu = quint32(total);
        zdonnees.resize(4);
        qToBigEndian<quint32>(attendu, zdonnees.data());
        zdonnees.append(r.ici(), int(r.taille() - r.pos()));
        const QByteArray brut = qUncompress(zdonnees);
        if (brut.size() < total)
            return QImage();
        std::memcpy(plans.data(), brut.constData(), size_t(total));
        if (compression == 3 && profondeur == 8) {
            for (qint64 rg = 0; rg < qint64(hauteur) * canaux; ++rg) {
                quint8 *l = plans.data() + rg * octetsRangee;
                for (qint64 x = 1; x < octetsRangee; ++x)
                    l[x] = quint8(l[x] + l[x - 1]);
            }
        } else if (compression == 3 && profondeur == 16) {
            for (qint64 rg = 0; rg < qint64(hauteur) * canaux; ++rg) {
                quint8 *l = plans.data() + rg * octetsRangee;
                quint16 prec = 0;
                for (int x = 0; x < largeur; ++x) {
                    quint16 v = qFromBigEndian<quint16>(l + x * 2);
                    v = quint16(v + prec);
                    prec = v;
                    qToBigEndian<quint16>(v, l + x * 2);
                }
            }
        }
    } else {
        return QImage();
    }

    auto plan = [&](int c) { return plans.data() + qint64(qMin(c, canaux - 1)) * taillePlan; };
    QImage img(largeur, hauteur, QImage::Format_ARGB32);
    if (img.isNull())
        return QImage();

    for (int y = 0; y < hauteur; ++y) {
        auto *dst = reinterpret_cast<QRgb *>(img.scanLine(y));
        for (int x = 0; x < largeur; ++x) {
            const qint64 i = qint64(y) * largeur + x;
            int R = 0, G = 0, B = 0, A = 255;
            if (profondeur == 1) {
                const quint8 octet = plan(0)[qint64(y) * octetsRangee + x / 8];
                const bool noir = octet & (0x80 >> (x % 8));
                R = G = B = noir ? 0 : 255;
            } else if (mode == 3 || (mode == 7 && canaux >= 3)) { // RVB
                R = versOctet(plan(0), i, profondeur);
                G = versOctet(plan(1), i, profondeur);
                B = versOctet(plan(2), i, profondeur);
                if (mode == 3 && canaux >= 4)
                    A = versOctet(plan(3), i, profondeur);
            } else if (mode == 4) { // CMJN, rangé inversé
                const int c = versOctet(plan(0), i, profondeur), m = versOctet(plan(1), i, profondeur);
                const int j = versOctet(plan(2), i, profondeur), k = versOctet(plan(3), i, profondeur);
                R = c * k / 255;
                G = m * k / 255;
                B = j * k / 255;
                if (canaux >= 5)
                    A = versOctet(plan(4), i, profondeur);
            } else if (mode == 2 && palette.size() >= 768) { // indexé
                const int idx = plan(0)[i];
                R = quint8(palette[idx]);
                G = quint8(palette[256 + idx]);
                B = quint8(palette[512 + idx]);
            } else if (mode == 9) { // Lab
                const double L = versOctet(plan(0), i, profondeur) * 100.0 / 255.0;
                const double a = versOctet(plan(1), i, profondeur) - 128.0;
                const double b = versOctet(plan(2), i, profondeur) - 128.0;
                const double fy = (L + 16.0) / 116.0;
                const double X = 0.9642 * labF(fy + a / 500.0), Y = labF(fy), Z = 0.8249 * labF(fy - b / 200.0);
                R = srgb(3.1339 * X - 1.6169 * Y - 0.4906 * Z);
                G = srgb(-0.9788 * X + 1.9161 * Y + 0.0335 * Z);
                B = srgb(0.0719 * X - 0.2290 * Y + 1.4052 * Z);
                if (canaux >= 4)
                    A = versOctet(plan(3), i, profondeur);
            } else { // niveaux de gris, bichromie, multicanal
                R = G = B = versOctet(plan(0), i, profondeur);
                if ((mode == 1 || mode == 8) && canaux >= 2)
                    A = versOctet(plan(1), i, profondeur);
            }
            dst[x] = qRgba(R, G, B, A);
        }
    }
    return img;
}

// ===========================================================================
// RAW — LibRaw
// ===========================================================================
bool rawDisponible()
{
#ifdef FEUILLET_LIBRAW
    return true;
#else
    return false;
#endif
}

bool estExtensionRaw(const QString &extBrute)
{
    static const QSet<QString> raw = {
        QStringLiteral(".cr2"), QStringLiteral(".cr3"), QStringLiteral(".crw"), QStringLiteral(".nef"),
        QStringLiteral(".nrw"), QStringLiteral(".arw"), QStringLiteral(".srf"), QStringLiteral(".sr2"),
        QStringLiteral(".dng"), QStringLiteral(".raf"), QStringLiteral(".orf"), QStringLiteral(".rw2"),
        QStringLiteral(".pef"), QStringLiteral(".rwl"), QStringLiteral(".srw"), QStringLiteral(".3fr"),
        QStringLiteral(".erf"), QStringLiteral(".kdc"), QStringLiteral(".mrw"), QStringLiteral(".mos"),
        QStringLiteral(".iiq"), QStringLiteral(".x3f"),
    };
    return raw.contains(extBrute.toLower());
}

QImage lireRaw(const QString &chemin)
{
#ifdef FEUILLET_LIBRAW
    QFile f(chemin);
    if (!f.open(QIODevice::ReadOnly))
        return QImage();
    QByteArray donnees = f.readAll();
    LibRaw raw;
    if (raw.open_buffer(donnees.data(), size_t(donnees.size())) != LIBRAW_SUCCESS)
        return QImage();
    if (raw.unpack() != LIBRAW_SUCCESS)
        return QImage();
    if (raw.dcraw_process() != LIBRAW_SUCCESS)
        return QImage();
    int err = 0;
    libraw_processed_image_t *im = raw.dcraw_make_mem_image(&err);
    if (!im)
        return QImage();
    QImage resultat;
    if (im->type == LIBRAW_IMAGE_BITMAP && im->colors == 3 && im->bits == 8) {
        resultat = QImage(im->data, im->width, im->height, int(im->width) * 3, QImage::Format_RGB888).copy();
    } else if (im->type == LIBRAW_IMAGE_BITMAP && im->colors == 1 && im->bits == 8) {
        resultat = QImage(im->data, im->width, im->height, int(im->width), QImage::Format_Grayscale8).copy();
    }
    LibRaw::dcraw_clear_mem(im);
    return resultat;
#else
    Q_UNUSED(chemin);
    return QImage();
#endif
}

// ===========================================================================
// WIC — le décodeur d'images de Windows
// ===========================================================================
QImage lireWic(const QString &chemin)
{
#ifdef Q_OS_WIN
    IWICImagingFactory *fabrique = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_IWICImagingFactory,
                                reinterpret_cast<void **>(&fabrique))))
        return QImage();
    QImage resultat;
    IWICBitmapDecoder *decodeur = nullptr;
    const std::wstring w = chemin.toStdWString();
    if (SUCCEEDED(fabrique->CreateDecoderFromFilename(w.c_str(), nullptr, GENERIC_READ,
                                                      WICDecodeMetadataCacheOnDemand, &decodeur))) {
        IWICBitmapFrameDecode *trame = nullptr;
        if (SUCCEEDED(decodeur->GetFrame(0, &trame))) {
            IWICBitmapSource *converti = nullptr;
            if (SUCCEEDED(WICConvertBitmapSource(GUID_WICPixelFormat32bppBGRA, trame, &converti))) {
                UINT l = 0, h = 0;
                converti->GetSize(&l, &h);
                if (l > 0 && h > 0) {
                    QImage img(int(l), int(h), QImage::Format_ARGB32);
                    if (!img.isNull()
                        && SUCCEEDED(converti->CopyPixels(nullptr, UINT(img.bytesPerLine()),
                                                          UINT(img.sizeInBytes()), img.bits())))
                        resultat = img;
                }
                converti->Release();
            }
            trame->Release();
        }
        decodeur->Release();
    }
    fabrique->Release();
    return resultat;
#else
    Q_UNUSED(chemin);
    return QImage();
#endif
}

} // namespace lecteurs
