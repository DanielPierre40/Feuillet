#include "theme.h"

namespace theme {

QString style()
{
    return QStringLiteral(R"(
QMainWindow  { background: %1; }
QDialog      { background: %1; color: %2; }
QWidget      { background: %1; color: %2; }

QMenuBar     { background: %3; color: #606878; border: none; }
QMenuBar::item           { background: transparent; padding: 4px 8px; }
QMenuBar::item:selected  { color: %2; background: #1a1a2e; }

QMenu        { background: %4; color: %2; border: 1px solid %5; }
QMenu::item  { padding: 6px 24px; }
QMenu::item:selected     { background: %6; color: %7; }
QMenu::separator         { height: 1px; background: %5; margin: 4px 8px; }

QGraphicsView {
    background: %8;
    border: 1px solid %5;
}

QPushButton  {
    background: %9;
    color: %2;
    border: 1px solid %10;
    border-radius: 3px;
    padding: 5px 14px;
    font-family: "%11";
    font-size: 10pt;
}
QPushButton:hover {
    background: %12;
    color: %7;
    border-color: %7;
}
QPushButton:pressed {
    background: %13;
}

QLineEdit {
    background: %14;
    color: %2;
    border: 1px solid %5;
    border-radius: 3px;
    padding: 4px 8px;
    font-family: "%11";
    font-size: 9pt;
}

QScrollBar:vertical   { background: %15; width: 14px; border: none; }
QScrollBar::handle:vertical   { background: %16; min-height: 30px;
                                border-radius: 3px; margin: 2px; }
QScrollBar::handle:vertical:hover { background: #666677; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

QScrollBar:horizontal { background: %15; height: 14px; border: none; }
QScrollBar::handle:horizontal { background: %16; min-width: 30px;
                                border-radius: 3px; margin: 2px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

QLabel { color: %2; font-family: "%11"; }
)")
        .arg(BG_WIN, FG, TOOLBAR_BG, BG_MENU, BORDER_COL, SEL_BG, ACCENT,
             SCENE_BG, BG_BTN)
        .arg(BD_BTN, FONT_UI, BG_BTN_HOV, BG_BTN_PRS, BG_EDITOR, SCROLL_BG,
             SCROLL_FG);
}

} // namespace theme
