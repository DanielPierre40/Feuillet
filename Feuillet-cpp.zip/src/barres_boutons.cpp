#include "barres_boutons.h"

#include "barre_titre.h"
#include "theme.h"

#include <QApplication>
#include <QCheckBox>
#include <QColorDialog>
#include <QContextMenuEvent>
#include <QDrag>
#include <QDragEnterEvent>
#include <QFontComboBox>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QJsonArray>
#include <QLabel>
#include <QMenu>
#include <QMimeData>
#include <QPainter>
#include <QPushButton>
#include <QSpinBox>
#include <QVBoxLayout>

#include <algorithm>

namespace {

const QString POLICE_DEFAUT = theme::FONT_UI;
const QString COULEUR_DEFAUT = theme::FG;
const QString FOND_DEFAUT = theme::BG_BTN;
constexpr int TAILLE_DEFAUT = 10;
const QString MIME_BOUTON = QStringLiteral("application/x-feuillet-bouton");
constexpr int LARGEUR_SEPARATEUR_DEFAUT = 40;
constexpr int LARGEUR_SEPARATEUR_MAX = 100000;
constexpr int HAUTEUR_BOUTON = 36;

QString texteDe(QWidget *w)
{
    if (auto *b = qobject_cast<QAbstractButton *>(w))
        return b->text();
    return QString();
}

} // namespace

// ===========================================================================
// Curseur, vignette, menus
// ===========================================================================
QPixmap curseurOrange()
{
    QPixmap pix(26, 26);
    pix.fill(Qt::transparent);
    QPainter p(&pix);
    p.setRenderHint(QPainter::Antialiasing);
    const QPoint fleche[] = {{3, 2}, {3, 19}, {8, 15}, {11, 22}, {14, 20}, {11, 14}, {17, 13}};
    p.setPen(QPen(QColor(0, 0, 0, 200), 2));
    p.setBrush(QColor(ORANGE));
    p.drawPolygon(fleche, 7);
    p.end();
    return pix;
}

QPixmap vignette(QWidget *widget)
{
    const QPixmap source = widget->grab();
    QPixmap pix(source.size());
    pix.fill(Qt::transparent);
    QPainter p(&pix);
    p.setOpacity(0.75);
    p.drawPixmap(0, 0, source);
    p.end();
    return pix;
}

QMenu *ouvrirMenuAuClic(QPushButton *bouton, QMenu *menu)
{
    QObject::connect(bouton, &QPushButton::clicked, bouton, [bouton, menu]() {
        menu->exec(bouton->mapToGlobal(QPoint(0, bouton->height())));
    });
    return menu;
}

QString feuilleApparence(const QJsonObject &apparence)
{
    if (apparence.isEmpty())
        return QString();
    QStringList morceaux;
    const QString famille = apparence.value(QStringLiteral("famille")).toString().trimmed();
    if (!famille.isEmpty())
        morceaux << QStringLiteral("font-family: \"%1\";").arg(famille);
    const int taille = apparence.value(QStringLiteral("taille")).toInt(0);
    if (taille > 0)
        morceaux << QStringLiteral("font-size: %1pt;").arg(taille);
    morceaux << QStringLiteral("font-weight: %1;")
                    .arg(apparence.value(QStringLiteral("gras")).toBool() ? QStringLiteral("bold")
                                                                           : QStringLiteral("normal"));
    morceaux << QStringLiteral("font-style: %1;")
                    .arg(apparence.value(QStringLiteral("italique")).toBool() ? QStringLiteral("italic")
                                                                               : QStringLiteral("normal"));
    const QString couleur = apparence.value(QStringLiteral("couleur")).toString().trimmed();
    if (!couleur.isEmpty() && QColor(couleur).isValid())
        morceaux << QStringLiteral("color: %1;").arg(couleur);

    QStringList etats;
    const QString fond = apparence.value(QStringLiteral("fond")).toString().trimmed();
    if (!fond.isEmpty() && QColor(fond).isValid()) {
        const QColor teinte(fond);
        morceaux << QStringLiteral("background-color: %1;").arg(teinte.name());
        const bool sombre = teinte.lightness() < 128;
        const QColor survol = sombre ? teinte.lighter(130) : teinte.darker(112);
        const QColor appui = sombre ? teinte.darker(120) : teinte.darker(128);
        etats << QStringLiteral("QPushButton:hover { background-color: %1; }").arg(survol.name());
        etats << QStringLiteral("QPushButton:pressed { background-color: %1; }").arg(appui.name());
    }
    return (QStringList{QStringLiteral("QPushButton { ") + morceaux.join(QLatin1Char(' ')) + QStringLiteral(" }")}
            + etats)
        .join(QLatin1Char(' '));
}

// ===========================================================================
// ChampLibelle — Entrée valide, Maj+Entrée passe à la ligne
// ===========================================================================
ChampLibelle::ChampLibelle(const QString &texte, QWidget *parent) : QPlainTextEdit(parent)
{
    setPlainText(texte);
    setTabChangesFocus(true);
    setLineWrapMode(QPlainTextEdit::NoWrap);
    setStyleSheet(QStringLiteral("QPlainTextEdit { background: %1; color: %2; border: 1px solid %3;"
                                 " border-radius: 3px; padding: 4px 6px;"
                                 " font-family: \"%4\"; font-size: 10pt; }")
                      .arg(theme::BG_EDITOR, COULEUR_DEFAUT, theme::BORDER_COL, POLICE_DEFAUT));
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    const QMargins m = contentsMargins();
    const int hauteur = 2 * fontMetrics().lineSpacing() + 12;
    setFixedHeight(hauteur + m.top() + m.bottom());
    QTextCursor c = textCursor();
    c.movePosition(QTextCursor::End);
    setTextCursor(c);
}

void ChampLibelle::keyPressEvent(QKeyEvent *ev)
{
    if (ev->key() == Qt::Key_Return || ev->key() == Qt::Key_Enter) {
        if (ev->modifiers() & Qt::ShiftModifier) {
            insertPlainText(QStringLiteral("\n"));
        } else {
            ev->ignore();
            if (auto *boite = qobject_cast<QDialog *>(window()))
                boite->accept();
        }
        return;
    }
    QPlainTextEdit::keyPressEvent(ev);
}

// ===========================================================================
// BoiteRenommage
// ===========================================================================
BoiteRenommage::BoiteRenommage(const QString &texte, QWidget *parent) : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Renommer le bouton"));
    auto *colonne = new QVBoxLayout(this);
    colonne->setSpacing(10);
    colonne->addWidget(new QLabel(QStringLiteral("Nouveau libellé du bouton :")));
    m_champ = new ChampLibelle(texte, this);
    colonne->addWidget(m_champ);
    auto *aide = new QLabel(QStringLiteral("Maj+Entrée passe à la ligne — un libellé peut tenir sur deux "
                                           "lignes.\nEntrée valide ; un champ laissé vide rend au bouton "
                                           "son libellé d'origine."));
    aide->setStyleSheet(QStringLiteral("color: %1; font-size: 9pt;").arg(QColor(COULEUR_DEFAUT).darker(155).name()));
    colonne->addWidget(aide);

    auto *boutons = new QHBoxLayout();
    auto *ok = new QPushButton(QStringLiteral("OK"));
    // Pas de setDefault : la touche Entrée est traitée par le champ.
    connect(ok, &QPushButton::clicked, this, &QDialog::accept);
    auto *annuler = new QPushButton(QStringLiteral("Annuler"));
    connect(annuler, &QPushButton::clicked, this, &QDialog::reject);
    boutons->addStretch();
    boutons->addWidget(ok);
    boutons->addWidget(annuler);
    colonne->addLayout(boutons);
    m_champ->setFocus();
    cadre::poserCadre(this, false, false);
}

QString BoiteRenommage::libelle() const
{
    QStringList lignes;
    const auto brutes = m_champ->toPlainText().split(QLatin1Char('\n'));
    for (const QString &l : brutes) {
        const QString t = l.trimmed();
        if (!t.isEmpty())
            lignes << t;
    }
    return lignes.join(QLatin1Char('\n'));
}

// ===========================================================================
// BoiteApparence
// ===========================================================================
BoiteApparence::BoiteApparence(const QString &texteBouton, const QJsonObject &apparence, QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Apparence du bouton"));
    auto *colonne = new QVBoxLayout(this);
    colonne->setSpacing(12);
    auto *forme = new QFormLayout();
    forme->setSpacing(10);

    m_police = new QFontComboBox();
    QString famille = apparence.value(QStringLiteral("famille")).toString();
    if (famille.isEmpty())
        famille = POLICE_DEFAUT;
    m_police->setCurrentFont(QFont(famille));
    forme->addRow(QStringLiteral("Police :"), m_police);

    auto *ligneStyle = new QHBoxLayout();
    m_gras = new QCheckBox(QStringLiteral("Gras"));
    m_gras->setChecked(apparence.value(QStringLiteral("gras")).toBool());
    m_italique = new QCheckBox(QStringLiteral("Italique"));
    m_italique->setChecked(apparence.value(QStringLiteral("italique")).toBool());
    ligneStyle->addWidget(m_gras);
    ligneStyle->addWidget(m_italique);
    ligneStyle->addStretch();
    forme->addRow(QStringLiteral("Style :"), ligneStyle);

    m_taille = new QSpinBox();
    m_taille->setRange(6, 72);
    m_taille->setSuffix(QStringLiteral(" pt"));
    int taille = apparence.value(QStringLiteral("taille")).toInt(TAILLE_DEFAUT);
    if (taille <= 0)
        taille = TAILLE_DEFAUT;
    m_taille->setValue(qBound(6, taille, 72));
    forme->addRow(QStringLiteral("Taille :"), m_taille);

    const QString couleur = apparence.value(QStringLiteral("couleur")).toString();
    m_couleur = QColor(couleur).isValid() && !couleur.isEmpty() ? couleur : COULEUR_DEFAUT;
    m_btnCouleur = new QPushButton();
    m_btnCouleur->setFixedSize(64, 26);
    m_btnCouleur->setToolTip(QStringLiteral("Choisir la couleur du texte"));
    connect(m_btnCouleur, &QPushButton::clicked, this, &BoiteApparence::choisirCouleur);
    forme->addRow(QStringLiteral("Couleur du texte :"), m_btnCouleur);

    const QString fond = apparence.value(QStringLiteral("fond")).toString();
    const bool fondValide = !fond.isEmpty() && QColor(fond).isValid();
    m_fond = fondValide ? fond : FOND_DEFAUT;
    m_btnFond = new QPushButton();
    m_btnFond->setFixedSize(64, 26);
    m_btnFond->setToolTip(QStringLiteral("Choisir la couleur du fond du bouton"));
    connect(m_btnFond, &QPushButton::clicked, this, &BoiteApparence::choisirFond);
    m_caseFond = new QCheckBox(QStringLiteral("Fond personnalisé"));
    m_caseFond->setChecked(fondValide);
    m_caseFond->setToolTip(QStringLiteral("Décochée, la case rend au bouton le fond commun du thème."));
    auto *ligneFond = new QHBoxLayout();
    ligneFond->addWidget(m_btnFond);
    ligneFond->addWidget(m_caseFond);
    ligneFond->addStretch();
    forme->addRow(QStringLiteral("Couleur du fond :"), ligneFond);
    colonne->addLayout(forme);

    // L'aperçu est un vrai bouton, habillé exactement comme le sera celui de
    // la barre — cliquer dessus ne fait rien.
    m_apercu = new QPushButton(texteBouton.isEmpty() ? QStringLiteral("Aperçu") : texteBouton);
    m_apercu->setMinimumHeight(36);
    m_apercu->setFocusPolicy(Qt::NoFocus);
    colonne->addWidget(new QLabel(QStringLiteral("Aperçu :")));
    colonne->addWidget(m_apercu);

    auto *boutons = new QHBoxLayout();
    auto *origine = new QPushButton(QStringLiteral("Réglages d'origine"));
    origine->setToolTip(QStringLiteral("Rend au bouton l'apparence commune du thème de Feuillet."));
    connect(origine, &QPushButton::clicked, this, [this]() {
        m_retourOrigine = true;
        accept();
    });
    auto *ok = new QPushButton(QStringLiteral("OK"));
    ok->setDefault(true);
    connect(ok, &QPushButton::clicked, this, &QDialog::accept);
    auto *annuler = new QPushButton(QStringLiteral("Annuler"));
    connect(annuler, &QPushButton::clicked, this, &QDialog::reject);
    boutons->addWidget(origine);
    boutons->addStretch();
    boutons->addWidget(ok);
    boutons->addWidget(annuler);
    colonne->addLayout(boutons);

    connect(m_police, &QFontComboBox::currentFontChanged, this, [this]() { rafraichir(); });
    connect(m_gras, &QCheckBox::toggled, this, [this]() { rafraichir(); });
    connect(m_italique, &QCheckBox::toggled, this, [this]() { rafraichir(); });
    connect(m_caseFond, &QCheckBox::toggled, this, [this]() { rafraichir(); });
    connect(m_taille, QOverload<int>::of(&QSpinBox::valueChanged), this, [this]() { rafraichir(); });
    rafraichir();
    cadre::poserCadre(this, false, false);
}

QJsonObject BoiteApparence::apparenceCourante() const
{
    QJsonObject a;
    a.insert(QStringLiteral("famille"), m_police->currentFont().family());
    a.insert(QStringLiteral("gras"), m_gras->isChecked());
    a.insert(QStringLiteral("italique"), m_italique->isChecked());
    a.insert(QStringLiteral("taille"), m_taille->value());
    a.insert(QStringLiteral("couleur"), m_couleur);
    // Chaîne vide = fond du thème, survol compris.
    a.insert(QStringLiteral("fond"), m_caseFond->isChecked() ? m_fond : QString());
    return a;
}

void BoiteApparence::rafraichir()
{
    m_btnCouleur->setStyleSheet(QStringLiteral("background: %1; border: 1px solid #888;").arg(m_couleur));
    m_btnFond->setEnabled(m_caseFond->isChecked());
    m_btnFond->setStyleSheet(QStringLiteral("background: %1; border: 1px solid #888;").arg(m_fond));
    m_apercu->setStyleSheet(feuilleApparence(apparenceCourante()));
}

void BoiteApparence::choisirCouleur()
{
    const QColor c = QColorDialog::getColor(QColor(m_couleur), this, QStringLiteral("Couleur du texte du bouton"));
    if (c.isValid()) {
        m_couleur = c.name();
        rafraichir();
    }
}

void BoiteApparence::choisirFond()
{
    const QColor c = QColorDialog::getColor(QColor(m_fond), this, QStringLiteral("Couleur du fond du bouton"));
    if (c.isValid()) {
        m_fond = c.name();
        m_caseFond->setChecked(true); // choisir une couleur, c'est la vouloir
        rafraichir();
    }
}

QJsonObject BoiteApparence::resultat() const
{
    return m_retourOrigine ? QJsonObject() : apparenceCourante();
}

// ===========================================================================
// Separateur — espace transparent de largeur libre
// ===========================================================================
Separateur::Separateur(int largeur, QWidget *parent) : QWidget(parent)
{
    setCursor(Qt::PointingHandCursor);
    setMinimumHeight(36);
    setAttribute(Qt::WA_TranslucentBackground);
    setStyleSheet(QStringLiteral("background: transparent; border: none;"));
    setToolTip(QStringLiteral("Séparateur transparent — clic droit pour changer sa largeur\n"
                              "ou le retirer. Il se déplace comme un bouton."));
    reglerLargeur(largeur);
}

void Separateur::reglerLargeur(int largeur)
{
    m_largeur = qMax(1, largeur);
    setFixedWidth(m_largeur);
}

void Separateur::mousePressEvent(QMouseEvent *ev)
{
    // Sans cet accusé de réception, aucun déplacement ne suivrait.
    ev->accept();
}

// ===========================================================================
// Glisseur — un filtre posé sur chaque objet déplaçable
// ===========================================================================
class Glisseur : public QObject {
public:
    explicit Glisseur(GroupeBarres *groupe) : QObject(groupe), m_groupe(groupe) {}

    bool eventFilter(QObject *obj, QEvent *ev) override
    {
        auto *w = qobject_cast<QWidget *>(obj);
        if (!w)
            return false;
        const QEvent::Type t = ev->type();
        if (t == QEvent::ContextMenu && !w->isEnabled()) {
            // Un widget désactivé absorbe le clic droit : on rend la main à la barre.
            if (auto *barre = qobject_cast<BarreBoutons *>(w->parentWidget())) {
                auto *ce = static_cast<QContextMenuEvent *>(ev);
                barre->menuContextuel(w->mapTo(barre, ce->pos()), ce->globalPos());
                return true;
            }
            return false;
        }
        if (t == QEvent::MouseButtonPress) {
            auto *me = static_cast<QMouseEvent *>(ev);
            if (me->button() == Qt::LeftButton) {
                m_depart = me->position().toPoint();
                m_cible = w;
            }
        } else if (t == QEvent::MouseButtonRelease) {
            m_depart.reset();
        } else if (t == QEvent::MouseMove && m_depart && w == m_cible) {
            auto *me = static_cast<QMouseEvent *>(ev);
            if (me->buttons() & Qt::LeftButton) {
                const int ecart = (me->position().toPoint() - *m_depart).manhattanLength();
                if (ecart >= QApplication::startDragDistance()) {
                    m_depart.reset();
                    lancer(w);
                    return true;
                }
            }
        }
        return false;
    }

private:
    void lancer(QWidget *objet)
    {
        auto *donnees = new QMimeData();
        donnees->setData(MIME_BOUTON, objet->objectName().toUtf8());
        auto *drag = new QDrag(objet);
        drag->setMimeData(donnees);
        const QPixmap vign = vignette(objet);
        drag->setPixmap(vign);
        drag->setHotSpot(QPoint(vign.width() / 2, vign.height() / 2));
        drag->setDragCursor(curseurOrange(), Qt::MoveAction);
        drag->setDragCursor(curseurOrange(), Qt::IgnoreAction);
        QPointer<QWidget> garde(objet);
        drag->exec(Qt::MoveAction);
        // Le glissé a intercepté le relâchement : sans cela le bouton resterait enfoncé.
        if (garde)
            if (auto *b = qobject_cast<QAbstractButton *>(garde.data()))
                b->setDown(false);
        m_groupe->enregistrer();
    }

    GroupeBarres *m_groupe;
    std::optional<QPoint> m_depart;
    QPointer<QWidget> m_cible;
};

// ===========================================================================
// BarreBoutons
// ===========================================================================
BarreBoutons::BarreBoutons(const QString &nom, GroupeBarres *groupe, QWidget *parent)
    : QWidget(parent), m_nom(nom), m_groupe(groupe)
{
    setAttribute(Qt::WA_StyledBackground, true);
    setAcceptDrops(true);
    m_layout = new QHBoxLayout(this);
    groupe->ajouterBarre(this);
}

QList<QPair<int, QWidget *>> BarreBoutons::occupants() const
{
    QList<QPair<int, QWidget *>> occ;
    for (int i = 0; i < m_layout->count(); ++i)
        if (QWidget *w = m_layout->itemAt(i)->widget())
            if (w->isVisible())
                occ.append({i, w});
    return occ;
}

QPair<int, int> BarreBoutons::viser(int x) const
{
    const auto occ = occupants();
    if (occ.isEmpty())
        return {0, contentsMargins().left()};
    const int demi = qMax(2, m_layout->spacing() / 2);
    if (x < occ.first().second->geometry().center().x())
        return {occ.first().first, occ.first().second->geometry().left() - demi};
    for (int k = 0; k + 1 < occ.size(); ++k) {
        const auto &a = occ[k];
        const auto &b = occ[k + 1];
        if (x < b.second->geometry().center().x()) {
            // Entre a et b : de quel bord est-on le plus près ?
            if ((x - a.second->geometry().right()) <= (b.second->geometry().left() - x))
                return {a.first + 1, a.second->geometry().right() + demi};
            return {b.first, b.second->geometry().left() - demi};
        }
    }
    return {occ.last().first + 1, occ.last().second->geometry().right() + demi};
}

void BarreBoutons::dragEnterEvent(QDragEnterEvent *ev)
{
    if (ev->mimeData()->hasFormat(MIME_BOUTON))
        ev->acceptProposedAction();
}

void BarreBoutons::dragMoveEvent(QDragMoveEvent *ev)
{
    if (!ev->mimeData()->hasFormat(MIME_BOUTON))
        return;
    m_trait = viser(ev->position().toPoint().x()).second;
    update();
    ev->acceptProposedAction();
}

void BarreBoutons::dragLeaveEvent(QDragLeaveEvent *)
{
    m_trait.reset();
    update();
}

void BarreBoutons::dropEvent(QDropEvent *ev)
{
    m_trait.reset();
    update();
    if (!ev->mimeData()->hasFormat(MIME_BOUTON))
        return;
    const QString nom = QString::fromUtf8(ev->mimeData()->data(MIME_BOUTON));
    QWidget *objet = m_groupe->objet(nom);
    if (!objet)
        return;
    inserer(objet, viser(ev->position().toPoint().x()).first);
    ev->acceptProposedAction();
    m_groupe->enregistrer();
}

void BarreBoutons::collerAuPrecedent(const QList<QWidget *> &compagnons)
{
    m_colles.clear();
    for (QWidget *c : compagnons)
        if (c)
            m_colles.append(c);
    recoller();
}

void BarreBoutons::recoller()
{
    if (m_colles.isEmpty())
        return;
    QList<int> rangs;
    for (const auto &c : std::as_const(m_colles))
        if (c) {
            const int r = m_layout->indexOf(c.data());
            if (r != -1)
                rangs.append(r);
        }
    if (rangs.isEmpty())
        return;
    const int premier = *std::min_element(rangs.begin(), rangs.end());
    const int dernier = *std::max_element(rangs.begin(), rangs.end());
    if (premier == 0)
        return;
    QLayoutItem *avant = m_layout->itemAt(premier - 1);
    if (!avant || !avant->spacerItem())
        return; // rien d'élastique devant : c'est bon
    // takeAt décale tout ce qui suit : l'espace se replace juste derrière.
    QLayoutItem *espace = m_layout->takeAt(premier - 1);
    m_layout->insertItem(dernier, espace);
}

void BarreBoutons::ajusterHauteur()
{
    // Un occupant ALIGNÉ échappe au plafond de hauteur des tailles fixes : on
    // centre chacun, puis on annonce la hauteur du plus haut.
    recoller();
    int haute = HAUTEUR_BOUTON;
    for (const auto &o : occupants()) {
        haute = qMax(haute, qMax(o.second->sizeHint().height(), o.second->minimumHeight()));
        m_layout->setAlignment(o.second, Qt::AlignVCenter);
    }
    const QMargins m = m_layout->contentsMargins();
    setMinimumHeight(haute + m.top() + m.bottom());
    m_layout->invalidate();
    updateGeometry();
}

void BarreBoutons::showEvent(QShowEvent *ev)
{
    QWidget::showEvent(ev);
    ajusterHauteur();
}

void BarreBoutons::inserer(QWidget *objet, int index)
{
    QWidget *ancien = objet->parentWidget();
    if (ancien && ancien->layout()) {
        if (ancien == this) {
            // Le rang visé compte l'objet lui-même : son retrait décale la suite.
            const int place = m_layout->indexOf(objet);
            if (place != -1 && place < index)
                --index;
        }
        ancien->layout()->removeWidget(objet);
    }
    m_layout->insertWidget(qBound(0, index, m_layout->count()), objet);
    objet->show();
    ajusterHauteur();
    for (BarreBoutons *autre : m_groupe->barres())
        if (autre != this)
            autre->ajusterHauteur();
}

void BarreBoutons::contextMenuEvent(QContextMenuEvent *ev)
{
    menuContextuel(ev->pos(), ev->globalPos());
}

void BarreBoutons::menuContextuel(const QPoint &pos, const QPoint &posGlobale)
{
    QWidget *cible = childAt(pos);
    while (cible && cible->parentWidget() != this)
        cible = cible->parentWidget();

    QMenu menu(this);
    QAction *actAvant = nullptr, *actApres = nullptr, *actIci = nullptr;
    QAction *actLargeur = nullptr, *actSuppr = nullptr;
    QAction *actApparence = nullptr, *actRenommer = nullptr;
    auto *sep = qobject_cast<Separateur *>(cible);
    if (sep) {
        actLargeur = menu.addAction(QStringLiteral("Modifier la largeur du séparateur  (%1 px)…").arg(sep->largeur()));
        actSuppr = menu.addAction(QStringLiteral("Supprimer ce séparateur"));
        menu.addSeparator();
        actAvant = menu.addAction(QStringLiteral("Ajouter un séparateur transparent avant"));
        actApres = menu.addAction(QStringLiteral("Ajouter un séparateur transparent après"));
    } else if (cible && m_groupe->connait(cible->objectName())) {
        actApparence = menu.addAction(QStringLiteral("Apparence du bouton…"));
        actRenommer = menu.addAction(QStringLiteral("Renommer le bouton…"));
        menu.addSeparator();
        actAvant = menu.addAction(QStringLiteral("Ajouter un séparateur transparent avant ce bouton"));
        actApres = menu.addAction(QStringLiteral("Ajouter un séparateur transparent après ce bouton"));
    } else {
        actIci = menu.addAction(QStringLiteral("Ajouter un séparateur transparent ici"));
    }
    menu.addSeparator();
    QAction *actUsine = menu.addAction(QStringLiteral("Rétablir la disposition d'origine"));

    QAction *choix = menu.exec(posGlobale);
    if (!choix)
        return;
    auto *bouton = qobject_cast<QPushButton *>(cible);
    if (choix == actUsine) {
        m_groupe->remettreAZero();
    } else if (choix == actApparence && bouton) {
        m_groupe->modifierApparence(bouton, this);
    } else if (choix == actRenommer && bouton) {
        m_groupe->renommer(bouton, this);
    } else if (choix == actLargeur && sep) {
        demanderLargeur(sep);
    } else if (choix == actSuppr && sep) {
        m_groupe->supprimerSeparateur(sep);
    } else if ((choix == actAvant || choix == actApres) && cible) {
        const int rang = m_layout->indexOf(cible);
        nouveauSeparateur(choix == actAvant ? rang : rang + 1);
    } else if (choix == actIci) {
        nouveauSeparateur(viser(pos.x()).first);
    }
}

void BarreBoutons::nouveauSeparateur(int rang)
{
    const auto largeur = saisirLargeur(LARGEUR_SEPARATEUR_DEFAUT);
    if (!largeur)
        return;
    Separateur *sep = m_groupe->creerSeparateur(*largeur);
    inserer(sep, rang);
    m_groupe->enregistrer();
}

void BarreBoutons::demanderLargeur(Separateur *sep)
{
    const auto largeur = saisirLargeur(sep->largeur());
    if (!largeur)
        return;
    sep->reglerLargeur(*largeur);
    m_groupe->enregistrer();
}

std::optional<int> BarreBoutons::saisirLargeur(int valeur)
{
    bool ok = false;
    const int largeur = QInputDialog::getInt(this, QStringLiteral("Séparateur transparent"),
                                             QStringLiteral("Largeur du séparateur, en pixels :"), valeur, 1,
                                             LARGEUR_SEPARATEUR_MAX, 1, &ok);
    if (!ok)
        return std::nullopt;
    return largeur;
}

void BarreBoutons::paintEvent(QPaintEvent *ev)
{
    QWidget::paintEvent(ev);
    if (!m_trait)
        return;
    QPainter p(this);
    p.setPen(QPen(QColor(ORANGE), 3));
    const int haut = contentsMargins().top();
    p.drawLine(*m_trait, haut, *m_trait, height() - haut);
}

// ===========================================================================
// GroupeBarres
// ===========================================================================
GroupeBarres::GroupeBarres(QObject *parent, Rappel auChangement)
    : QObject(parent), m_auChangement(std::move(auChangement))
{
    m_glisseur = new Glisseur(this);
}

void GroupeBarres::ajusterBarres()
{
    for (BarreBoutons *b : std::as_const(m_barres))
        b->ajusterHauteur();
}

QWidget *GroupeBarres::rendreDeplacable(QWidget *objet, const QString &nom)
{
    objet->setObjectName(nom);
    objet->setCursor(Qt::PointingHandCursor);
    objet->installEventFilter(m_glisseur);
    m_objets.insert(nom, objet);
    if (qobject_cast<QAbstractButton *>(objet) && !m_libellesUsine.contains(nom))
        m_libellesUsine.insert(nom, texteDe(objet));
    return objet;
}

void GroupeBarres::declarerEtats(QPushButton *bouton, const QMap<QString, QString> &libelles,
                                 const QString &etat)
{
    const QString nom = bouton->objectName();
    for (auto it = libelles.begin(); it != libelles.end(); ++it) {
        const QString c = nom + QLatin1Char('@') + it.key();
        if (!m_libellesUsine.contains(c))
            m_libellesUsine.insert(c, it.value());
    }
    m_etats.insert(nom, etat);
    appliquerLibelle(nom);
}

void GroupeBarres::changerEtat(QPushButton *bouton, const QString &etat)
{
    m_etats.insert(bouton->objectName(), etat);
    appliquerLibelle(bouton->objectName());
}

QString GroupeBarres::cle(const QString &nom) const
{
    const QString etat = m_etats.value(nom);
    return etat.isEmpty() ? nom : nom + QLatin1Char('@') + etat;
}

void GroupeBarres::appliquerLibelle(const QString &nom)
{
    auto *b = qobject_cast<QAbstractButton *>(m_objets.value(nom));
    if (!b)
        return;
    const QString c = cle(nom);
    QString libelle;
    if (m_libelles.contains(c))
        libelle = m_libelles.value(c);
    else if (m_libellesUsine.contains(c))
        libelle = m_libellesUsine.value(c);
    else
        return;
    if (b->text() != libelle) {
        b->setText(libelle);
        b->updateGeometry();
    }
}

void GroupeBarres::appliquerApparence(QWidget *objet)
{
    if (qobject_cast<Separateur *>(objet))
        return;
    objet->setStyleSheet(feuilleApparence(m_apparences.value(objet->objectName())));
    objet->updateGeometry();
}

void GroupeBarres::modifierApparence(QPushButton *bouton, QWidget *parent)
{
    const QString nom = bouton->objectName();
    BoiteApparence boite(bouton->text(), m_apparences.value(nom), parent);
    if (boite.exec() != QDialog::Accepted)
        return;
    if (boite.retourOrigine())
        m_apparences.remove(nom);
    else
        m_apparences.insert(nom, boite.resultat());
    appliquerApparence(bouton);
    ajusterBarres();
    enregistrer();
}

void GroupeBarres::renommer(QPushButton *bouton, QWidget *parent)
{
    BoiteRenommage boite(bouton->text(), parent);
    if (boite.exec() != QDialog::Accepted)
        return;
    const QString nom = bouton->objectName();
    const QString c = cle(nom);
    const QString texte = boite.libelle();
    if (!texte.isEmpty())
        m_libelles.insert(c, texte);
    else
        m_libelles.remove(c); // retour au libellé d'origine
    appliquerLibelle(nom);
    ajusterBarres();
    enregistrer();
}

Separateur *GroupeBarres::creerSeparateur(int largeur)
{
    auto *sep = new Separateur(largeur);
    rendreDeplacable(sep, nomLibre());
    return sep;
}

void GroupeBarres::supprimerSeparateur(Separateur *sep)
{
    const QString nom = sep->objectName();
    if (!nom.startsWith(QLatin1String("sep-")))
        return;
    if (sep->parentWidget() && sep->parentWidget()->layout())
        sep->parentWidget()->layout()->removeWidget(sep);
    m_objets.remove(nom);
    sep->setParent(nullptr);
    sep->deleteLater();
    enregistrer();
}

QString GroupeBarres::nomLibre() const
{
    int i = 1;
    while (m_objets.contains(QStringLiteral("sep-%1").arg(i)))
        ++i;
    return QStringLiteral("sep-%1").arg(i);
}

void GroupeBarres::viderSeparateurs()
{
    const QStringList noms = m_objets.keys();
    for (const QString &nom : noms) {
        if (!nom.startsWith(QLatin1String("sep-")))
            continue;
        QWidget *sep = m_objets.take(nom);
        if (sep->parentWidget() && sep->parentWidget()->layout())
            sep->parentWidget()->layout()->removeWidget(sep);
        sep->setParent(nullptr);
        sep->deleteLater();
    }
}

QJsonObject GroupeBarres::agencement() const
{
    QJsonObject barres;
    for (BarreBoutons *barre : m_barres) {
        QJsonArray contenu;
        for (int i = 0; i < barre->layoutH()->count(); ++i) {
            QWidget *w = barre->layoutH()->itemAt(i)->widget();
            if (w && !w->objectName().isEmpty() && m_objets.contains(w->objectName()))
                contenu.append(QJsonArray{w->objectName(), i});
        }
        barres.insert(barre->nom(), contenu);
    }
    QJsonObject seps;
    for (auto it = m_objets.begin(); it != m_objets.end(); ++it)
        if (auto *s = qobject_cast<Separateur *>(it.value()))
            seps.insert(it.key(), s->largeur());
    QJsonObject libelles;
    for (auto it = m_libelles.begin(); it != m_libelles.end(); ++it)
        libelles.insert(it.key(), it.value());
    QJsonObject apparences;
    for (auto it = m_apparences.begin(); it != m_apparences.end(); ++it)
        apparences.insert(it.key(), it.value());

    QJsonObject r;
    r.insert(QStringLiteral("barres"), barres);
    r.insert(QStringLiteral("separateurs"), seps);
    r.insert(QStringLiteral("libelles"), libelles);
    r.insert(QStringLiteral("apparences"), apparences);
    return r;
}

bool GroupeBarres::appliquer(const QJsonObject &agencement)
{
    const QJsonValue vb = agencement.value(QStringLiteral("barres"));
    if (!vb.isObject())
        return false;
    const QJsonObject barres = vb.toObject();
    const QJsonObject largeurs = agencement.value(QStringLiteral("separateurs")).toObject();

    // Les séparateurs n'existent que par la disposition.
    viderSeparateurs();
    for (auto it = largeurs.begin(); it != largeurs.end(); ++it)
        if (it.key().startsWith(QLatin1String("sep-")))
            rendreDeplacable(new Separateur(it.value().toInt(LARGEUR_SEPARATEUR_DEFAUT)), it.key());

    // Libellés et apparences AVANT le contrôle de l'ordre.
    m_apparences.clear();
    const QJsonObject apps = agencement.value(QStringLiteral("apparences")).toObject();
    for (auto it = apps.begin(); it != apps.end(); ++it)
        if (m_objets.contains(it.key()) && it.value().isObject())
            m_apparences.insert(it.key(), it.value().toObject());
    m_libelles.clear();
    const QJsonObject libs = agencement.value(QStringLiteral("libelles")).toObject();
    for (auto it = libs.begin(); it != libs.end(); ++it)
        if (m_objets.contains(it.key().section(QLatin1Char('@'), 0, 0)))
            m_libelles.insert(it.key(), it.value().toString());
    for (auto it = m_objets.begin(); it != m_objets.end(); ++it) {
        if (qobject_cast<Separateur *>(it.value()))
            continue;
        appliquerLibelle(it.key());
        appliquerApparence(it.value());
    }
    ajusterBarres();

    // Une disposition qui ne parle pas exactement des mêmes objets vient d'une
    // autre version : on l'ignore en bloc.
    QStringList attendus;
    for (auto it = barres.begin(); it != barres.end(); ++it)
        for (const QJsonValue &c : it.value().toArray())
            attendus << c.toArray().at(0).toString();
    QStringList connus = m_objets.keys();
    attendus.sort();
    connus.sort();
    if (attendus != connus) {
        viderSeparateurs();
        return false;
    }

    for (BarreBoutons *barre : std::as_const(m_barres))
        for (QWidget *obj : std::as_const(m_objets))
            if (obj->parentWidget() == barre)
                barre->layoutH()->removeWidget(obj);

    for (BarreBoutons *barre : std::as_const(m_barres)) {
        QList<QPair<int, QString>> places;
        for (const QJsonValue &c : barres.value(barre->nom()).toArray()) {
            const QJsonArray a = c.toArray();
            places.append({a.at(1).toInt(), a.at(0).toString()});
        }
        std::stable_sort(places.begin(), places.end(),
                         [](const auto &x, const auto &y) { return x.first < y.first; });
        for (const auto &[index, nom] : places) {
            QWidget *obj = m_objets.value(nom);
            if (!obj)
                continue;
            barre->layoutH()->insertWidget(qMin(index, barre->layoutH()->count()), obj);
            obj->show();
        }
    }
    return true;
}

void GroupeBarres::enregistrer()
{
    if (m_auChangement)
        m_auChangement(agencement());
}

void GroupeBarres::figerDispositionUsine()
{
    m_usine = agencement();
    m_usineFigee = true;
}

void GroupeBarres::remettreAZero()
{
    if (!m_usineFigee)
        return;
    QJsonObject usine = m_usine;
    const QJsonObject courant = agencement();
    usine.insert(QStringLiteral("libelles"), courant.value(QStringLiteral("libelles")));
    usine.insert(QStringLiteral("apparences"), courant.value(QStringLiteral("apparences")));
    if (appliquer(usine))
        enregistrer();
}
