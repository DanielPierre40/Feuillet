// graphics_items — feuilles, éléments redimensionnables et leurs poignées.
#pragma once

#include "origines.h"

#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>
#include <QMap>
#include <QPixmap>

class QGraphicsSimpleTextItem;

// Drapeau global de manipulation en cours (molette, panoramique, glissé) :
// les éléments se dessinent alors avec la copie la plus légère qu'ils ont.
struct RenduRapide {
    static bool actif;
};

inline const QString COULEUR_COLLE = QStringLiteral("#ff3b30");
inline const QString COULEUR_INSERTION = QStringLiteral("#ff9500");
inline const QString COULEUR_CHOISIE = QStringLiteral("#730073");

constexpr double OMBRE_ETALEMENT = 46.0;
constexpr double OMBRE_DECALAGE = 10.0;
constexpr int OMBRE_ALPHA = 135;

void peindreOmbreDouce(QPainter *painter, const QRectF &rect, double etalement = OMBRE_ETALEMENT,
                       double decalage = OMBRE_DECALAGE, int alpha = OMBRE_ALPHA);

bool estImprimante(QPainter *painter);

class ResizablePixmapItem;

class HandleItem : public QGraphicsRectItem {
public:
    enum { Type = UserType + 3 };
    int type() const override { return Type; }

    HandleItem(const QString &cle, ResizablePixmapItem *parent);
    QString cle() const { return m_cle; }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;

private:
    QString m_cle;
    ResizablePixmapItem *m_parent;
};

class PaperItem : public QGraphicsRectItem {
public:
    enum { Type = UserType + 1 };
    int type() const override { return Type; }

    PaperItem(double w, double h, int index = 0);
    int index() const { return m_index; }
    void setIndex(int index);
    void marquerDeplacement(bool valeur = true);
    bool isPortrait() const { return rect().height() >= rect().width(); }
    QRectF scenePageRect() const { return mapRectToScene(rect()); }

    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;

private:
    int m_index;
    QGraphicsSimpleTextItem *m_label;
    bool m_enDeplacement = false;
};

class ResizablePixmapItem : public QGraphicsPixmapItem {
public:
    enum { Type = UserType + 2 };
    int type() const override { return Type; }

    explicit ResizablePixmapItem(const QPixmap &pixmap);

    QPixmap originalPixmap;
    Origine origine;
    // Rectangle d'affichage (en coordonnées de l'élément).
    QRectF rectAffiche;
    bool fraichementColle = false;

    // Copie de travail (1600 px), fabriquée au premier besoin seulement.
    QPixmap apercu();
    QPixmap apercuCache() const { return m_apercuCache; }
    void poserApercu(const QPixmap &p) { m_apercuCache = p; }
    void preparerManipulation() { apercu(); }

    void setDisplaySize(int maxW, int maxH);
    // Vignette d'affichage reprise telle quelle, proportions comprises.
    void poserTaille(int w, int h);
    void libererCacheEcran();
    void marquerColle(bool valeur = true);
    void updateHandlesPos();
    void handleMove(const QString &cle, const QPointF &souris);
    void finRedimension();
    // Centre du rectangle affiché, en coordonnées de scène.
    QPointF centreScene() const { return mapRectToScene(rectAffiche).center(); }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;

protected:
    QVariant itemChange(GraphicsItemChange change, const QVariant &value) override;
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;

private:
    static QPixmap fabriquerApercu(const QPixmap &pixmap);
    QPixmap sourceEcran(double largeurVisee);

    QPixmap m_apercuCache;
    QPixmap m_hdPixmap;
    int m_hdPalier = 0;
    QMap<QString, HandleItem *> m_handles;
};
