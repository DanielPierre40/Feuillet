// driver_feuillet — l'imprimante virtuelle « Feuillet ».
//
// Une imprimante Windows nommée « Feuillet » est créée sur le pilote
// « Microsoft Print to PDF », branchée sur un PORT FICHIER fixe :
//
//     %LOCALAPPDATA%\Feuillet\spool\feuillet_spool.pdf
//
// Un GUETTEUR invisible (Feuillet.exe --guetteur, lancé au démarrage de la
// session) surveille ce fichier : dès qu'une impression arrive, il la range
// sous un nom unique dans le dossier `impressions` et ouvre Feuillet avec.
//
// Seule la création du port et de l'imprimante exige les droits
// administrateur : Feuillet.exe se relance alors lui-même, élevé (UAC), avec
// --admin-installer ou --admin-desinstaller.
#pragma once

#include <QString>

namespace driver {

QString dossierDonnees();
QString dossierSpool();
QString fichierSpool();
QString dossierImpressions();
QString fichierConfig();
QString drapeauStop();
QString fichierLog();

void journal(const QString &msg);

bool imprimanteInstallee();
bool guetteurActif();

struct Resultat {
    bool ok;
    QString message;
};
Resultat installer();
Resultat desinstaller();

// Modes en ligne de commande (rendent le code de sortie du processus).
int guetteur();
int adminInstaller(const QString &spool);
int adminDesinstaller(const QString &spool);

} // namespace driver
