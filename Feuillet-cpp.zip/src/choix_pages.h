// choix_pages — choix des pages sur lesquelles appliquer la duplication.
#pragma once

#include <QDialog>
#include <QList>
#include <QPair>
#include <optional>

class QCheckBox;
class QPushButton;

class ChoixPagesDialog : public QDialog {
    Q_OBJECT
public:
    // `pages` : (index, libellé). `defaut` : index pré-coché.
    ChoixPagesDialog(const QList<QPair<int, QString>> &pages, int copies, int defaut,
                     QWidget *parent = nullptr);
    // Rend les index cochés, ou rien si l'utilisateur renonce.
    std::optional<QList<int>> choisir();

private:
    void cocher(bool etat);
    void majBouton();

    QList<QPair<QCheckBox *, int>> m_cases;
    QPushButton *m_btnOk;
};
