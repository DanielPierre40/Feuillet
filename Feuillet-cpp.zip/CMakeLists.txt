cmake_minimum_required(VERSION 3.21)

project(Feuillet VERSION 2.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)

find_package(Qt6 REQUIRED COMPONENTS Core Gui Widgets PrintSupport Svg Pdf)

# LibRaw (développement des photos RAW) : facultatif. Sans lui, les RAW
# passent par le décodeur d'images de Windows.
option(FEUILLET_AVEC_LIBRAW "Développer les photos RAW avec LibRaw" ON)
if(FEUILLET_AVEC_LIBRAW)
    find_package(libraw CONFIG QUIET)
    if(NOT libraw_FOUND AND NOT WIN32)
        find_path(LIBRAW_INCLUDE_DIR libraw/libraw.h)
        find_library(LIBRAW_LIBRARY NAMES raw raw_r libraw)
    endif()
endif()

set(SOURCES
    src/main.cpp
    src/aide_dialog.cpp
    src/apparence.cpp
    src/apres_impression.cpp
    src/barre_titre.cpp
    src/barres_boutons.cpp
    src/chargeur.cpp
    src/choix_pages.cpp
    src/config.cpp
    src/convertisseurs.cpp
    src/driver_feuillet.cpp
    src/editor_view.cpp
    src/format_inconnu.cpp
    src/graphics_items.cpp
    src/historique.cpp
    src/infos_dialog.cpp
    src/lecteurs_images.cpp
    src/main_window.cpp
    src/memoire_fenetres.cpp
    src/office_com.cpp
    src/options_dialog.cpp
    src/origines.cpp
    src/print_editor_dialog.cpp
    src/theme.cpp
    src/ui_helpers.cpp
    src/workers.cpp
)

set(HEADERS
    src/aide_dialog.h
    src/apparence.h
    src/apres_impression.h
    src/barre_titre.h
    src/barres_boutons.h
    src/chargeur.h
    src/choix_pages.h
    src/config.h
    src/convertisseurs.h
    src/driver_feuillet.h
    src/editor_view.h
    src/format_inconnu.h
    src/graphics_items.h
    src/historique.h
    src/infos_dialog.h
    src/lecteurs_images.h
    src/main_window.h
    src/memoire_fenetres.h
    src/office_com.h
    src/options_dialog.h
    src/origines.h
    src/print_editor_dialog.h
    src/theme.h
    src/ui_helpers.h
    src/version.h
    src/workers.h
)

set(RESSOURCES ressources/ressources.qrc)
if(WIN32)
    list(APPEND RESSOURCES ressources/feuillet.rc)
endif()

add_executable(Feuillet WIN32 ${SOURCES} ${HEADERS} ${RESSOURCES})

target_link_libraries(Feuillet PRIVATE
    Qt6::Core Qt6::Gui Qt6::Widgets Qt6::PrintSupport Qt6::Svg Qt6::Pdf)

if(FEUILLET_AVEC_LIBRAW AND libraw_FOUND AND (TARGET libraw::raw_r OR TARGET libraw::raw))
    target_compile_definitions(Feuillet PRIVATE FEUILLET_LIBRAW)
    if(WIN32)
        target_compile_definitions(Feuillet PRIVATE LIBRAW_NODLL)
    endif()
    if(TARGET libraw::raw_r)
        target_link_libraries(Feuillet PRIVATE libraw::raw_r)
    else()
        target_link_libraries(Feuillet PRIVATE libraw::raw)
    endif()
    message(STATUS "LibRaw : trouvé (RAW développés par LibRaw)")
elseif(FEUILLET_AVEC_LIBRAW AND LIBRAW_INCLUDE_DIR AND LIBRAW_LIBRARY)
    target_compile_definitions(Feuillet PRIVATE FEUILLET_LIBRAW)
    target_include_directories(Feuillet PRIVATE ${LIBRAW_INCLUDE_DIR})
    target_link_libraries(Feuillet PRIVATE ${LIBRAW_LIBRARY})
    message(STATUS "LibRaw : trouvé (${LIBRAW_LIBRARY})")
else()
    message(STATUS "LibRaw : absent (RAW par le décodeur de Windows)")
endif()

if(WIN32)
    target_compile_definitions(Feuillet PRIVATE NOMINMAX)
    target_link_libraries(Feuillet PRIVATE dwmapi ole32 oleaut32 shell32 windowscodecs uuid)
endif()

if(MSVC)
    # Les sources sont en UTF-8 (accents, émojis des boutons).
    target_compile_options(Feuillet PRIVATE /utf-8 /W3 /permissive-)
endif()
